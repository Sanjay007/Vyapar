<?php

namespace App\Http\Livewire\Admin;

use Livewire\Component;

class PaymentSetting extends Component
{
    public function render()
    {
        return view('livewire.admin.payment-setting');
    }
}
