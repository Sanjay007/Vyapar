<?php

return array (
  'next' => 'Next &raquo;',
  'previous' => '&laquo; Previous',
);
