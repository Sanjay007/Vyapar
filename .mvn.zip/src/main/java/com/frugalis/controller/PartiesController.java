package com.frugalis.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.frugalis.domain.Parties;
import com.frugalis.repository.PartiesRepository;

@RestController
@RequestMapping("/api")
public class PartiesController {
	 
	@Autowired
	PartiesRepository partiesRepository;
	
	@PostMapping("/parties")
	ResponseEntity<String> saveParty(@RequestBody Parties party){
		
		
		return new ResponseEntity<>(new String("Test"), HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	
}
