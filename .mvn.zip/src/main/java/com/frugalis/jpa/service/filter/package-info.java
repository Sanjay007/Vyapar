/**
 * Utilities for JPA criteria classes, used for filtering data on the back-end.
 */
package com.frugalis.jpa.service.filter;
