package com.frugalis.domain;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;
import lombok.Data;

@Entity
@Data
@Table(name = "Parties")
public class Parties implements Serializable  {

	private static final long serialVersionUID = 1L;

	@Id
	Long id;
	
	String partyName;
	Long phone;
	String email;
	
	

}
