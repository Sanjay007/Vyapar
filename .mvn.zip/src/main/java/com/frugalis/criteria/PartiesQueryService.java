package com.frugalis.criteria;

import javax.persistence.criteria.JoinType;

import com.frugalis.domain.Parties_;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.frugalis.domain.Parties;
import com.frugalis.jpa.service.QueryService;



@Service
@Transactional(readOnly = true)
public class PartiesQueryService extends QueryService<PartiesCriteria>  {

	
	
	 protected Specification<Parties> createSpecification(PartiesCriteria criteria) {
	        Specification<Parties> specification = Specification.where(null);
	        if (criteria != null) {
	            // This has to be called first, because the distinct method returns null
	        	 if (criteria.getPartyName() != null) {
					 specification = specification.and(buildStringSpecification(criteria.getPartyName(), Parties_.partyName));
	             }
	            
	        }
	        return specification;
	    }
	
}

