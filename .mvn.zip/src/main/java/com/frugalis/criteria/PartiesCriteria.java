package com.frugalis.criteria;

import com.frugalis.jpa.service.Criteria;
import com.frugalis.jpa.service.filter.StringFilter;

public class PartiesCriteria implements Criteria
{
	StringFilter partyName;
	
    private Boolean distinct;

	public Boolean getDistinct() {
		return distinct;
	}



	public void setDistinct(Boolean distinct) {
		this.distinct = distinct;
	}



	public PartiesCriteria(PartiesCriteria partiesCriteria) {
		
		this.partyName = partiesCriteria.partyName;
	}



	public StringFilter getPartyName() {
		return partyName;
	}



	public void setPartyName(StringFilter partyName) {
		this.partyName = partyName;
	}



	@Override
	public Criteria copy() {
		return new PartiesCriteria(this);
	}

}
