/**
 *
 */
package com.john.appo.media.service.impl;

import com.john.appo.enums.ErrorCode;
import com.john.appo.media.service.FileService;
import com.john.appo.output.ApiResponse;
import com.john.appo.utils.UniqueIdGenerator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;

/**
 * @author nakesh
 */
@Service("localMediaService")
public class LocalFileServiceImpl implements FileService {

    private static final Logger logger = LoggerFactory.getLogger(LocalFileServiceImpl.class);
    private static final int BUFFER_SIZE = 4096;
    @Value("${media.storage.location:${user.home}/media}")
    String storageFolder;

    @Override
    public ApiResponse upload(MultipartFile input, String id) {
        String filePath = UniqueIdGenerator.getId() + "_" + id + "." + input.getOriginalFilename().split("\\.")[1];
        ;
        File file = new File(storageFolder + "/" + filePath);
        try {
            input.transferTo(file);
        } catch (IllegalStateException | IOException e) {
        }
        logger.info("Uploaded file with orgnlFileName- {} and generatedFileName- {} ", input.getOriginalFilename(), filePath);
        return new ApiResponse(filePath);
    }

    @Override
    public ApiResponse download(HttpServletResponse response, String fileName) {
        try {
            response.setHeader("Content-Disposition", "attachment;filename=\"" + fileName + "\"");
            OutputStream out = response.getOutputStream();

            File downloadFile = new File(storageFolder + "/" + fileName);
            if (!downloadFile.exists()) {
                return new ApiResponse(ErrorCode.FILE_DOES_NOT_EXIST);
            }
            FileInputStream inputStream = new FileInputStream(downloadFile);
            byte[] buffer = new byte[BUFFER_SIZE];
            int bytesRead = -1;

            // write bytes read from the input stream into the output stream
            while ((bytesRead = inputStream.read(buffer)) != -1) {
                out.write(buffer, 0, bytesRead);
            }

            inputStream.close();
            out.flush();
            out.close();
            logger.info("Downloded file with generatedFileName- {} ", fileName);
        } catch (IOException e) {
            logger.info("Error parsing downloaded file IOException " + e.getMessage());
            logger.info("Downloding failed for generatedFileName- {} ", fileName);
            return new ApiResponse(ErrorCode.MEDIA_DOWNLOAD_FAILED);
        }
        return new ApiResponse();
    }

    @Override
    public ApiResponse delete(String fileName) {
        File file = new File(storageFolder + "/" + fileName);
        file.delete();
        logger.info("Deleted file with generatedFileName- {} ", fileName);
        return new ApiResponse();
    }
}
