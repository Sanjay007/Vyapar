package com.john.appo.media.service;

import com.john.appo.output.ApiResponse;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;


/**
 * @author: nakesh
 */
public interface FileService {
    ApiResponse upload(MultipartFile input, String id);

    ApiResponse download(HttpServletResponse response, String fileName);

    ApiResponse delete(String fileName);
}
