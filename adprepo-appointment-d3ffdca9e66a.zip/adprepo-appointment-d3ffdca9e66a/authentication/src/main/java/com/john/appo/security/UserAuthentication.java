package com.john.appo.security;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;

import java.util.Collection;

/**
 * @author nakesh
 */
public class UserAuthentication implements Authentication {

    private static final long serialVersionUID = 1L;

    private final UserRecord user;
    private boolean authenticated = true;

    public UserAuthentication(UserRecord user) {
        this.user = user;
    }

    @Override
    public String getName() {
        // TODO Auto-generated method stub
        return user.getUsername();
    }

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        // TODO Auto-generated method stub
        return user.getAuthorities();
    }

    @Override
    public Object getCredentials() {
        // TODO Auto-generated method stub
        return user.getPassword();
    }

    @Override
    public UserRecord getDetails() {
        // TODO Auto-generated method stub
        return user;
    }

    @Override
    public Object getPrincipal() {
        // TODO Auto-generated method stub
        return user.getUsername();
    }

    @Override
    public boolean isAuthenticated() {
        // TODO Auto-generated method stub
        return this.authenticated;
    }

    @Override
    public void setAuthenticated(boolean arg0) throws IllegalArgumentException {
        // TODO Auto-generated method stub
        this.authenticated = arg0;
    }

    public UserRecord getUser() {
        return user;
    }
}
