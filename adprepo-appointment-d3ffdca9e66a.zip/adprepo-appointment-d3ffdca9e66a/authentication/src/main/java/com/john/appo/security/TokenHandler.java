package com.john.appo.security;

import com.john.appo.constants.C;
import com.john.appo.enums.TimeZoneList;
import com.john.appo.enums.UserType;
import com.john.appo.output.TokenModel;
import io.jsonwebtoken.*;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;

/**
 * @author nakesh
 */
public final class TokenHandler {
    private final String secret = "some_secret";
    private final long expirationSeconds = 86400; //one day


    public TokenHandler() {
    }

    public String parseUserFromToken(String token, String audience) throws ExpiredJwtException, MalformedJwtException {
        try {
            Claims claims = Jwts.parser().setSigningKey(secret).parseClaimsJws(token).getBody();
            String username = claims.getSubject();
            if (!claims.getAudience().equals(audience)) {
//				throw new BadCredentialsException("Client authentication error: Token is being used by unintended client");
            }
//			DateTime issuedAt = new DateTime(claims.getIssuedAt());
            LocalDateTime expiresAt = LocalDateTime.ofInstant(claims.getExpiration().toInstant(), ZoneId.of(TimeZoneList.IST.getZoneId()));
            if (expiresAt.isBefore(LocalDateTime.now(ZoneId.of(TimeZoneList.IST.getZoneId())))) {
                throw new ExpiredJwtException(null, null, "Token has expired");
            }
            return username;
        } catch (SignatureException e) {
            throw new SignatureException("Invalid token: Signature does not match");
        } catch (NullPointerException e) {
            throw new NullPointerException("User does not exist");
        } catch (Exception exception) {
            throw new SignatureException("Invalid token: Signature does not match");
        }
    }

    public TokenModel parseUserAndRolesFromToken(String token, String audience) throws ExpiredJwtException, MalformedJwtException {
        try {
            TokenModel tkm = new TokenModel();
            Claims claims = Jwts.parser().setSigningKey(secret).parseClaimsJws(token).getBody();
            tkm.setUserId(Long.parseLong(claims.getSubject()));
            tkm.setRoles((String) claims.get("roles"));
            tkm.setUserType(UserType.valueOf((String) claims.get("userType")));
            tkm.setUsername((String) claims.get("username"));
        /*	if(!claims.getAudience().equals(audience)){
//				throw new BadCredentialsException("Client authentication error: Token is being used by unintended client");
			}*/
            LocalDateTime expiresAt = LocalDateTime.ofInstant(claims.getExpiration().toInstant(), ZoneId.of(TimeZoneList.IST.getZoneId()));
            if (expiresAt.isBefore(LocalDateTime.now(ZoneId.of(TimeZoneList.IST.getZoneId())))) {
                throw new ExpiredJwtException(null, null, "Token has expired");
            }
            return tkm;
        } catch (SignatureException e) {
            throw new SignatureException("Invalid token: Signature does not match");
        } catch (NullPointerException e) {
            throw new NullPointerException("User does not exist");
        } catch (Exception exception) {
            throw new SignatureException("Invalid token: Signature does not match");
        }
    }

    public String createTokenForUser(String userId, String audience) {
        LocalDateTime issuedAt = LocalDateTime.now(ZoneId.of(TimeZoneList.IST.getZoneId()));
        //DateTime issuedAt = new DateTime(new Date());
//		logger.debug("Security props: " + securityProps.getValue());
        LocalDateTime expiration = issuedAt.plusSeconds(expirationSeconds);
        return Jwts.builder().setSubject(userId).setAudience(audience).signWith(SignatureAlgorithm.HS256, secret)
                .setIssuedAt(Date.from(issuedAt.atZone(ZoneId.of(TimeZoneList.IST.getZoneId())).toInstant()))
                        .setExpiration(Date.from(expiration.atZone(ZoneId.of(TimeZoneList.IST.getZoneId())).toInstant())).compact();
    }

    public String createTokenForUserWithRoles(String userId, String username, UserType userType, String userRole) {
        LocalDateTime issuedAt = LocalDateTime.now(ZoneId.of(TimeZoneList.IST.getZoneId()));
        //DateTime issuedAt = new DateTime(new Date());
//		logger.debug("Security props: " + securityProps.getValue());
        LocalDateTime expiration = issuedAt.plusSeconds(expirationSeconds);
        Claims claims = Jwts.claims().setSubject(userId).setAudience(C.APP_NAME);
        claims.put("roles", userRole);
        claims.put("userType", userType.name());
        claims.put("username", username);
        return Jwts.builder().setClaims(claims).signWith(SignatureAlgorithm.HS256, secret)
                .setIssuedAt(Date.from(issuedAt.atZone(ZoneId.of(TimeZoneList.IST.getZoneId())).toInstant()))
                .setExpiration(Date.from(expiration.atZone(ZoneId.of(TimeZoneList.IST.getZoneId())).toInstant())).compact();
    }

}