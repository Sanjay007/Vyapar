/**
 *
 */
package com.john.appo.security.service;

import com.john.appo.enums.UserType;
import com.john.appo.security.UserAuthentication;
import com.john.appo.security.UserRecord;
import org.springframework.security.core.userdetails.UserDetailsService;

/**
 * @author nakesh
 */
public interface AuthenticationService extends UserDetailsService {

    public UserAuthentication getUserFromToken(String token, String audience);

    public String createToken(Long userId, String appId);

    UserRecord getUser();

    String createToken(Long userId, String username, UserType userType, String userRole);

}
