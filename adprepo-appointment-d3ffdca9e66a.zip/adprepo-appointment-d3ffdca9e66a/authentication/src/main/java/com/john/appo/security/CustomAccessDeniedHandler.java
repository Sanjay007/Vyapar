package com.john.appo.security;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.john.appo.output.ApiResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.web.access.AccessDeniedHandler;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * @author: nakesh
 */
public class CustomAccessDeniedHandler implements AccessDeniedHandler {

    private Logger logger = LoggerFactory.getLogger(CustomAccessDeniedHandler.class);

    public CustomAccessDeniedHandler() {
        super();
    }

    @Override
    public void handle(HttpServletRequest request, HttpServletResponse response,
                       AccessDeniedException accessDeniedException) throws IOException, ServletException {

        logger.info("Got Access denied exception = " + accessDeniedException.getMessage());

        ApiResponse error = new ApiResponse();
        error.setSuccess(false);
        error.setErrorCode(403);
        error.setErrorMsgEn("Unauthorized access: You are Not Authorised to access this resource.Please contact Admin for more details.");
        HttpServletResponse httpResponse = (HttpServletResponse) response;
        httpResponse.setStatus(HttpServletResponse.SC_FORBIDDEN);
        httpResponse.setContentType("application/json");
        httpResponse.setCharacterEncoding("UTF-8");
        httpResponse.getWriter().write(new ObjectMapper().writeValueAsString(error));
    }

}
