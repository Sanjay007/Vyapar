package com.john.appo.security;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.john.appo.constants.C;
import com.john.appo.output.ApiResponse;
import com.john.appo.security.service.AuthenticationService;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.MalformedJwtException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.filter.GenericFilterBean;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * @author nakesh
 */
public class HeaderAuthenticationFilter extends GenericFilterBean {
    private AuthenticationService authenticationService;

    public HeaderAuthenticationFilter(AuthenticationService authenticationService) {
        this.authenticationService = authenticationService;
    }

    @Override
    public void doFilter(ServletRequest arg0, ServletResponse arg1, FilterChain arg2)
            throws IOException, ServletException {
        HttpServletRequest request = (HttpServletRequest) arg0;
        HttpServletResponse response = (HttpServletResponse) arg1;
        if (SecurityContextHolder.getContext().getAuthentication() == null) {
            try {
                String token = request.getHeader(C.X_AUTH_TOKEN);
                String audience = C.APP_NAME;
                if (token != null) {
                    Authentication auth = authenticationService.getUserFromToken(token, audience);
                    SecurityContextHolder.getContext().setAuthentication(auth);
                } else {
                    String clientId = request.getHeader(C.CLIENT_ID);
                    logger.info("clientId : " + clientId);
                    if (clientId != null && C.CLIENT_ID.equalsIgnoreCase(clientId)) {
                        // do something
                    } else {
                        throw new ExpiredJwtException(null, null, "Invalid token: Signature does not match");
                    }
                }
                logger.info("Continuing with Filter chain : moving forward");
                arg2.doFilter(request, response);
            } catch (ExpiredJwtException ex) {
                this.sendForbiddenJsonError(response, 401, "Unauthroized access: token expired",
                        HttpServletResponse.SC_UNAUTHORIZED);
            } catch (MalformedJwtException ex) {
                this.sendForbiddenJsonError(response, 401, "Unauthroized access: unable to authenticate the user",
                        HttpServletResponse.SC_UNAUTHORIZED);
            } catch (Exception exception) {
                this.sendForbiddenJsonError(response, 401, "Unauthroized access: unable to authenticate the user",
                        HttpServletResponse.SC_UNAUTHORIZED);
            }
        }

    }

    private void sendForbiddenJsonError(ServletResponse response, int errorCode, String errorEn, int httpServletResponseCode) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        ((HttpServletResponse) response).setStatus(httpServletResponseCode);
        ApiResponse error = new ApiResponse();
        error.setSuccess(false);
        error.setErrorMsgEn(errorEn);
        error.setErrorCode(errorCode);
        response.getWriter().write(new ObjectMapper().writeValueAsString(error));
    }


}
