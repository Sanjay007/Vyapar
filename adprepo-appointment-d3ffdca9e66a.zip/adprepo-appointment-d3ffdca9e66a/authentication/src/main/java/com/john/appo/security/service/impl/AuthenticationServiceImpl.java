/**
 *
 */
package com.john.appo.security.service.impl;

import com.john.appo.constants.C;
import com.john.appo.enums.UserType;
import com.john.appo.output.TokenModel;
import com.john.appo.security.TokenHandler;
import com.john.appo.security.UserAuthentication;
import com.john.appo.security.UserRecord;
import com.john.appo.security.service.AuthenticationService;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.MalformedJwtException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

/**
 * @author nakesh
 */
@Service
public class AuthenticationServiceImpl implements AuthenticationService {

    private final TokenHandler tokenHandler;

    public AuthenticationServiceImpl() {
        tokenHandler = new TokenHandler();
    }

    @Override
    public UserRecord getUser() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication == null || !authentication.isAuthenticated())
            return null;
        return (UserRecord) authentication.getDetails();
    }

    @Override
    public UserDetails loadUserByUsername(String arg0) throws UsernameNotFoundException {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public UserAuthentication getUserFromToken(String token, String audience) throws ExpiredJwtException, MalformedJwtException {
        TokenModel tkm = tokenHandler.parseUserAndRolesFromToken(token, audience);
        UserAuthentication userAuth = new UserAuthentication(new UserRecord(tkm));
        userAuth.setAuthenticated(true);
        return userAuth;
    }

    @Override
    public String createToken(Long userId, String appCode) {
        if (userId != null) {
            return tokenHandler.createTokenForUser(String.valueOf(userId), appCode);
        }
        return null;
    }

    @Override
    public String createToken(Long userId, String username, UserType userType, String userRole) {
        if (userId != null) {
            String token = tokenHandler.createTokenForUserWithRoles(String.valueOf(userId), username, userType, userRole);
            setSecurityContext(token);
            return token;
        }
        return null;
    }

    private void setSecurityContext(String token) {
        Authentication auth = getUserFromToken(token, C.APP_NAME);
        SecurityContextHolder.getContext().setAuthentication(auth);
    }

}
