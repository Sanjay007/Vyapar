/**
 *
 */
package com.john.appo.security;

import com.john.appo.constants.C;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;

/**
 * @author nakesh
 */

@Configuration
@EnableWebSecurity
@Order(1)
public class SwaggerSecurityConfig extends WebSecurityConfigurerAdapter {
    @Autowired
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
        auth
                .inMemoryAuthentication()
                .withUser("appo@").password("appo#apis")
                .authorities("ROLE_SWAGGER_ADMIN");
    }

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http
                .antMatcher(C.SWAGGER_UI)
                .authorizeRequests()
                .anyRequest().hasRole("SWAGGER_ADMIN")
                .and()
                .httpBasic();
    }
}
