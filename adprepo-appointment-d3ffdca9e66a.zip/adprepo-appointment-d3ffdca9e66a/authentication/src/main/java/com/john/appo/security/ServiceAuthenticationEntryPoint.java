package com.john.appo.security;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.john.appo.output.ApiResponse;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.AuthenticationEntryPoint;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * @author nakesh
 */
public class ServiceAuthenticationEntryPoint implements AuthenticationEntryPoint {

    public ServiceAuthenticationEntryPoint() {
        super();
    }

    //Any exception while security check will land here
    @Override
    public void commence(HttpServletRequest arg0, HttpServletResponse arg1, AuthenticationException arg2)
            throws IOException, ServletException {
        ApiResponse error = new ApiResponse();
        error.setSuccess(false);
        error.setErrorCode(403);
        error.setErrorMsgEn("Unauthenticated access: Please sign in first");
        HttpServletResponse httpResponse = (HttpServletResponse) arg1;
        httpResponse.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
        httpResponse.setContentType("application/json");
        httpResponse.setCharacterEncoding("UTF-8");
        httpResponse.getWriter().write(new ObjectMapper().writeValueAsString(error));
    }
}