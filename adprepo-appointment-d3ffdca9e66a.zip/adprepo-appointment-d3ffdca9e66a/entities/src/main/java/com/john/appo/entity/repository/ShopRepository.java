/**
 *
 */
package com.john.appo.entity.repository;

import com.john.appo.entity.Shop;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

/**
 * @author nakesh
 */
public interface ShopRepository extends JpaRepository<Shop, Long> {

    List<Shop> findAllByOrderByCreatedTimeAsc();

}
