package com.john.appo.entity.repository;

import com.john.appo.entity.ServiceSlotBooking;
import com.john.appo.enums.Status;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;
import java.util.List;

/**
 * @author Krishna
 */
public interface ServiceSlotBookingRepository extends JpaRepository<ServiceSlotBooking, Long> {

    List<ServiceSlotBooking> findByShopIdInAndServiceDate(List<Long> shopIds, LocalDate serviceDate);

    List<ServiceSlotBooking> findByShopIdIn(List<Long> shopIds);

    List<ServiceSlotBooking> findByShopIdAndShopServiceIdInAndSlotInAndStatusInAndServiceDate(Long shopId, List<Long> shopServiceId, List<Integer> slot, List<Status> status, LocalDate serviceDate);

    List<ServiceSlotBooking> findByBookingId(String bookingId);
}
