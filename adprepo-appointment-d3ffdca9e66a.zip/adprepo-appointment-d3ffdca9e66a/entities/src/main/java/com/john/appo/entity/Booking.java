/**
 *
 */
package com.john.appo.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.john.appo.constants.C;
import com.john.appo.enums.PaymentMode;
import com.john.appo.enums.Status;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.time.LocalDate;

/**
 * @author nakesh
 */
@Table
@Entity(name = C.E_BOOKING)
public class Booking extends AuditedEntity {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.TABLE, generator = "enhanced_table_seq_gen")
    @GenericGenerator(name = "enhanced_table_seq_gen", strategy = "org.hibernate.id.enhanced.TableGenerator",
            parameters = {
                    @org.hibernate.annotations.Parameter(name = "table_name", value = "lib_sequences"),
                    @org.hibernate.annotations.Parameter(name = "segment_column_name", value = "name"),
                    @org.hibernate.annotations.Parameter(name = "segment_value", value = "booking_seq"),
                    @org.hibernate.annotations.Parameter(name = "value_column_name", value = "next_val")})
    private Long id;

    @Column(name = "booking_id")
    private String bookingId;
    @Column(name = "user_id")
    private Long userId;
    @Column(name = "shop_id")
    private Long shopId;
    @Column(name = "cat_id")
    private Long catId;
    @Column(name = "sub_cat_id")
    private Long subCatId;
    @Column(name = "shop_service_id")
    private Long shopServiceId;
    @Column(name = "address_id")
    private Long addressId; // userId
    private int slot;
    private int duration;
    @Column(name = "service_date")
    private LocalDate serviceDate;
    @Enumerated(EnumType.STRING)
    @Column(name = "payment_mode")
    private PaymentMode paymentMode;
    @Column(name = "payment_id")
    private String paymentId;
    @Column(name = "act_price")
    private Double actualPrice;
    @Column(name = "paid_amount")
    private Double paidAmount;
    @Column(name = "dis_flat")
    private Double disFlat; // discountFlat
    @Column(name = "dis_percent")
    private Integer disPercent;// discountPercentage
    @Column(name = "promo_id")
    private Long promoId;
    @Column(name = "promo_code")
    private String promoCode;
    private Status status;
    private Float lat;
    private Float lon;
    private String description;

    public Booking() {
        super();
    }

    public Booking(String bookingId, Long userId, Long shopId, Long catId, Long subCatId, Long shopServiceId, Long addressId, int slot,
                   int duration, LocalDate serviceDate, PaymentMode paymentMode, String paymentId, Double actualPrice, Double paidAmount,
                   Double disFlat, Integer disPercent, Long promoId, String promoCode, Status status, Float lat, Float lon,
                   String description) {
        super();
        this.bookingId = bookingId;
        this.userId = userId;
        this.shopId = shopId;
        this.catId = catId;
        this.subCatId = subCatId;
        this.shopServiceId = shopServiceId;
        this.addressId = addressId;
        this.slot = slot;
        this.duration = duration;
        this.serviceDate = serviceDate;
        this.paymentMode = paymentMode;
        this.paymentId = paymentId;
        this.actualPrice = actualPrice;
        this.paidAmount = paidAmount;
        this.disFlat = disFlat;
        this.disPercent = disPercent;
        this.promoId = promoId;
        this.promoCode = promoCode;
        this.status = status;
        this.lat = lat;
        this.lon = lon;
        this.description = description;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getBookingId() {
        return bookingId;
    }

    public void setBookingId(String bookingId) {
        this.bookingId = bookingId;
    }

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd-MM-yyyy")
    public LocalDate getServiceDate() {
        return serviceDate;
    }

    public void setServiceDate(LocalDate serviceDate) {
        this.serviceDate = serviceDate;
    }

    public Double getActualPrice() {
        return actualPrice;
    }

    public void setActualPrice(Double actualPrice) {
        this.actualPrice = actualPrice;
    }

    public Double getActualAmount() {
        return actualPrice;
    }

    public void setActualAmount(Double actualPrice) {
        this.actualPrice = actualPrice;
    }

    public Double getDisFlat() {
        return disFlat;
    }

    public void setDisFlat(Double disFlat) {
        this.disFlat = disFlat;
    }

    public Integer getDisPercent() {
        return disPercent;
    }

    public void setDisPercent(Integer disPercent) {
        this.disPercent = disPercent;
    }


    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Float getLat() {
        return lat;
    }

    public void setLat(Float lat) {
        this.lat = lat;
    }

    public Float getLon() {
        return lon;
    }

    public void setLon(Float lon) {
        this.lon = lon;
    }

    public Long getShopServiceId() {
        return shopServiceId;
    }

    public void setShopServiceId(Long shopServiceId) {
        this.shopServiceId = shopServiceId;
    }

    public Long getAddressId() {
        return addressId;
    }

    public void setAddressId(Long addressId) {
        this.addressId = addressId;
    }

    public Long getPromoId() {
        return promoId;
    }

    public void setPromoId(Long promoId) {
        this.promoId = promoId;
    }

    public String getPromoCode() {
        return promoCode;
    }

    public void setPromoCode(String promoCode) {
        this.promoCode = promoCode;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public Long getShopId() {
        return shopId;
    }

    public void setShopId(Long shopId) {
        this.shopId = shopId;
    }

    public Long getCatId() {
        return catId;
    }

    public void setCatId(Long catId) {
        this.catId = catId;
    }

    public Long getSubCatId() {
        return subCatId;
    }

    public void setSubCatId(Long subCatId) {
        this.subCatId = subCatId;
    }

    public int getSlot() {
        return slot;
    }

    public void setSlot(int slot) {
        this.slot = slot;
    }

    public int getDuration() {
        return duration;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }

    public PaymentMode getPaymentMode() {
        return paymentMode;
    }

    public void setPaymentMode(PaymentMode paymentMode) {
        this.paymentMode = paymentMode;
    }

    public String getPaymentId() {
        return paymentId;
    }

    public void setPaymentId(String paymentId) {
        this.paymentId = paymentId;
    }

    public Double getPaidAmount() {
        return paidAmount;
    }

    public void setPaidAmount(Double paidAmount) {
        this.paidAmount = paidAmount;
    }

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }
}
