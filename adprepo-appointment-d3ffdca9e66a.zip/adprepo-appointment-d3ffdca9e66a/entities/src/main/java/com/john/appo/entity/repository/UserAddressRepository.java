package com.john.appo.entity.repository;

import com.john.appo.entity.UserAddress;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * @author Krishna
 */
public interface UserAddressRepository extends JpaRepository<UserAddress, Long> {
}
