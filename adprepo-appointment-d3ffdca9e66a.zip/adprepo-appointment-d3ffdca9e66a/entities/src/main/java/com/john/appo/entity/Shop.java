/**
 *
 */
package com.john.appo.entity;

import com.john.appo.constants.C;
import com.john.appo.entity.utils.StringListConverter;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.util.List;

/**
 * @author nakesh
 */
@Entity
@Table(name = C.E_SHOP)
public class Shop extends AuditedEntity {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.TABLE, generator = "enhanced_table_seq_gen")
    @GenericGenerator(name = "enhanced_table_seq_gen", strategy = "org.hibernate.id.enhanced.TableGenerator",
            parameters = {
                    @org.hibernate.annotations.Parameter(name = "table_name", value = "lib_sequences"),
                    @org.hibernate.annotations.Parameter(name = "segment_column_name", value = "name"),
                    @org.hibernate.annotations.Parameter(name = "segment_value", value = "shop_seq"),
                    @org.hibernate.annotations.Parameter(name = "value_column_name", value = "next_val")})
    private Long id;

    @Column(name = "owner_id")
    private Long ownerId;   //id from admin table
    private String name;
    private Long phone;
    private Long mobile;
    private Float lat;
    private Float lon;
    @Column(name = "street_name")
    private String streetName;
    private String locality;
    private String area;
    private String state;
    private String city;
    @Column(name = "pin_code")
    private int pinCode;
    private String address;
    @Column(name = "working_days")
    private String workingDays; // comma separated days
    @Column(name = "max_seat")
    private int maxSeat;
    @Column(name = "start_time")
    private int startTime; // in minutes (24 hrs time frame)
    @Column(name = "end_time")
    private int endTime; // in minutes (24 hrs time frame)
    @Column(name = "break_time")
    private int breakTime; // in minutes (24 hrs time frame)
    @Column(name = "break_duration")
    private int breakDuration; // in minutes (24 hrs time frame)
    private Float rating;
    private String description;
    private boolean active;
    private boolean approved;
    @Convert(converter = StringListConverter.class)
    private List<String> files;

    public Shop() {

    }

    public Shop(Long ownerId, String name, Long phone, Long mobile, Float lat, Float lon, String streetName,
                String locality, String area, String state, String city, int pinCode, String address, String workingDays,
                int maxSeat, int startTime, int endTime, int breakTime, int breakDuration, Float rating,
                String description, boolean active, boolean approved) {
        super();
        this.ownerId = ownerId;
        this.name = name;
        this.phone = phone;
        this.mobile = mobile;
        this.lat = lat;
        this.lon = lon;
        this.streetName = streetName;
        this.locality = locality;
        this.area = area;
        this.state = state;
        this.city = city;
        this.pinCode = pinCode;
        this.address = address;
        this.workingDays = workingDays;
        this.maxSeat = maxSeat;
        this.startTime = startTime;
        this.endTime = endTime;
        this.breakTime = breakTime;
        this.breakDuration = breakDuration;
        this.rating = rating;
        this.description = description;
        this.active = active;
        this.approved = approved;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public List<String> getFiles() {
        return files;
    }

    public void setFiles(List<String> files) {
        this.files = files;
    }

    public Long getOwnerId() {
        return ownerId;
    }

    public void setOwnerId(Long ownerId) {
        this.ownerId = ownerId;
    }

    public Float getRating() {
        return rating;
    }

    public void setRating(Float rating) {
        this.rating = rating;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getWorkingDays() {
        return workingDays;
    }

    public void setWorkingDays(String workingDays) {
        this.workingDays = workingDays;
    }

    public int getMaxSeat() {
        return maxSeat;
    }

    public void setMaxSeat(int maxSeat) {
        this.maxSeat = maxSeat;
    }

    public int getStartTime() {
        return startTime;
    }

    public void setStartTime(int startTime) {
        this.startTime = startTime;
    }

    public int getEndTime() {
        return endTime;
    }

    public void setEndTime(int endTime) {
        this.endTime = endTime;
    }

    public int getBreakTime() {
        return breakTime;
    }

    public void setBreakTime(int breakTime) {
        this.breakTime = breakTime;
    }

    public int getBreakDuration() {
        return breakDuration;
    }

    public void setBreakDuration(int breakDuration) {
        this.breakDuration = breakDuration;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public boolean isApproved() {
        return approved;
    }

    public void setApproved(boolean approved) {
        this.approved = approved;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Long getPhone() {
        return phone;
    }

    public void setPhone(Long phone) {
        this.phone = phone;
    }

    public Long getMobile() {
        return mobile;
    }

    public void setMobile(Long mobile) {
        this.mobile = mobile;
    }

    public Float getLat() {
        return lat;
    }

    public void setLat(Float lat) {
        this.lat = lat;
    }

    public Float getLon() {
        return lon;
    }

    public void setLon(Float lon) {
        this.lon = lon;
    }

    public String getStreetName() {
        return streetName;
    }

    public void setStreetName(String streetName) {
        this.streetName = streetName;
    }

    public String getLocality() {
        return locality;
    }

    public void setLocality(String locality) {
        this.locality = locality;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public int getPinCode() {
        return pinCode;
    }

    public void setPinCode(int pinCode) {
        this.pinCode = pinCode;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    @Override
    public String toString() {
        return "Shop [getId()=" + getId() + ", lat=" + lat + ", lon=" + lon + ", city=" + city + ", pinCode=" + pinCode + ", maxSeat=" + maxSeat
                + ", startTime=" + startTime + ", endTime=" + endTime + ", rating=" + rating + ", active=" + active
                + "]";
    }


}
