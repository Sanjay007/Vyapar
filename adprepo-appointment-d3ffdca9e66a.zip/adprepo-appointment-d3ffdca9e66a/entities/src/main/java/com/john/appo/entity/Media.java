/**
 *
 */
package com.john.appo.entity;

import com.john.appo.constants.C;
import com.john.appo.enums.Operation;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;

/**
 * @author nakesh
 */
@Entity
@Table(name = C.E_MEDIA)
public class Media extends AuditedEntity {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.TABLE, generator = "enhanced_table_seq_gen")
    @GenericGenerator(name = "enhanced_table_seq_gen", strategy = "org.hibernate.id.enhanced.TableGenerator",
            parameters = {
                    @org.hibernate.annotations.Parameter(name = "table_name", value = "lib_sequences"),
                    @org.hibernate.annotations.Parameter(name = "segment_column_name", value = "name"),
                    @org.hibernate.annotations.Parameter(name = "segment_value", value = "media_seq"),
                    @org.hibernate.annotations.Parameter(name = "value_column_name", value = "next_val")})
    private Long id;

    @Column(name = "user_id")
    private Long userId;
    @Column(name = "shop_id")
    private Long shopId;
    @Column(name = "shop_Service_id")
    private Long shopServiceId;
    @Enumerated(EnumType.STRING)
    private Operation operation;
    @Column(name = "orgnl_name")
    private String orgnlName;
    @Column(name = "generated_name")
    private String generatedName;
    @Column(name = "content_type")
    private String contentType;
    private boolean active;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public Long getShopId() {
        return shopId;
    }

    public void setShopId(Long shopId) {
        this.shopId = shopId;
    }

    public Long getShopServiceId() {
        return shopServiceId;
    }

    public void setShopServiceId(Long shopServiceId) {
        this.shopServiceId = shopServiceId;
    }

    public Operation getOperation() {
        return operation;
    }

    public void setOperation(Operation operation) {
        this.operation = operation;
    }

    public String getOrgnlName() {
        return orgnlName;
    }

    public void setOrgnlName(String orgnlName) {
        this.orgnlName = orgnlName;
    }

    public String getGeneratedName() {
        return generatedName;
    }

    public void setGeneratedName(String generatedName) {
        this.generatedName = generatedName;
    }

    public String getContentType() {
        return contentType;
    }

    public void setContentType(String contentType) {
        this.contentType = contentType;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }
}