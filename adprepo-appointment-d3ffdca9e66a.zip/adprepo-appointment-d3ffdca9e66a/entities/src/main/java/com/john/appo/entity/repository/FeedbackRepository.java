/**
 *
 */
package com.john.appo.entity.repository;

import com.john.appo.entity.Feedback;
import com.john.appo.enums.Operation;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

/**
 * @author nakesh
 */
public interface FeedbackRepository extends JpaRepository<Feedback, Long> {

    Feedback findByUserIdAndBookingIdAndOperation(Long userId, Long bookingId, Operation operation);

    @Query("SELECT AVG(rating) FROM Feedback where shopServiceId = :shopServiceId AND operation = :operation")
    Double findAverageRatingForServiceId(@Param("shopServiceId") Long shopServiceId, @Param("operation") Operation operation);

    @Query("SELECT AVG(rating) FROM Feedback where shopId = :shopId AND operation = :operation")
    Double findAverageRatingForShopId(@Param("shopId") Long shopId, @Param("operation") Operation operation);

    @Query("SELECT rating, count(id) FROM Feedback WHERE shopId = :shopId AND rating = :rating AND operation = :operation GROUP BY rating")
    List<Object[]> findByShopIdAndRatingAndOperation(@Param("shopId") Long shopId, @Param("rating") Integer rating, @Param("operation") Operation operation);

    @Query("SELECT rating, count(id) FROM Feedback WHERE shopServiceId = :shopServiceId AND rating = :rating AND operation = :operation GROUP BY rating")
    List<Object[]> findByShopServiceIdAndRatingAndOperation(@Param("shopServiceId") Long shopServiceId, @Param("rating") Integer rating, @Param("operation") Operation operation);

    @Query("SELECT rating, count(id) FROM Feedback WHERE shopId = :shopId AND operation = :operation GROUP BY rating")
    List<Object[]> findByShopIdAndOperation(@Param("shopId") Long shopId, @Param("operation") Operation operation);

    @Query("SELECT rating, count(id) FROM Feedback WHERE shopServiceId = :shopServiceId AND operation = :operation GROUP BY rating")
    List<Object[]> findByShopServiceIdAndOperation(@Param("shopServiceId") Long shopServiceId, @Param("operation") Operation operation);

    @Query("SELECT rating, count(id) FROM Feedback WHERE rating = :rating AND operation = :operation GROUP BY rating")
    List<Object[]> findByRatingAndOperation(@Param("rating") Integer rating, @Param("operation") Operation operation);

    @Query("SELECT shopId, count(id) FROM Feedback WHERE shopId in (:shopIds) AND operation = :operation GROUP BY shopId")
    List<Object[]> getFeedbackCountShopWise(@Param("shopIds") List<Long> shopIds, @Param("operation") Operation operation);

    Page<Feedback> findByShopServiceIdAndOperationOrderByRatingDescCreatedTimeDesc(Long shopServiceId,
                                                                                   Operation uSsFeedback, Pageable pageable);

    Page<Feedback> findByShopIdAndRatingAndOperationOrderByCreatedTimeDesc(Long shopId, Integer rating,
                                                                           Operation uSsFeedback, Pageable pageable);

    Page<Feedback> findByShopServiceIdAndRatingAndOperationOrderByCreatedTimeDesc(Long shopServiceId, Integer rating,
                                                                                  Operation uSsFeedback, Pageable pageable);

    Page<Feedback> findByShopIdAndOperationOrderByRatingDescCreatedTimeDesc(Long shopId, Operation uSsFeedback,
                                                                            Pageable pageable);

    Page<Feedback> findByRatingAndOperationOrderByCreatedTimeDesc(Integer rating, Operation uSsFeedback,
                                                                  Pageable pageable);


}
