/**
 *
 */
package com.john.appo.entity.repository;

import com.john.appo.entity.Category;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * @author nakesh
 */
public interface CategoryRepository extends JpaRepository<Category, Long> {

}
