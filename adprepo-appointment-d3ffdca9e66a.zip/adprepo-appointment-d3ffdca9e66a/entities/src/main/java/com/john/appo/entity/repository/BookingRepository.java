/**
 *
 */
package com.john.appo.entity.repository;

import com.john.appo.entity.Booking;
import com.john.appo.enums.Status;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

/**
 * @author nakesh
 */
public interface BookingRepository extends JpaRepository<Booking, Long> {

    List<Booking> findByShopIdAndCreatedTime(Long shopId, LocalDateTime dateTime);

    List<Booking> findByShopIdInAndServiceDate(List<Long> shopIds, LocalDate serviceDate);

    List<Booking> findByShopIdIn(List<Long> shopIds);

    //with paging
    Page<Booking> findByBookingId(String bookingId, Pageable pageable);

    Page<Booking> findAllByOrderByModifiedTimeDesc(Pageable pageable);

    Page<Booking> findByShopIdOrderByModifiedTimeDesc(Long shopId, Pageable pageable);

    Page<Booking> findByShopServiceIdOrderByModifiedTimeDesc(Long shopServiceId, Pageable pageable);

    Page<Booking> findByCatIdOrderByModifiedTimeDesc(Long catId, Pageable pageable);

    Page<Booking> findByStatusOrderByModifiedTimeDesc(String status, Pageable pageable);

    Page<Booking> findByModifiedTimeBetweenOrderByModifiedTimeDesc(LocalDateTime start, LocalDateTime end, Pageable pageable);

	List<Booking> findByShopServiceIdAndServiceDateInAndStatus(Long serviceId, List<LocalDate> blockingDates,
			Status approved);

}
