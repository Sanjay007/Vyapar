/**
 *
 */
package com.john.appo.entity;

import com.john.appo.constants.C;
import com.john.appo.enums.Device;
import com.john.appo.enums.Operation;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;

/**
 * @author nakesh
 */
@Entity
@Table(name = C.E_FEEDBACK)
public class Feedback extends AuditedEntity {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.TABLE, generator = "enhanced_table_seq_gen")
    @GenericGenerator(name = "enhanced_table_seq_gen", strategy = "org.hibernate.id.enhanced.TableGenerator",
            parameters = {
                    @org.hibernate.annotations.Parameter(name = "table_name", value = "lib_sequences"),
                    @org.hibernate.annotations.Parameter(name = "segment_column_name", value = "name"),
                    @org.hibernate.annotations.Parameter(name = "segment_value", value = "feedback_seq"),
                    @org.hibernate.annotations.Parameter(name = "value_column_name", value = "next_val")})
    private Long id;

    @Column(name = "shop_id")
    private Long shopId;
    @Column(name = "shop_service_id")
    private Long shopServiceId;
    @Column(name = "user_id")
    private Long userId;
    @Column(name = "booking_id")
    private Long bookingId;
    private Float lat;
    private Float lon;
    @Enumerated(EnumType.STRING)
    private Operation operation;
    private int rating;
    private String review;
    @Enumerated(EnumType.STRING)
    private Device device;
    @Column(name = "device_model")
    private String deviceModel;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getBookingId() {
        return bookingId;
    }

    public void setBookingId(Long bookingId) {
        this.bookingId = bookingId;
    }

    public Device getDevice() {
        return device;
    }

    public void setDevice(Device device) {
        this.device = device;
    }

    public String getDeviceModel() {
        return deviceModel;
    }

    public void setDeviceModel(String deviceModel) {
        this.deviceModel = deviceModel;
    }

    public Operation getOperation() {
        return operation;
    }

    public void setOperation(Operation operation) {
        this.operation = operation;
    }

    public Long getShopId() {
        return shopId;
    }

    public void setShopId(Long shopId) {
        this.shopId = shopId;
    }

    public Long getShopServiceId() {
        return shopServiceId;
    }

    public void setShopServiceId(Long shopServiceId) {
        this.shopServiceId = shopServiceId;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public Float getLat() {
        return lat;
    }

    public void setLat(Float lat) {
        this.lat = lat;
    }

    public Float getLon() {
        return lon;
    }

    public void setLon(Float lon) {
        this.lon = lon;
    }

    public int getRating() {
        return rating;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }

    public String getReview() {
        return review;
    }

    public void setReview(String review) {
        this.review = review;
    }
}
