/**
 *
 */
package com.john.appo.entity.repository;

import com.john.appo.entity.Admin;
import com.john.appo.enums.UserType;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * @author nakesh
 */
public interface AdminRepository extends JpaRepository<Admin, Long> {
    Admin findByEmail(String email);

    Admin findByEmailAndPassword(String email, String password);

    Page<Admin> findByUserType(UserType admin, Pageable page);
}
