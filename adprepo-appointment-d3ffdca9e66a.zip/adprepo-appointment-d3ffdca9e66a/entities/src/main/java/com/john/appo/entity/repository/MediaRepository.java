/**
 *
 */
package com.john.appo.entity.repository;

import com.john.appo.entity.Media;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

/**
 * @author nakesh
 */
public interface MediaRepository extends JpaRepository<Media, Long> {

    List<Media> findByShopIdAndShopServiceIdAndGeneratedNameIn(Long shopId, Long shopServiceId, List<String> fileNames);

    List<Media> findByShopIdAndGeneratedNameIn(Long shopId, List<String> fileNames);

}
