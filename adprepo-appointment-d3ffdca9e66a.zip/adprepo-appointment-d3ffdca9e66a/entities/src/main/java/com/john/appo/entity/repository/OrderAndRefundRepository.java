package com.john.appo.entity.repository;

import com.john.appo.entity.OrderAndRefund;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * @author krishna.kumar
 */
public interface OrderAndRefundRepository extends JpaRepository<OrderAndRefund, String> {
}
