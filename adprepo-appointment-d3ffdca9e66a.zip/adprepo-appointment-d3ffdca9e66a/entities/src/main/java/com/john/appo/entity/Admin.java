/**
 *
 */
package com.john.appo.entity;

import com.john.appo.constants.C;
import com.john.appo.enums.Sex;
import com.john.appo.enums.UserType;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;

/**
 * @author nakesh
 * @implNote This class holds the data for persistent of shop user(i.e. named as Admin) and app admin (i.e. named as Super Admin)
 */
@Entity
@Table(name = C.E_ADMIN)
public class Admin extends AuditedEntity {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.TABLE, generator = "enhanced_table_seq_gen")
    @GenericGenerator(name = "enhanced_table_seq_gen", strategy = "org.hibernate.id.enhanced.TableGenerator",
            parameters = {
                    @org.hibernate.annotations.Parameter(name = "table_name", value = "lib_sequences"),
                    @org.hibernate.annotations.Parameter(name = "segment_column_name", value = "name"),
                    @org.hibernate.annotations.Parameter(name = "segment_value", value = "admin_seq"),
                    @org.hibernate.annotations.Parameter(name = "value_column_name", value = "next_val")})
    private Long id;

    private String name;
    private String email;
    private String password;
    private String mobile;
    @Enumerated(EnumType.STRING)
    @Column(name = "user_type")
    private UserType userType;
    @Enumerated(EnumType.STRING)
    private Sex sex;
    @Column(name = "pro_image")
    private String proImage;
    private String roles;
    private String otp;
    private Float lat;
    private Float lon;
    private boolean active;
    private boolean approved;

    public Admin() {

    }

    public Admin(String name, String email, String password, String mobile, UserType userType, Sex sex, String proImage,
                 String roles, String otp, Float lat, Float lon, boolean active, boolean approved) {
        super();
        this.name = name;
        this.email = email;
        this.password = password;
        this.mobile = mobile;
        this.userType = userType;
        this.sex = sex;
        this.proImage = proImage;
        this.roles = roles;
        this.otp = otp;
        this.lat = lat;
        this.lon = lon;
        this.active = active;
        this.approved = approved;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Float getLat() {
        return lat;
    }

    public void setLat(Float lat) {
        this.lat = lat;
    }

    public Float getLon() {
        return lon;
    }

    public void setLon(Float lon) {
        this.lon = lon;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public UserType getUserType() {
        return userType;
    }

    public void setUserType(UserType userType) {
        this.userType = userType;
    }

    public Sex getSex() {
        return sex;
    }

    public void setSex(Sex sex) {
        this.sex = sex;
    }

    public String getProImage() {
        return proImage;
    }

    public void setProImage(String proImage) {
        this.proImage = proImage;
    }

    public String getRoles() {
        return roles;
    }

    public void setRoles(String roles) {
        this.roles = roles;
    }

    public String getOtp() {
        return otp;
    }

    public void setOtp(String otp) {
        this.otp = otp;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public boolean isApproved() {
        return approved;
    }

    public void setApproved(boolean approved) {
        this.approved = approved;
    }
}
