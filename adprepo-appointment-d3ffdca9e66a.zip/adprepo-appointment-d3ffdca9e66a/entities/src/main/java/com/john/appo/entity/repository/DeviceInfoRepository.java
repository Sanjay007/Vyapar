package com.john.appo.entity.repository;

import com.john.appo.entity.DeviceInfo;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * @author Krishna
 */
public interface DeviceInfoRepository extends JpaRepository<DeviceInfo, Long> {
}
