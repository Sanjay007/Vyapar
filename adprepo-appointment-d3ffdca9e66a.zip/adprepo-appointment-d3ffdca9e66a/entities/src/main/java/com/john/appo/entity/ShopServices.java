/**
 *
 */
package com.john.appo.entity;

import com.john.appo.constants.C;
import com.john.appo.entity.utils.StringListConverter;
import org.hibernate.annotations.GenericGenerator;

import javax.persistence.*;
import java.util.List;

/**
 * @author nakesh
 */
@Entity
@Table(name = C.E_SHOP_SERVICES)
public class ShopServices extends AuditedEntity {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.TABLE, generator = "enhanced_table_seq_gen")
    @GenericGenerator(name = "enhanced_table_seq_gen", strategy = "org.hibernate.id.enhanced.TableGenerator",
            parameters = {
                    @org.hibernate.annotations.Parameter(name = "table_name", value = "lib_sequences"),
                    @org.hibernate.annotations.Parameter(name = "segment_column_name", value = "name"),
                    @org.hibernate.annotations.Parameter(name = "segment_value", value = "shop_services_seq"),
                    @org.hibernate.annotations.Parameter(name = "value_column_name", value = "next_val")})
    private Long id;

    @Column(name = "shop_owner_id")
    private Long shopOwnerId;
    @Column(name = "shop_id")
    private Long shopId;
    @Column(name = "cat_id")
    private Long catId;
    @Column(name = "sub_cat_id")
    private Long subCatId;
    private String name;
    @Column(name = "serving_person_name")
    private String servingPersonName;
    private String description;
    private Float lat;
    private Float lon;
    @Column(name = "act_price")
    private Double actPrice; // actualPrice
    @Column(name = "dis_flat")
    private Double disFlat; // discountFlat
    @Column(name = "dis_percent")
    private Integer disPercent;// discountPercentage
    @Column(name = "working_days")
    private String workingDays; // comma separated days
    @Column(name = "avg_time")
    private int avgTime;
    @Column(name = "max_seat")
    private int maxSeat;
    @Column(name = "start_time")
    private int startTime; // in minutes (24 hrs time frame)
    @Column(name = "end_time")
    private int endTime; // in minutes (24 hrs time frame)
    @Column(name = "break_time")
    private int breakTime; // in minutes (24 hrs time frame)
    @Column(name = "break_duration")
    private int breakDuration; // in minutes (24 hrs time frame)
    @Column(name = "wknd_start_time")
    private int wkndStartTime; // weekendStartTime
    @Column(name = "wknd_end_time")
    private int wkndEndTime; // weekendEndTime
    @Column(name = "wknd_act_price")
    private Double wkndActPrice; // weekendActualTime
    private int pinCode;
    private Float rating;
    private boolean active;
    private boolean approved;
    @Convert(converter = StringListConverter.class)
    private List<String> files;

    @Transient
    private Double distance;

    public ShopServices() {

    }

    public ShopServices(Long id, Long shopId, Long catId, Long subCatId, String name, String servingPersonName, String description, Float lat,
                        Float lon, Double actPrice, Double disFlat, Integer disPercent, String workingDays, int avgTime,
                        int maxSeat, int startTime, int endTime, int breakTime, int breakDuration, Float rating, List<String> files, Double distance) {
        this.id = id;
        this.shopId = shopId;
        this.catId = catId;
        this.subCatId = subCatId;
        this.name = name;
        this.servingPersonName = servingPersonName;
        this.description = description;
        this.lat = lat;
        this.lon = lon;
        this.actPrice = actPrice;
        this.disFlat = disFlat;
        this.disPercent = disPercent;
        this.workingDays = workingDays;
        this.avgTime = avgTime;
        this.maxSeat = maxSeat;
        this.startTime = startTime;
        this.endTime = endTime;
        this.breakTime = breakTime;
        this.breakDuration = breakDuration;
        this.rating = rating;
        this.files = files;
        this.distance = distance;
    }

    public ShopServices(Long id, Long shopId, Long catId, Long subCatId, String name, String servingPersonName, String description, Float lat,
                        Float lon, Double actPrice, Double disFlat, Integer disPercent, String workingDays, int avgTime,
                        int maxSeat, int startTime, int endTime, int breakTime, int breakDuration, Float rating) {
        this.id = id;
        this.shopId = shopId;
        this.catId = catId;
        this.subCatId = subCatId;
        this.name = name;
        this.servingPersonName = servingPersonName;
        this.description = description;
        this.lat = lat;
        this.lon = lon;
        this.actPrice = actPrice;
        this.disFlat = disFlat;
        this.disPercent = disPercent;
        this.workingDays = workingDays;
        this.avgTime = avgTime;
        this.maxSeat = maxSeat;
        this.startTime = startTime;
        this.endTime = endTime;
        this.breakTime = breakTime;
        this.breakDuration = breakDuration;
        this.rating = rating;
    }

    public ShopServices(Long shopOwnerId, Long shopId, Long catId, Long subCatId, String name, String servingPersonName, String description, Float lat,
                        Float lon, Double actPrice, Double disFlat, Integer disPercent, String workingDays, int avgTime,
                        int maxSeat, int startTime, int endTime, int breakTime, int breakDuration, int pinCode, Float rating, boolean active, boolean approved) {
        super();
        this.shopOwnerId = shopOwnerId;
        this.shopId = shopId;
        this.catId = catId;
        this.subCatId = subCatId;
        this.name = name;
        this.servingPersonName = servingPersonName;
        this.description = description;
        this.lat = lat;
        this.lon = lon;
        this.actPrice = actPrice;
        this.disFlat = disFlat;
        this.disPercent = disPercent;
        this.workingDays = workingDays;
        this.avgTime = avgTime;
        this.maxSeat = maxSeat;
        this.startTime = startTime;
        this.endTime = endTime;
        this.breakTime = breakTime;
        this.breakDuration = breakDuration;
        this.pinCode = pinCode;
        this.rating = rating;
        this.active = active;
        this.approved = approved;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public List<String> getFiles() {
        return files;
    }

    public void setFiles(List<String> files) {
        this.files = files;
    }

    public int getPinCode() {
        return pinCode;
    }

    public void setPinCode(int pinCode) {
        this.pinCode = pinCode;
    }

    public Double getDistance() {
        return distance;
    }

    public void setDistance(Double distance) {
        this.distance = distance;
    }

    public String getServingPersonName() {
        return servingPersonName;
    }

    public void setServingPersonName(String servingPersonName) {
        this.servingPersonName = servingPersonName;
    }

    public Float getRating() {
        return rating;
    }

    public void setRating(Float rating) {
        this.rating = rating;
    }

    public Float getLat() {
        return lat;
    }

    public void setLat(Float lat) {
        this.lat = lat;
    }

    public Float getLon() {
        return lon;
    }

    public void setLon(Float lon) {
        this.lon = lon;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Long getShopOwnerId() {
        return shopOwnerId;
    }

    public void setShopOwnerId(Long shopOwnerId) {
        this.shopOwnerId = shopOwnerId;
    }

    public Long getShopId() {
        return shopId;
    }

    public void setShopId(Long shopId) {
        this.shopId = shopId;
    }

    public Long getCatId() {
        return catId;
    }

    public void setCatId(Long catId) {
        this.catId = catId;
    }

    public Long getSubCatId() {
        return subCatId;
    }

    public void setSubCatId(Long subCatId) {
        this.subCatId = subCatId;
    }

    public Double getActPrice() {
        return actPrice;
    }

    public void setActPrice(Double actPrice) {
        this.actPrice = actPrice;
    }

    public Double getDisFlat() {
        return disFlat;
    }

    public void setDisFlat(Double disFlat) {
        this.disFlat = disFlat;
    }

    public Integer getDisPercent() {
        return disPercent;
    }

    public void setDisPercent(Integer disPercent) {
        this.disPercent = disPercent;
    }

    public void setDisPercent(int disPercent) {
        this.disPercent = disPercent;
    }

    public String getWorkingDays() {
        return workingDays;
    }

    public void setWorkingDays(String workingDays) {
        this.workingDays = workingDays;
    }

    public int getAvgTime() {
        return avgTime;
    }

    public void setAvgTime(int avgTime) {
        this.avgTime = avgTime;
    }

    public int getMaxSeat() {
        return maxSeat;
    }

    public void setMaxSeat(int maxSeat) {
        this.maxSeat = maxSeat;
    }

    public void setMaxSeat(Integer maxSeat) {
        this.maxSeat = maxSeat;
    }

    public int getStartTime() {
        return startTime;
    }

    public void setStartTime(int startTime) {
        this.startTime = startTime;
    }

    public int getEndTime() {
        return endTime;
    }

    public void setEndTime(int endTime) {
        this.endTime = endTime;
    }

    public int getBreakTime() {
        return breakTime;
    }

    public void setBreakTime(int breakTime) {
        this.breakTime = breakTime;
    }

    public int getBreakDuration() {
        return breakDuration;
    }

    public void setBreakDuration(int breakDuration) {
        this.breakDuration = breakDuration;
    }

    public int getWkndStartTime() {
        return wkndStartTime;
    }

    public void setWkndStartTime(int wkndStartTime) {
        this.wkndStartTime = wkndStartTime;
    }

    public int getWkndEndTime() {
        return wkndEndTime;
    }

    public void setWkndEndTime(int wkndEndTime) {
        this.wkndEndTime = wkndEndTime;
    }

    public Double getWkndActPrice() {
        return wkndActPrice;
    }

    public void setWkndActPrice(Double wkndActPrice) {
        this.wkndActPrice = wkndActPrice;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public boolean isApproved() {
        return approved;
    }

    public void setApproved(boolean approved) {
        this.approved = approved;
    }

    @Override
    public String toString() {
        return "ShopServices [getId()=" + getId() + ", distance=" + distance + ", shopId=" + shopId + ", catId=" + catId + ", subCatId=" + subCatId + ", lat=" + lat
                + ", lon=" + lon + ", avgTime=" + avgTime + ", startTime=" + startTime + ", endTime=" + endTime
                + ", rating=" + rating + ", files=" + files + "]";
    }


}
