/**
 *
 */
package com.john.appo.entity.repository;

import com.john.appo.entity.ShopServices;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

/**
 * @author nakesh
 */
public interface ShopServicesRepository extends JpaRepository<ShopServices, Long> {
    static final String HAVERSINE_PART = "(6371 * acos(cos(radians(:latitude)) * cos(radians(e.lat)) * cos(radians(e.lon) - radians(:longitude)) + sin(radians(:latitude)) * sin(radians(e.lat))))";

    List<ShopServices> findBySubCatIdAndLatAndLon(Long subCatId, Float lat, Float lon);

    List<ShopServices> findByShopIdOrderByRatingDesc(Long shopId);

    List<ShopServices> findBySubCatId(Long subCatId);

    //List<ShopServices> findByUserId(Long userId);
    List<ShopServices> findByShopOwnerId(Long shopOwnerId);

    List<ShopServices> findByLat(Float duration);

    List<ShopServices> findByName(String name);

    Page<ShopServices> findBySubCatIdAndPinCodeOrderByRatingDesc(Long subCatId, int pinCode, Pageable pageable);

    @Query("SELECT new com.john.appo.entity.ShopServices(id, shopId, catId, subCatId, name, servingPersonName, description, lat, lon, actPrice, disFlat, disPercent, workingDays, "
            + "avgTime, maxSeat, startTime, endTime, breakTime, breakDuration, rating, files, " + HAVERSINE_PART + " as distance) "
            + "FROM ShopServices e WHERE subCatId = :subCatId AND " + HAVERSINE_PART + " <= :dist ORDER BY rating DESC, " + HAVERSINE_PART + " ASC")
    Page<ShopServices> findServicesBySubCatAndLocationAndDistance(@Param("subCatId") final Long subCatId, @Param("latitude") final float latitude, @Param("longitude") final float longitude, @Param("dist") Double dist, Pageable pageable);

	List<ShopServices> findByShopId(Long shopId);

}