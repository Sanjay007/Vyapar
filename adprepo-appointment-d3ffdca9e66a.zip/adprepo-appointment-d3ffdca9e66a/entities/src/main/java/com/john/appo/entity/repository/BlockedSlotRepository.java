/**
 * 
 */
package com.john.appo.entity.repository;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.john.appo.entity.BlockedSlot;

/**
 * @author nakesh
 *
 */
public interface BlockedSlotRepository extends JpaRepository<BlockedSlot, Long>{

	List<BlockedSlot> findByShopServiceIdInAndDateAfter(List<Long> shopServiceId, LocalDate now);
	
}
