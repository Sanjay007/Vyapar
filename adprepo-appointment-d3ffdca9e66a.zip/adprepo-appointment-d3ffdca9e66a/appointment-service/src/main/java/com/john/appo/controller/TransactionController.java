package com.john.appo.controller;

import com.john.appo.constants.C;
import com.john.appo.output.ApiResponse;
import com.john.appo.transactions.services.TransactionService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author krishna.kumar
 */
@RestController
@RequestMapping(value = C.TRANSACTION, consumes = {MediaType.APPLICATION_JSON_VALUE}, produces = {MediaType.APPLICATION_JSON_VALUE})
public class TransactionController {
    private static final Logger logger = LoggerFactory.getLogger(TransactionController.class);

    @Autowired
    TransactionService transactionService;

    @RequestMapping(value = C.SAVE, method = RequestMethod.GET)
    public ApiResponse savePayment(@RequestParam String paymentId, @RequestParam String bookingId) {
        logger.info("user having 'USER' role can access this method");
        return transactionService.savePayment(paymentId, bookingId);
    }

    @RequestMapping(value = C.GET, method = RequestMethod.GET)
    public ApiResponse getPayment(@RequestParam String paymentId) {
        logger.info("user having 'USER' role can access this method");
        return transactionService.getPayment(paymentId);
    }

    @RequestMapping(value = C.ALL, method = RequestMethod.GET)
    public ApiResponse getAllPayments() {
        logger.info("user having 'USER' role can access this method");
        return transactionService.getAllPayments();
    }

    @RequestMapping(value = C.REFUND, method = RequestMethod.GET)
    public ApiResponse refundForPayment(@RequestParam String paymentId, @RequestParam String bookingId, @RequestParam long refundAmountInRs){
        logger.info("user having 'USER' role can access this method");
        return transactionService.refundForPayment(paymentId, bookingId, refundAmountInRs);
    }
}
