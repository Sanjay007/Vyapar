/**
 *
 */
package com.john.appo.service.Impl;

import com.john.appo.entity.Category;
import com.john.appo.entity.SubCategory;
import com.john.appo.entity.repository.CategoryRepository;
import com.john.appo.entity.repository.SubCategoryRepository;
import com.john.appo.enums.ErrorCode;
import com.john.appo.input.CategorySubCategoryInput;
import com.john.appo.output.ApiResponse;
import com.john.appo.output.CategorySubCategoryOutput;
import com.john.appo.output.SubCategoryModel;
import com.john.appo.service.SubCategoryService;
import org.apache.maven.shared.utils.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;


/**
 * @author nakesh
 */
@Service
public class SubCategoryServiceImpl implements SubCategoryService {

    @Autowired
    SubCategoryRepository subCategoryRepository;
    @Autowired
    CategoryRepository categoryRepository;

    @Override
    public ApiResponse create(CategorySubCategoryInput input) {
        if (input.getCatId() == null || input.getNames() == null || input.getNames().isEmpty()) {
            return new ApiResponse(ErrorCode.INPUT_PARAM_NOT_CORRECT);
        }
        List<SubCategory> subCategories = new ArrayList<>();
        for (String subCatName : input.getNames()) {
            SubCategory subCategory = new SubCategory();
            subCategory.setCatId(input.getCatId());
            subCategory.setName(subCatName);
            subCategories.add(subCategory);
        }
        subCategoryRepository.save(subCategories);
        // Todo : send notification to all device to get update of categorySubCategoryList

        // return all category subCategory list
        return getAllCatSubCategories();
    }

    @Override
    public ApiResponse update(CategorySubCategoryInput input) {
        if (input.getSubCatId() == null || StringUtils.isBlank(input.getName())) {
            return new ApiResponse(ErrorCode.INPUT_PARAM_NOT_CORRECT);
        }
        SubCategory subCategory = subCategoryRepository.findOne(input.getSubCatId());
        if (subCategory == null) {
            return new ApiResponse(ErrorCode.SUB_CATEGORY_NOT_FOUND);
        }
        subCategory.setName(input.getName());
        subCategoryRepository.save(subCategory);
        // Todo : send notification to all device to get update of categorySubCategoryList

        // return all category subCategory list
        return getAllCatSubCategories();
    }

    @Override
    public ApiResponse delete(Long id) {
        subCategoryRepository.delete(id);
        // Todo : send notification to all device to get update of categorySubCategoryList

        // return all category subCategory list
        return getAllCatSubCategories();
    }

    @Override
    public ApiResponse getAllCatSubCategories() {
        List<Category> categories = categoryRepository.findAll();
        List<Long> categoryIds = categories.stream().map(Category::getId).collect(Collectors.toList());
        List<SubCategory> subCategories = subCategoryRepository.findByCatIdIn(categoryIds);
        Map<Long, List<SubCategoryModel>> catIdSubCategoriesMap = getCatIdSubCategoryMap(subCategories);
        return new ApiResponse(catSubCategories(categories, catIdSubCategoriesMap));
    }

    private Map<Long, List<SubCategoryModel>> getCatIdSubCategoryMap(List<SubCategory> subCategories) {
        Map<Long, List<SubCategoryModel>> catIdSubCategoriesMap = new HashMap<>();
        for (SubCategory subCategory : subCategories) {
            if (catIdSubCategoriesMap.containsKey(subCategory.getCatId())) {
                SubCategoryModel scm = new SubCategoryModel();
                BeanUtils.copyProperties(subCategory, scm);
                catIdSubCategoriesMap.get(subCategory.getCatId()).add(scm);
            } else {
                List<SubCategoryModel> SubCategoryModels = new ArrayList<>();
                SubCategoryModel scm = new SubCategoryModel();
                BeanUtils.copyProperties(subCategory, scm);
                SubCategoryModels.add(scm);
                catIdSubCategoriesMap.put(subCategory.getCatId(), SubCategoryModels);
            }
        }
        return catIdSubCategoriesMap;
    }

    private List<CategorySubCategoryOutput> catSubCategories(List<Category> categories,
                                                             Map<Long, List<SubCategoryModel>> catIdSubCategoriesMap) {
        List<CategorySubCategoryOutput> catSubCatOutputs = new ArrayList<>();
        for (Category category : categories) {
            CategorySubCategoryOutput catSubCatOutput = new CategorySubCategoryOutput();
            catSubCatOutput.setId(category.getId());
            catSubCatOutput.setCatName(category.getName());
            catSubCatOutput.setSubCategories(catIdSubCategoriesMap.get(category.getId()));
            catSubCatOutputs.add(catSubCatOutput);
        }
        return catSubCatOutputs;
    }
}
