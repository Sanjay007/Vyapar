/**
 *
 */
package com.john.appo.controller;

import com.john.appo.constants.C;
import com.john.appo.entity.repository.ShopServicesRepository;
import com.john.appo.output.ApiResponse;
import com.john.appo.service.ListingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDate;

/**
 * @author nakesh
 */
@RestController
@RequestMapping(value = C.LISTING, consumes = {MediaType.APPLICATION_JSON_VALUE}, produces = {MediaType.APPLICATION_JSON_VALUE})
public class ListingController {

    @Autowired
    ListingService listingService;
    @Autowired
    ShopServicesRepository ssr;

    @RequestMapping(method = RequestMethod.GET)
    public ApiResponse listing(@RequestParam(required = true) Long subcatid, @RequestParam(required = false) Float lat,
                               @RequestParam(required = false) Float lon, @RequestParam(required = false) Integer pincode, @RequestParam(required = false) Double distance,
                               @RequestParam LocalDate date, Pageable pageable) {
        return listingService.listing(subcatid, lat, lon, pincode, distance, date, pageable);
    }

    @RequestMapping(value = C.SHOPS_FOR_SUB_CAT, method = RequestMethod.GET)
    public ApiResponse getShopsForSubCategory(@RequestParam(required = true) Long subcatid, @RequestParam(required = false) Float lat,
                                              @RequestParam(required = false) Float lon, @RequestParam(required = false) Integer pincode,
                                              @RequestParam(required = false) Double distance, Pageable pageable) {
        return listingService.getShopsForSubCategory(subcatid, lat, lon, pincode, distance, pageable);
    }

    @RequestMapping(value = C.SERVICES_FOR_SHOP_ID, method = RequestMethod.GET)
    public ApiResponse getServicesForShopId(@RequestParam(required = true) Long shopid) {
        return listingService.getServicesForShopId_2(shopid);
    }

    @RequestMapping(value = C.SLOTS_FOR_SERVICES, method = RequestMethod.GET)
    public ApiResponse getAvailableSlotsForService(@RequestParam Long serviceid, @RequestParam LocalDate date) {
        return listingService.getAvailableSlotsForService(serviceid, date);
    }
}
