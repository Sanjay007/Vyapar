/**
 * 
 */
package com.john.appo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.john.appo.constants.C;
import com.john.appo.constants.Roles;
import com.john.appo.input.BlockSlotInput;
import com.john.appo.output.ApiResponse;
import com.john.appo.service.BlockSlotService;

/**
 * @author nakesh
 *
 */
@RestController
@RequestMapping(value = C.BLOCK_SLOT, consumes = {MediaType.APPLICATION_JSON_VALUE}, produces = {
        MediaType.APPLICATION_JSON_VALUE})
public class BlockSlotController {
	
	@Autowired BlockSlotService blockSlotService;
	
	 @RequestMapping(method = RequestMethod.POST)
	 @Secured({Roles.ROLE_ADMIN_UPDATE, Roles.ROLE_SUPER_ADMIN})
	 public ApiResponse blockSlot(@RequestBody BlockSlotInput input) {
	      return blockSlotService.blockSlot(input);
	 }
}
