package com.john.appo.service.Impl;

import com.john.appo.entity.ServiceSlotBooking;
import com.john.appo.entity.repository.ServiceSlotBookingRepository;
import com.john.appo.service.ServiceSlotBookingService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

/**
 * @author Krishna
 */
@Service
public class ServiceSlotBookingServiceImpl implements ServiceSlotBookingService {
    private static final Logger logger = LoggerFactory.getLogger(ServiceSlotBookingServiceImpl.class);

    @Autowired
    ServiceSlotBookingRepository serviceSlotBookingRepository;

    @Override
    public List<ServiceSlotBooking> getBookingList(List<Long> shopIds, LocalDate serviceDate) {
        List<ServiceSlotBooking> serviceSlotBookings = null;
        if (serviceDate != null) {
            serviceSlotBookings = serviceSlotBookingRepository.findByShopIdInAndServiceDate(shopIds, serviceDate);
        } else {
            serviceSlotBookings = serviceSlotBookingRepository.findByShopIdIn(shopIds);
        }
        return serviceSlotBookings;
    }
}
