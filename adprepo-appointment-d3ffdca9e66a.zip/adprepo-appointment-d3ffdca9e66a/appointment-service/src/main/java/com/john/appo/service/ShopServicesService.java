package com.john.appo.service;


import org.springframework.data.domain.Pageable;

import com.john.appo.input.ShopServicesInput;
import com.john.appo.output.ApiResponse;

public interface ShopServicesService {

    ApiResponse create(ShopServicesInput input);

    ApiResponse update(ShopServicesInput input);

    ApiResponse delete(Long id);

    ApiResponse get(Long id);

    ApiResponse get(Pageable pageable);

    ApiResponse validateInput(ShopServicesInput input);

}
