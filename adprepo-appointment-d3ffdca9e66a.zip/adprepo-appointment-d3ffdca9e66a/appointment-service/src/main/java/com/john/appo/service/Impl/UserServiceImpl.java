/**
 *
 */
package com.john.appo.service.Impl;

import com.john.appo.constants.C;
import com.john.appo.constants.Roles;
import com.john.appo.entity.User;
import com.john.appo.entity.repository.UserRepository;
import com.john.appo.enums.ErrorCode;
import com.john.appo.enums.Status;
import com.john.appo.enums.TimeZoneList;
import com.john.appo.enums.UserType;
import com.john.appo.input.LoginInput;
import com.john.appo.input.UserInput;
import com.john.appo.output.ApiResponse;
import com.john.appo.output.PageableResponse;
import com.john.appo.output.ShopOutput;
import com.john.appo.output.UserOutput;
import com.john.appo.service.UserService;
import com.john.appo.utils.UniqueIdGenerator;
import com.john.appo.security.Role;
import com.john.appo.security.service.AuthenticationService;
import org.apache.maven.shared.utils.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.List;

/**
 * @author nakesh
 */
@Service
public class UserServiceImpl implements UserService {

    private static final Logger logger = LoggerFactory.getLogger(UserServiceImpl.class);
    @Autowired
    AuthenticationService authService;
    @Autowired
    UserRepository userRepository;

    @Override
    public ApiResponse create(UserInput input) {
        ApiResponse response = validate(input);
        if (!response.isSuccess()) {
            return response;
        }
        User user = new User();
        BeanUtils.copyProperties(input, user);
        user.setUserType(UserType.USER);
        user.setRoles(Roles.ROLE_USER);
        user = userRepository.save(user);
        String token = authService.createToken(user.getId(), C.APP_NAME, user.getUserType(), Roles.ROLE_USER);
        logger.info("created user with id- {}, userType- {}, role- {}", new Object[]{user.getId(), user.getUserType(), Roles.ROLE_USER});
        UserOutput output = new UserOutput();
        BeanUtils.copyProperties(user, output);
        output.setAuthToken(token);
        response.setData(output);
        return response;
    }

    @Override
    public ApiResponse registerUser(UserInput input) {
        ApiResponse resp = validateSignupRequest(input);
        //	BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
        if (resp.isSuccess()) {
            User account = new User();
            if (!StringUtils.isEmpty(input.getSocialId())) {
                // Check if Already Account Exist with same SocialId
                User account1 = userRepository.findByFbIdOrTwitterIdOrGoogleId(input.getSocialId(),
                        input.getSocialId(), input.getSocialId());
                if (account1 != null) {
                    logger.info("Social Existing acount found for the user Loggin in to the account");
                    if (input.getDevice() != null && input.getDevice() != account1.getDevice()) {
                        account1.setDevice(input.getDevice());
                    }
                    account1.setLastLoginTime(LocalDateTime.now(ZoneId.of(TimeZoneList.IST.getZoneId())));
                    userRepository.save(account1);
                    return loginUserAndReturnProfileDtsl(account1);
                }
                // No Matching Profile Found
                logger.info("Creating Only Social Account for SocialType " + input.getSocialAccountType());
                // Anonymous user linking first Time ==> Anonymous User --> Registered User
                // Conversion
                ApiResponse response = validateSocialAccountId(input);
                if (!response.isSuccess()) {
                    return response;
                }
                if (StringUtils.isNotBlank(input.getEmail())) {
                    account = userRepository.findByEmail(input.getEmail());
                    if (account == null && input.getId() != null) {
                        account = userRepository.findOne(input.getId());
                    }
                } else if (input.getId() != null) {        // if email is blank then link socialId with existing account id (of anonymous user)
                    account = userRepository.findOne(input.getId());
                }
                if (account == null) {
                    account = new User();// No Anonymous User Found: Should not happen
                }

                setSocialId(account, input);

                account.setEmail(input.getEmail());
                account.setStatus(Status.APPROVED);
                account.setName(input.getName());
                account.setCreatedBy(input.getEmail());
                account.setUserType(UserType.USER);
                account.setRoles(Role.ROLE_USER.name());
                account.setDevice(input.getDevice());
                account.setLastLoginTime(LocalDateTime.now(ZoneId.of(TimeZoneList.IST.getZoneId())));
                account = userRepository.save(account);
                return loginUserAndReturnProfileDtsl(account);
            } else {
                // Anonymous user linking first Time ==> Anonymous User --> Registered User
                // Conversion
                if (StringUtils.isNotBlank(input.getEmail())) {
                    account = userRepository.findByEmail(input.getEmail());
                    if (account != null) {
                        if (account.getStatus() == Status.APPROVED) {                // user already exist with status=APPROVED, in case of status=APPROVED user must login with valid password
                            return new ApiResponse(ErrorCode.EMAIL_ID_EXIST, input.getEmail());
                        }
                    } else if (input.getId() != null) {
                        account = userRepository.findOne(input.getId());
                    }
                }
                if (account == null)
                    account = new User();// No Anonymous User Found: Should not happen

                BeanUtils.copyProperties(input, account);
                account.setOtp(UniqueIdGenerator.getOtp());
                account.setStatus(Status.APPROVED);
                account.setCreatedBy(input.getEmail());
                account.setUserType(UserType.USER);
                account.setRoles(Role.ROLE_USER.name());

                account = userRepository.save(account);
                UserOutput opt = new UserOutput();
                opt.setId(account.getId());
                return new ApiResponse(opt);
            }
        } else
            return resp;
    }

    private ApiResponse validateSocialAccountId(UserInput input) {
        switch (input.getSocialAccountType()) {
            case FB:
                // validate fb account
                break;
            case GOOGLE:
                // validate google account
                break;
            case TWITTER:
                // validate twitter account
                break;
            default:
                logger.info("SignUp Request with Invalid Social Type : " + input.getSocialAccountType());
                return new ApiResponse(ErrorCode.INVALID_SOCIAL_MEDIA_TYPE);
        }
        return new ApiResponse();
    }

    private ApiResponse setSocialId(User account, UserInput input) {
        switch (input.getSocialAccountType()) {
            case FB:
                account.setFbId(input.getSocialId());
                break;
            case GOOGLE:
                account.setGoogleId(input.getSocialId());
                break;
            case TWITTER:
                account.setTwitterId(input.getSocialId());
                break;
            default:
                logger.info("SignUp Request with Invalid Social Type : " + input.getSocialAccountType());
                return new ApiResponse(ErrorCode.INVALID_SOCIAL_MEDIA_TYPE);
        }
        return new ApiResponse();
    }

    private ApiResponse loginUserAndReturnProfileDtsl(User account) {
        if (account == null) {
            return new ApiResponse(ErrorCode.USER_NOT_FOUND);
        }
        if (account.getStatus() != Status.APPROVED) {
            return new ApiResponse(ErrorCode.ACCOUNT_NOT_YET_APPROVED);
        }

        String token = authService.createToken(account.getId(), C.APP_NAME, account.getUserType(), Roles.ROLE_USER);
        ApiResponse response = new ApiResponse();
        UserOutput output = new UserOutput();
        BeanUtils.copyProperties(account, output);
        output.setAuthToken(token);
        response.setData(output);
        return response;
    }

    private ApiResponse validateSignupRequest(UserInput input) {

        if (input.getDevice() == null) {
            return new ApiResponse(ErrorCode.DEVICE_TYPE_SHOULD_NOT_BE_BLANKED);
        }
        if (!StringUtils.isEmpty(input.getSocialId())) {
            return new ApiResponse();
        } else if (StringUtils.isEmpty(input.getEmail())) {
            return new ApiResponse(ErrorCode.USERNAME_MISSING);
        } else if (!input.getPassword().equals(input.getConfirmPassword())) {
            return new ApiResponse(ErrorCode.PASSWORD_AND_CONFIRM_PASSWORD_MISMATCH);
        }
        return new ApiResponse();
    }

    @Override
    public ApiResponse get(Long id) {
        User user = userRepository.findOne(id);
        if (user == null) {
            return new ApiResponse(ErrorCode.USER_NOT_FOUND);
        }
        List<UserOutput> users = new ArrayList<>();
        UserOutput output = new UserOutput();
        BeanUtils.copyProperties(user, output);
        users.add(output);
        return new ApiResponse(new PageableResponse<>(users, C.ONE, C.ZERO, C.ONE, C.ONE));
    }

    @Override
    public ApiResponse get(Pageable page) {
        List<UserOutput> userOutputs = new ArrayList<>();
        Page<User> users = userRepository.findAll(page);
        if (users.getSize() == 0) {
            return new ApiResponse(new PageableResponse<ShopOutput>(new ArrayList<>(), C.ZERO, C.ZERO, C.ZERO, C.ZERO));
        }
        for (User user : users) {
            UserOutput userOutput = new UserOutput();
            BeanUtils.copyProperties(user, userOutput);
            userOutputs.add(userOutput);
        }
        PageableResponse<UserOutput> pageableReponse = new PageableResponse<>(userOutputs, users);
        return new ApiResponse(pageableReponse);
    }

    @Override
    public ApiResponse update(UserInput input) {
        if (input.getId() == null) {
            return new ApiResponse(ErrorCode.INPUT_PARAM_NOT_CORRECT);
        }
        User user = userRepository.findOne(input.getId());
        if (user == null) {
            return new ApiResponse(ErrorCode.USER_NOT_FOUND);
        }
        Boolean update = false;
        // update name
        if (!StringUtils.endsWithIgnoreCase(input.getName(), user.getName())
                && StringUtils.isNotBlank(input.getName())) {
            user.setName(input.getName());
            update = true;
        }
        // update mobile
        if (!StringUtils.equals(input.getMobile(), user.getMobile()) && input.getMobile() != null
                && input.getMobile().toString().length() == C.TEN) {
            user.setMobile(input.getMobile());
            update = true;
        }
        if (update) {
            userRepository.save(user);
        }
        return get(input.getId());
    }

    /*
     * validate user
     * save deviceType and lastLoginTime
     * return result
     */
    @Override
    public ApiResponse login(LoginInput input) {
        if (StringUtils.isBlank(input.getDeviceToken())) {
            return new ApiResponse(ErrorCode.MISSING_DEVICE_TYPE);
        }
        User user = userRepository.findByEmailAndPassword(input.getEmail(), input.getPassword());
        if (user == null) {
            return new ApiResponse(ErrorCode.INVALID_CREDENTIALS);
        }
        String token = authService.createToken(user.getId(), input.getEmail(), user.getUserType(), user.getRoles());

        user.setDeviceToken(input.getDeviceToken());
        user.setLastLoginTime(LocalDateTime.now(ZoneId.of(TimeZoneList.IST.getZoneId())));
        userRepository.save(user);
        logger.info("Successful login for user with id- {}, userType- {}, role- {}", new Object[]{user.getId(), user.getUserType(), user.getRoles()});
        UserOutput output = new UserOutput();
        BeanUtils.copyProperties(user, output);
        output.setAuthToken(token);
        return new ApiResponse(output);
    }


    private ApiResponse validate(UserInput input) {
        User user = userRepository.findByEmail(input.getEmail());
        if (user != null) {
            return new ApiResponse(ErrorCode.EMAIL_ID_EXIST, input.getEmail());
        }
        return new ApiResponse();
    }

    @Override
    public ApiResponse resetPassword(LoginInput input) {
        User user = userRepository.findOne(input.getId());
        if (user == null) {
            return new ApiResponse(ErrorCode.USER_NOT_FOUND);
        }
        user.setPassword(input.getNewPassword());
        userRepository.save(user);
        return new ApiResponse();
    }

    /*
     * update deviceToken to null so that user will not get any notification after logout
     */
    @Override
    public ApiResponse logout(Long userId) {
        User user = userRepository.findOne(userId);
        user.setDeviceToken(null);
        userRepository.save(user);
        return new ApiResponse();
    }

    /*
     * for now returning naked password, later will send password via message or email
     */
    @Override
    public ApiResponse forgot(String email) {
        User user = userRepository.findByEmail(email);
        if (user == null) {
            return new ApiResponse(ErrorCode.USER_NOT_FOUND);
        }
        return new ApiResponse(user.getPassword());
    }
}
