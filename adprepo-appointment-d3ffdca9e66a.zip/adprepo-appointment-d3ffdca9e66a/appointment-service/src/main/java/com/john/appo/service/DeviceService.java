package com.john.appo.service;

import com.john.appo.entity.DeviceInfo;

/**
 * @author Krishna
 */
public interface DeviceService {
    DeviceInfo create(DeviceInfo input);

    DeviceInfo update(DeviceInfo input);

    boolean delete(Long id);

    DeviceInfo get();
}
