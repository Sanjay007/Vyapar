/**
 *
 */
package com.john.appo.exception;

import com.john.appo.enums.ErrorCode;
import com.john.appo.output.ApiResponse;
import com.john.appo.utils.UniqueIdGenerator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.validation.ConstraintViolationException;
import javax.validation.UnexpectedTypeException;

/**
 * @author nakesh
 */
@ControllerAdvice
public class GlobalExceptionHandler {

    private static final Logger logger = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    @ExceptionHandler(value = Exception.class)
    public
    @ResponseBody
    ApiResponse exception(Exception e) {
        String exceptionId = UniqueIdGenerator.getId();
        logger.info("GlobalExceptionHandler Exception caught exception with id : " + exceptionId);
        e.printStackTrace();
        return new ApiResponse(ErrorCode.UNKNOWN_EXCEPTION, exceptionId + " : " + e.getMessage());
    }

    @ExceptionHandler
    public
    @ResponseBody
    ApiResponse handle(MethodArgumentNotValidException exception) {
        exception.printStackTrace();
        logger.info("GlobalExceptionHandler MethodArgumentNotValidException: " + exception.getMessage());
        return new ApiResponse(ErrorCode.GIVEN_INPUT_PARAM_NOT_CORRECT, exception.getMessage());
    }


    @ExceptionHandler
    public
    @ResponseBody
    ApiResponse handle(ConstraintViolationException exception) {
        exception.printStackTrace();
        logger.info("GlobalExceptionHandler ConstraintViolationException: " + exception.getMessage());
        return new ApiResponse(ErrorCode.GIVEN_INPUT_PARAM_NOT_CORRECT, exception.getMessage());
    }

    @ExceptionHandler
    public
    @ResponseBody
    ApiResponse handle(UnexpectedTypeException exception) {
        exception.printStackTrace();
        logger.info("GlobalExceptionHandler UnexpectedTypeException: " + exception.getMessage());
        return new ApiResponse(ErrorCode.GIVEN_INPUT_PARAM_NOT_CORRECT, exception.getMessage());
    }

    @ExceptionHandler
    public
    @ResponseBody
    ApiResponse handle(MissingServletRequestParameterException exception) {
        exception.printStackTrace();
        logger.info("GlobalExceptionHandler MissingServletRequestParameterException: " + exception.getMessage());
        return new ApiResponse(ErrorCode.GIVEN_INPUT_PARAM_NOT_CORRECT, exception.getMessage());
    }
}

