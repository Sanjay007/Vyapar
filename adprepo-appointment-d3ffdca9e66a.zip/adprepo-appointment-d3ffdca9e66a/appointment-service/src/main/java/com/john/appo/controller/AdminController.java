/**
 *
 */
package com.john.appo.controller;

import com.john.appo.constants.C;
import com.john.appo.constants.Roles;
import com.john.appo.input.UserInput;
import com.john.appo.output.ApiResponse;
import com.john.appo.service.AdminService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.MediaType;
import org.springframework.security.access.annotation.Secured;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

/**
 * @author nakesh
 */
@RestController
@RequestMapping(value = C.ADMIN, consumes = {MediaType.APPLICATION_JSON_VALUE}, produces = {
        MediaType.APPLICATION_JSON_VALUE})
public class AdminController {

    private static final Logger logger = LoggerFactory.getLogger(BookingController.class);

    @Autowired
    AdminService adminService;

    @RequestMapping(value = C.CREATE, method = RequestMethod.POST)
    public ApiResponse save(@Valid @RequestBody UserInput input) {
        logger.info("inside AdminController.create()");
        return adminService.create(input);
    }

    @Secured({Roles.ROLE_ADMIN, Roles.ROLE_SUPER_ADMIN})
    @RequestMapping(method = RequestMethod.GET)
    public ApiResponse get(@RequestParam Long id) {
        logger.info("inside AdminController.get()");
        return adminService.get(id);
    }

    @Secured({Roles.ROLE_ADMIN, Roles.ROLE_SUPER_ADMIN})
    @RequestMapping(method = RequestMethod.PUT)
    public ApiResponse update(@RequestBody UserInput input) {
        logger.info("inside AdminController.update()");
        input.setId(Long.parseLong(SecurityContextHolder.getContext().getAuthentication().getName()));
        return adminService.update(input);
    }

    @Secured({Roles.ROLE_SUPER_ADMIN})
    @RequestMapping(value = C.ALL, method = RequestMethod.GET)
    public ApiResponse getAll(Pageable page) {
        logger.info("inside AdminController.getAll()");
        return adminService.get(page);
    }
}

