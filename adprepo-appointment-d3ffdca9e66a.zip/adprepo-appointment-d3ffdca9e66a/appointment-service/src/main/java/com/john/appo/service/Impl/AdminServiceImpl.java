/**
 *
 */
package com.john.appo.service.Impl;

import com.john.appo.constants.C;
import com.john.appo.constants.Roles;
import com.john.appo.entity.Admin;
import com.john.appo.entity.repository.AdminRepository;
import com.john.appo.enums.ErrorCode;
import com.john.appo.enums.UserType;
import com.john.appo.input.LoginInput;
import com.john.appo.input.UserInput;
import com.john.appo.output.ApiResponse;
import com.john.appo.output.PageableResponse;
import com.john.appo.output.ShopOutput;
import com.john.appo.output.UserOutput;
import com.john.appo.service.AdminService;
import com.john.appo.security.service.AuthenticationService;
import org.apache.maven.shared.utils.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * @author nakesh
 */
@Service
public class AdminServiceImpl implements AdminService {

    private static final Logger logger = LoggerFactory.getLogger(UserServiceImpl.class);
    @Autowired
    AuthenticationService authService;
    @Autowired
    AdminRepository adminRepository;

    @Override
    public ApiResponse create(UserInput input) {
        ApiResponse response = validate(input);
        if (!response.isSuccess()) {
            return response;
        }
        Admin admin = new Admin();
        BeanUtils.copyProperties(input, admin);
        admin.setUserType(UserType.ADMIN);
        admin.setRoles(Roles.ROLE_ADMIN);
        admin = adminRepository.save(admin);
        String token = authService.createToken(admin.getId(), C.APP_NAME, UserType.ADMIN, Roles.ROLE_ADMIN);
        logger.info("created shop admin with id- {}, userType- {}, role- {}", new Object[]{admin.getId(), admin.getUserType(), Roles.ROLE_ADMIN});
        UserOutput output = new UserOutput();
        BeanUtils.copyProperties(admin, output);
        output.setAuthToken(token);
        response.setData(output);
        return response;
    }

    @Override
    public ApiResponse get(Long id) {
        Admin admin = adminRepository.findOne(id);
        if (admin == null) {
            return new ApiResponse(ErrorCode.USER_NOT_FOUND);
        }
        List<UserOutput> users = new ArrayList<>();
        UserOutput output = new UserOutput();
        BeanUtils.copyProperties(admin, output);
        users.add(output);
        return new ApiResponse(new PageableResponse<>(users, C.ONE, C.ZERO, C.ONE, C.ONE));
    }

    @Override
    public ApiResponse get(Pageable page) {
        List<UserOutput> userOutputs = new ArrayList<>();
        // return only shop admins not super admin
        Page<Admin> admins = adminRepository.findByUserType(UserType.ADMIN, page);
        if (admins.getSize() == C.ZERO) {
            return new ApiResponse(new PageableResponse<ShopOutput>(new ArrayList<>(), C.ZERO, C.ZERO, C.ZERO, C.ZERO));
        }
        for (Admin admin : admins) {
            UserOutput userOutput = new UserOutput();
            BeanUtils.copyProperties(admin, userOutput);
            userOutputs.add(userOutput);
        }
        PageableResponse<UserOutput> pageableResponse = new PageableResponse<>(userOutputs, admins);
        return new ApiResponse(pageableResponse);
    }

    @Override
    public ApiResponse update(UserInput input) {
        if (input.getId() == null) {
            return new ApiResponse(ErrorCode.INPUT_PARAM_NOT_CORRECT);
        }
        Admin admin = adminRepository.findOne(input.getId());
        if (admin == null) {
            return new ApiResponse(ErrorCode.USER_NOT_FOUND);
        }
        Boolean update = false;
        // update name
        if (!StringUtils.endsWithIgnoreCase(input.getName(), admin.getName())
                && StringUtils.isNotBlank(input.getName())) {
            admin.setName(input.getName());
            update = true;
        }
        // update mobile
        if (!StringUtils.equals(input.getMobile(), admin.getMobile()) && input.getMobile() != null
                && input.getMobile().toString().length() == C.TEN) {
            admin.setMobile(input.getMobile());
            update = true;
        }
        if (update) {
            adminRepository.save(admin);
        }
        return get(input.getId());
    }

    @Override
    public ApiResponse login(LoginInput input) {
        Admin admin = adminRepository.findByEmailAndPassword(input.getEmail(), input.getPassword());
        if (admin == null) {
            return new ApiResponse(ErrorCode.INVALID_CREDENTIALS);
        }
        String token = authService.createToken(admin.getId(), input.getEmail(), admin.getUserType(), admin.getRoles());
        logger.info("Successful login for admin with id- {}, userType- {}, role- {}", new Object[]{admin.getId(), admin.getUserType(), admin.getRoles()});
        UserOutput output = new UserOutput();
        BeanUtils.copyProperties(admin, output);
        if (admin.getRoles().equalsIgnoreCase(Roles.ROLE_SUPER_ADMIN)) {
            output.setUserType(UserType.SUPER);
        }
        output.setAuthToken(token);
        return new ApiResponse(output);
    }

    private ApiResponse validate(UserInput input) {
        Admin admin = adminRepository.findByEmail(input.getEmail());
        if (admin != null) {
            return new ApiResponse(ErrorCode.EMAIL_ID_EXIST, input.getEmail());
        }
        return new ApiResponse();
    }

    @Override
    public ApiResponse resetPassword(LoginInput input) {
        Admin admin = adminRepository.findOne(input.getId());
        if (admin == null) {
            return new ApiResponse(ErrorCode.USER_NOT_FOUND);
        }
        admin.setPassword(input.getNewPassword());
        adminRepository.save(admin);
        return new ApiResponse();
    }


    @Override
    public ApiResponse logout(Long adminId) {
        // TODO do required work
        return new ApiResponse();
    }

    /*
     * for now returning naked password, later will send password via message or email
     */
    @Override
    public ApiResponse forgot(String email) {
        Admin admin = adminRepository.findByEmail(email);
        if (admin == null) {
            return new ApiResponse(ErrorCode.USER_NOT_FOUND);
        }
        return new ApiResponse(admin.getPassword());
    }
}
