package com.john.appo.service.Impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import com.john.appo.security.service.AuthenticationService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.john.appo.constants.C;
import com.john.appo.entity.ShopServices;
import com.john.appo.entity.repository.AdminRepository;
import com.john.appo.entity.repository.CategoryRepository;
import com.john.appo.entity.repository.ShopRepository;
import com.john.appo.entity.repository.ShopServicesRepository;
import com.john.appo.entity.repository.SubCategoryRepository;
import com.john.appo.enums.ErrorCode;
import com.john.appo.enums.WorkingDays;
import com.john.appo.input.ShopServicesInput;
import com.john.appo.output.ApiResponse;
import com.john.appo.output.PageableResponse;
import com.john.appo.output.ShopServicesOutput;
import com.john.appo.service.ShopServicesService;

@Service
public class ShopServicesImpl implements ShopServicesService {

    private static final Logger logger = LoggerFactory.getLogger(ShopServicesImpl.class);

    @Autowired
    ShopServicesRepository shopServiceRepository;
    @Autowired
    AdminRepository adminRepository;
    @Autowired
    ShopRepository shopRepository;
    @Autowired
    CategoryRepository categoryRepository;
    @Autowired
    SubCategoryRepository subCategoryRepository;
    @Autowired
    AuthenticationService authService;

    @Override
    public ApiResponse create(ShopServicesInput input) {

        ApiResponse response = validateInput(input);

        if (!response.isSuccess())
            return response;
        List<ShopServices> shopServiceList = new ArrayList<>();
        int numOfSubCat = input.getSubCatId().size();
        for (int i = 0; i < numOfSubCat; i++) {
            ShopServices shopServices = new ShopServices();
            BeanUtils.copyProperties(input, shopServices);
            shopServices.setSubCatId(input.getSubCatId().get(i));
            shopServiceList.add(shopServices);
            logger.info("created shopServices for shopId-{}, catId-{}", input.getShopId(), input.getSubCatId().get(i));
        }
        shopServiceRepository.save(shopServiceList);
        return response;
    }

    @Override
    public ApiResponse update(ShopServicesInput input) {

        if (null == shopRepository.findOne(input.getShopId()))
            return new ApiResponse(ErrorCode.SHOP_NOT_FOUND);

        if (null == categoryRepository.findOne(input.getCatId()))
            return new ApiResponse(ErrorCode.CATEGORY_NOT_FOUND);

        Boolean update = false;

        ShopServices shopServices = shopServiceRepository.findOne(input.getId());
        if (input.getActPrice() != null && shopServices.getActPrice() != input.getActPrice()) {
            shopServices.setActPrice(input.getActPrice());
            update = true;
        }

        if (input.getDisFlat() != null && shopServices.getDisFlat() != input.getDisFlat()) {
            shopServices.setDisFlat(input.getDisFlat());
            update = true;
        }

        return get(input.getId());

    }

    @Override
    public ApiResponse delete(Long id) {
        ShopServices shopService = shopServiceRepository.findOne(id);
        if (shopService == null)
            return new ApiResponse(ErrorCode.SHOP_SERVICE_NOT_FOUND, id.toString());
        shopServiceRepository.delete(shopService);

        return new ApiResponse();
    }

    @Override
    public ApiResponse get(Long id) {
        ShopServices shopService = shopServiceRepository.findOne(id);
        if (shopService == null)
            return new ApiResponse(ErrorCode.SHOP_SERVICE_NOT_FOUND, id.toString());

        List<ShopServices> shopServiceList = new ArrayList<ShopServices>();
        ShopServicesOutput shopServiceOutput = new ShopServicesOutput();
        BeanUtils.copyProperties(shopService, shopServiceOutput);
        shopServiceList.add(shopService);
        return new ApiResponse(new PageableResponse<>(shopServiceList, C.ONE, C.ZERO, C.ONE, C.ONE));

    }

    @Override
    public ApiResponse validateInput(ShopServicesInput input) {

        if (null == adminRepository.findOne(input.getUserId()))
            return new ApiResponse(ErrorCode.USER_NOT_FOUND);

        if (null == shopRepository.findOne(input.getShopId()))
            return new ApiResponse(ErrorCode.SHOP_NOT_FOUND);

        if (null == categoryRepository.findOne(input.getCatId()))
            return new ApiResponse(ErrorCode.CATEGORY_NOT_FOUND);

        List<Long> subCatList = input.getSubCatId();
        for (Long catId : subCatList) {
            if (null == subCategoryRepository.findOne(catId))
                return new ApiResponse(ErrorCode.SUB_CATEGORY_NOT_FOUND);
        }

        // validate shop maxSeat
        if (!validateMaxSeat(input.getMaxSeat())) {
            return new ApiResponse(ErrorCode.INVALID_MAX_SEAT, input.getWorkingDays());
        }

        // validate shop timings
        if (!validateTimings(input.getStartTime(), input.getEndTime(), input.getBreakTime(), input.getBreakDuration())) {
            return new ApiResponse(ErrorCode.INVALID_TIMINGS);
        }
        // validate working days
        if (!validateWorkingDays(input.getWorkingDays())) {
            return new ApiResponse(ErrorCode.INVALID_WORKING_DAYS, input.getWorkingDays());
        }

        return new ApiResponse();

    }

    private boolean validateMaxSeat(int maxSheet) {
        return maxSheet > C.ZERO && maxSheet < C.TWENTY;
    }

    private boolean validateTimings(int startTime, int endTime, int breakTime, int breakDuration) {
        // valid case : return true
        // invalid case : return false
        return validateStartTime(startTime, endTime)
                && validateEndTime(startTime, endTime)
                && validateBreakTime(startTime, endTime, breakTime)
                && validateBreakDuration(startTime, endTime, breakTime, breakDuration);
    }

    private boolean validateStartTime(int startTime, int endTime) {
        return startTime < endTime && startTime > C.FOUR * C.SIXTY;         // 4*60 = 240 min = 4 hr = 4 o'clock morning
    }

    private boolean validateEndTime(int startTime, int endTime) {
        return startTime < endTime && endTime < C.TWENTY_THREE * C.SIXTY;   // 23*60 = 1380 min = 23 hr = 23 o'clock night;
    }

    private boolean validateBreakTime(int startTime, int endTime, int breakTime) {
        return breakTime > startTime && breakTime < endTime;
    }

    private boolean validateBreakDuration(int startTime, int endTime, int breakTime, int breakDuration) {
        return breakTime != 0 && breakDuration > C.ZERO && breakDuration <= C.THREE && breakDuration < endTime - startTime;
    }

    private boolean validateWorkingDays(String commaSeparatedWorkingDays) {
        List<String> workingDays = Stream.of(WorkingDays.values()).map(WorkingDays::name).collect(Collectors.toList());
        return workingDays.containsAll(Arrays.asList(commaSeparatedWorkingDays.split("\\s*,\\s*")));
    }

    @Override
    public ApiResponse get(Pageable pageable) {

        return null;
    }
}
