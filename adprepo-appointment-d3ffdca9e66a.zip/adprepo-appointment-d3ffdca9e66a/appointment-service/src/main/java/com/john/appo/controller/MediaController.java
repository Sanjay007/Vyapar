/**
 *
 */
package com.john.appo.controller;

import com.john.appo.constants.C;
import com.john.appo.constants.Roles;
import com.john.appo.output.ApiResponse;
import com.john.appo.service.MediaService;
import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
 * @author nakesh
 */
@RestController
@RequestMapping(value = C.MEDIA)
public class MediaController {

    @Autowired
    MediaService mediaService;

    @Secured({Roles.ROLE_ADMIN_WRITE, Roles.ROLE_SUPER_ADMIN})
    @RequestMapping(value = C.UPLOAD + C.SHOP_PIC, method = RequestMethod.POST)
    public ApiResponse uploadShopPics(@RequestParam("files") @NotEmpty MultipartFile[] files, @RequestParam Long shopid,
                                      @RequestParam(required = false) Long serviceid, @RequestParam(required = false) Boolean active) {

        return mediaService.uploadShopPics(files, shopid, serviceid, active,
                Long.parseLong(SecurityContextHolder.getContext().getAuthentication().getName()));
    }

    @Secured({Roles.ROLE_ADMIN_WRITE, Roles.ROLE_USER})
    @RequestMapping(value = C.UPLOAD + C.PROFILE_PIC, method = RequestMethod.POST)
    public ApiResponse uploadProfilePic(@RequestParam("files") @NotEmpty MultipartFile[] files) {

        return mediaService.uploadProfilePic(files);
    }

    @Secured({Roles.ROLE_ADMIN_WRITE, Roles.ROLE_SUPER_ADMIN, Roles.ROLE_USER})
    @RequestMapping(value = C.DOWNLOAD + C.PROFILE_PIC, method = RequestMethod.GET)
    public ApiResponse downloadProfilePic(HttpServletResponse response, @RequestParam String filename) {
        return mediaService.downloadProfilePic(response, filename);
    }

    @Secured({Roles.ROLE_ADMIN_WRITE, Roles.ROLE_SUPER_ADMIN})
    @RequestMapping(value = C.DOWNLOAD + C.SHOP_PIC, method = RequestMethod.GET)
    public ApiResponse downloadShopPics(HttpServletResponse response, @RequestParam String filename) {
        return mediaService.downloadShopPics(response, filename);
    }

    @Secured({Roles.ROLE_ADMIN_WRITE, Roles.ROLE_SUPER_ADMIN})
    @RequestMapping(value = C.SHOP_PIC, method = RequestMethod.DELETE)
    public ApiResponse delete(@RequestParam(required = true) Long shopid, @RequestParam(required = false) Long serviceid,
                              @RequestParam List<String> filenames) {
        return mediaService.delete(shopid, serviceid, filenames);
    }
}
