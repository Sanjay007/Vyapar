/**
 *
 */
package com.john.appo.controller;

import com.john.appo.constants.C;
import com.john.appo.loader.SeedData;
import com.john.appo.output.ApiResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author nakesh
 */
@RestController
@RequestMapping(value = C.SEEDDATA, consumes = {MediaType.APPLICATION_JSON_VALUE}, produces = {MediaType.APPLICATION_JSON_VALUE})
public class SeedDataController {

    @Autowired
    SeedData seedData;

    @RequestMapping(method = RequestMethod.GET)
    public ApiResponse load(@RequestParam int noofshop) {
        return seedData.load(noofshop);
    }

//	@RequestMapping(value = "/load", method= RequestMethod.GET)
//	public ApiResponse loadFromEnum() {
//		return seedData.loadFromEnum();
//	}
}
