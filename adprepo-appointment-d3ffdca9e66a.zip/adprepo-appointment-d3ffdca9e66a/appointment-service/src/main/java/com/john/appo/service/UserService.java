/**
 *
 */
package com.john.appo.service;

import com.john.appo.input.LoginInput;
import com.john.appo.input.UserInput;
import com.john.appo.output.ApiResponse;
import org.springframework.data.domain.Pageable;

/**
 * @author nakesh
 */
public interface UserService {
    ApiResponse create(UserInput input);

    ApiResponse get(Long id);

    ApiResponse get(Pageable page);

    ApiResponse update(UserInput input);

    ApiResponse login(LoginInput input);

    ApiResponse resetPassword(LoginInput input);

    ApiResponse logout(Long userId);

    ApiResponse forgot(String email);

    ApiResponse registerUser(UserInput input);
}