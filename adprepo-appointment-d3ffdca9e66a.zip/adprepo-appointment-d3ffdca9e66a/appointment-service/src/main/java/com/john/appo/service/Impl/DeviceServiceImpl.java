package com.john.appo.service.Impl;

import com.john.appo.entity.DeviceInfo;
import com.john.appo.service.DeviceService;
import org.springframework.stereotype.Service;

/**
 * @author Krishna
 */
@Service
public class DeviceServiceImpl implements DeviceService {
    @Override
    public DeviceInfo create(DeviceInfo input) {
        return null;
    }

    @Override
    public DeviceInfo update(DeviceInfo input) {
        return null;
    }

    @Override
    public boolean delete(Long id) {
        return false;
    }

    @Override
    public DeviceInfo get() {
        return null;
    }
}
