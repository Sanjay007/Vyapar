/**
 *
 */
package com.john.appo.service;


import com.john.appo.input.BlockSlotInput;
import com.john.appo.input.BookingInput;
import com.john.appo.input.ServicesSlotsBookingInput;
import com.john.appo.output.ApiResponse;
import com.john.appo.output.FcmDataOutput;
import com.john.appo.search.BookingSearchCriteria;
import org.springframework.data.domain.Pageable;

import java.util.List;

/**
 * @author Krishna
 */
public interface BookingService {

    //To check and lock available slots : done
    ApiResponse validateAndLockAvailableSlotsForBooking(ServicesSlotsBookingInput input);

    //For final booking : Todo partially done
    ApiResponse book(BookingInput bookingInput);

    //To check slots confirmation status : done
    ApiResponse getSlotsAvailabilityConfStatus(Long userId, String bookingId);

    //To update slot status : done
    ApiResponse updateServicesSlotsBookingStatus(List<FcmDataOutput> dataList);

    //To block slots by shop : done
    ApiResponse blockSlotsReservation(ServicesSlotsBookingInput input);

    //To unblock slots by shop : done
    ApiResponse unblockSlotsReservation(ServicesSlotsBookingInput input);

    //Search : done
    ApiResponse search(BookingSearchCriteria criteria, Pageable pageable);

	void changeStatus(BlockSlotInput input);
}
