package com.john.appo.main;

import com.john.appo.enums.TimeZoneList;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.format.Formatter;
import springfox.documentation.builders.ParameterBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.schema.ModelRef;
import springfox.documentation.service.Parameter;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

import java.text.ParseException;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * @author nakesh
 */

@SpringBootApplication
@EnableSwagger2
@ComponentScan(basePackages = {"com"})
@EntityScan(basePackages = {"com.john.appo.entity"})
@EnableJpaRepositories(basePackages = {"com.john.appo.entity.repository"})
@EnableJpaAuditing
@PropertySources({
//	@PropertySource({"file:/home/nakesh/micro/properties/appointment.properties"})
        @PropertySource({"classpath:/appointment.properties"})
})
public class Application {

    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }

    @Bean
    public Docket api() {

        ParameterBuilder aParameterBuilder = new ParameterBuilder();

        aParameterBuilder.name("X-AUTH-TOKEN").description("Enter Auth Token").modelRef(new ModelRef("string"))
                .parameterType("header").required(false).build();

        ParameterBuilder aParameterBuilder2 = new ParameterBuilder();

        aParameterBuilder2.name("Content-Type").description("Enter Content Type for Request")
                .modelRef(new ModelRef("string")).parameterType("header").defaultValue("application/json")
                .required(false).build();

        List<Parameter> aParameters = new ArrayList<Parameter>();

        aParameters.add(aParameterBuilder.build());

        aParameters.add(aParameterBuilder2.build());

        return new Docket(DocumentationType.SWAGGER_2)
                .select()
                .apis(RequestHandlerSelectors.any()) // .basePackage("com.example.controller")
                .paths(PathSelectors.any())
                .build()
                .globalOperationParameters(aParameters);
    }

    /* added to support serialization of new java 8 date and time api which spring does not do by default */
    @Bean
    public Formatter<LocalDate> localDateFormatter() {
        return new Formatter<LocalDate>() {
            @Override
            public LocalDate parse(String date, Locale locale) throws ParseException {
                return LocalDate.parse(date, DateTimeFormatter.ofPattern("dd-MM-yyyy", Locale.ENGLISH).withZone(ZoneId.of(TimeZoneList.IST.getZoneId())));
            }

            @Override
            public String print(LocalDate date, Locale locale) {
                return date.format(DateTimeFormatter.ofPattern("dd-MM-yyyy", Locale.ENGLISH));
            }
        };
    }
}