/**
 *
 */
package com.john.appo.service;

import com.john.appo.entity.ServiceSlotBooking;
import com.john.appo.entity.ShopServices;
import com.john.appo.output.ApiResponse;
import org.springframework.data.domain.Pageable;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

/**
 * @author nakesh
 */
public interface ListingService {
    ApiResponse getAvailableSlotsForService(Long serviceId, LocalDate date);

    ApiResponse listing(Long subCatId, Float lat, Float lon, Integer pinCode, Double dis, LocalDate date, Pageable pageable);

    ApiResponse getShopsForSubCategory(Long subCatId, Float lat, Float lon, Integer pinCode, Double distance, Pageable pageable);

    ApiResponse getServicesForShopId(Long shopId);

    //   List<String> getAvailableTimeSlots(ShopServices service, List<Booking> bookings, int startBookingTimeOnlyForToday);
    List<String> getAvailableTimeSlots(ShopServices service, List<ServiceSlotBooking> bookings, int startBookingTimeOnlyForToday);

    Map<Integer, Integer> getAvailableTimeSlotsWithSeatCount(ShopServices service, List<ServiceSlotBooking> serviceSlotBookingList, int startBookingTimeOnlyForToday);

    //    List<Booking> getBookingList(List<Long> shopIds, Date date);
    List<ServiceSlotBooking> getBookingList(List<Long> shopIds, LocalDate date);

    ApiResponse getServicesForShopId_2(Long shopid);
}
