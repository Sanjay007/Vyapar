/**
 *
 */
package com.john.appo.controller;

import com.john.appo.constants.C;
import com.john.appo.constants.Roles;
import com.john.appo.enums.Operation;
import com.john.appo.input.FeedbackInput;
import com.john.appo.output.ApiResponse;
import com.john.appo.feedback.service.FeedbackService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.MediaType;
import org.springframework.security.access.annotation.Secured;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

/**
 * @author nakesh
 */
@RestController
@RequestMapping(value = C.FEEDBACK, consumes = {MediaType.APPLICATION_JSON_VALUE}, produces = {
        MediaType.APPLICATION_JSON_VALUE})
public class FeedbackController {

    @Autowired
    FeedbackService feedbackService;

    @Secured({Roles.ROLE_ADMIN_WRITE, Roles.ROLE_USER})
    @RequestMapping(method = RequestMethod.POST)
    public ApiResponse add(@RequestBody FeedbackInput input) {
        // if Operation == U_SS_FEEDBACK then userId is customer's id
        // else if Operation == SO_SS_FEEDBACK then userId is shopowner's id
        input.setUserId(Long.parseLong(SecurityContextHolder.getContext().getAuthentication().getName()));
        return feedbackService.add(input);
    }

    @Secured({Roles.ROLE_ADMIN_WRITE, Roles.ROLE_USER})
    @RequestMapping(method = RequestMethod.PUT)
    public ApiResponse update(@RequestBody FeedbackInput input) {
        input.setUserId(Long.parseLong(SecurityContextHolder.getContext().getAuthentication().getName()));
        return feedbackService.update(input);
    }

    // everyone should allow to get
    @RequestMapping(value = C.LIST, method = RequestMethod.GET)
    public ApiResponse getFeedbacks(@RequestParam(required = false) Long serviceid, @RequestParam(required = false) Long shopid,
                                    @RequestParam(required = false) Integer rating, Pageable pageable) {
        return feedbackService.getFeedbacks(serviceid, shopid, rating, Operation.U_SS_FEEDBACK, pageable);
    }
}
