/**
 *
 */
package com.john.appo.service.Impl;

import com.john.appo.entity.*;
import com.john.appo.entity.repository.*;
import com.john.appo.enums.ErrorCode;
import com.john.appo.enums.Operation;
import com.john.appo.enums.TimeZoneList;
import com.john.appo.enums.UserType;
import com.john.appo.output.ApiResponse;
import com.john.appo.service.MediaService;
import com.john.appo.media.service.FileService;
import com.john.appo.security.UserRecord;
import org.apache.maven.shared.utils.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import javax.transaction.Transactional;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @author nakesh
 */
@Service
public class MediaServiceImpl implements MediaService {

    @Qualifier("localMediaService")
    @Autowired
    FileService fileService;
    @Autowired
    MediaRepository mediaRepository;
    @Autowired
    UserRepository userRepository;
    @Autowired
    AdminRepository adminRepository;
    @Autowired
    ShopServicesRepository shopServiceRepository;
    @Autowired
    ShopRepository shopRepository;

    // can't validate shopId with sender id because shop images can be uploaded by superadmin also.
    @Override
    @Transactional
    public ApiResponse uploadShopPics(MultipartFile[] files, Long shopId, Long shopServiceId, Boolean active, Long senderId) {
        if (files == null || shopId == null) {
            return new ApiResponse(ErrorCode.INPUT_PARAM_NOT_CORRECT);
        }
        Operation operation = Operation.S_DP;
        ApiResponse response = null;
        if (shopServiceId != null) {
            operation = Operation.SS_DP;
            response = validateShopServiceId(shopId, shopServiceId); // validate shopService belongs to shop or not
            if (!response.isSuccess()) {
                return response;
            }
        }
        response = uploadAndSave(files, shopId, shopServiceId, operation, active, senderId);
        return response.isSuccess() ? new ApiResponse() : response;  // in case of success response data has Media object, so send new ApiResponse without Media object
    }

    @Override
    public ApiResponse downloadProfilePic(HttpServletResponse response, String fileName) {
        UserRecord userDetails = (UserRecord) SecurityContextHolder.getContext().getAuthentication().getDetails();
        Long id = Long.parseLong(userDetails.getUsername());
        if (userDetails.getUserType() == UserType.ADMIN) {
            Admin admin = adminRepository.findOne(id);
            if (!StringUtils.equals(fileName, admin.getProImage())) {
                return new ApiResponse(ErrorCode.FILE_DOES_NOT_BELONGS_TO_YOU);
            }
        } else {
            User user = userRepository.findOne(id);
            if (!StringUtils.equals(fileName, user.getProImage())) {
                return new ApiResponse(ErrorCode.FILE_DOES_NOT_BELONGS_TO_YOU);
            }
        }
        return fileService.download(response, fileName);
    }

    @Override
    public ApiResponse downloadShopPics(HttpServletResponse response, String fileName) {
        return fileService.download(response, fileName);
    }

    @SuppressWarnings("unchecked")
    @Override
    public ApiResponse uploadProfilePic(MultipartFile[] files) {
        UserRecord userDetails = (UserRecord) SecurityContextHolder.getContext().getAuthentication().getDetails();
        Long id = Long.parseLong(userDetails.getUsername());
        ApiResponse response = uploadAndSave(files, null, null, Operation.U_DP, null, id);
        if (!response.isSuccess()) {
            return response;
        }
        String existingProfilePicName = null;
        if (userDetails.getUserType() == UserType.ADMIN) {
            Admin admin = adminRepository.findOne(id);
            existingProfilePicName = admin.getProImage();
            admin.setProImage(((List<Media>) response.getData()).get(0).getGeneratedName());
            adminRepository.save(admin);
        } else {
            User user = userRepository.findOne(id);
            existingProfilePicName = user.getProImage();
            user.setProImage(((List<Media>) response.getData()).get(0).getGeneratedName());
            userRepository.save(user);
        }
        return fileService.delete(existingProfilePicName);  // deleting exiting profile pic
    }

    private ApiResponse uploadAndSave(MultipartFile[] files, Long shopId, Long shopServiceId,
                                      Operation operation, Boolean active, Long senderId) {
        List<Media> medias = new ArrayList<>();
        List<String> generFileNames = new ArrayList<>();
        for (MultipartFile multipartFile : files) {
            ApiResponse response = fileService.upload(multipartFile, operation.name() + senderId);
            if (!response.isSuccess()) {
                return response;
            }
            String generatedFileName = response.getData().toString();
            generFileNames.add(generatedFileName);
            Media media = new Media();
            media.setUserId(senderId);
            media.setShopId(shopId);
            media.setShopServiceId(shopServiceId);
            media.setOperation(operation);
            media.setOrgnlName(multipartFile.getOriginalFilename());
            media.setGeneratedName(generatedFileName);
            media.setContentType(multipartFile.getContentType());
            media.setActive(active == null ? true : active);
            media.setCreatedTime(LocalDateTime.now(ZoneId.of(TimeZoneList.IST.getZoneId())));
            medias.add(media);
        }
        mediaRepository.save(medias);
        // updating files to shop or shopService entity
        saveFilesToShopOrShopServiceEntity(shopId, shopServiceId, generFileNames);
        return new ApiResponse(medias);
    }

    // updating files to shop or shopService entity
    private void saveFilesToShopOrShopServiceEntity(Long shopId, Long shopServiceId, List<String> generFileNames) {
        if (shopServiceId != null) {
            saveFilesToShopService(shopServiceId, generFileNames);
        } else if (shopId != null) {
            saveFilesToShop(shopId, generFileNames);
        }
    }

    // updating files to shopService entity
    private void saveFilesToShopService(long shopServiceId, List<String> generFileNames) {
        ShopServices shopServices = shopServiceRepository.findOne(shopServiceId);
        if (shopServices != null) {
            generFileNames.addAll(shopServices.getFiles());
            shopServices.setFiles(generFileNames.stream().distinct().collect(Collectors.toList()));  //remove duplicates from list
            shopServiceRepository.save(shopServices);
        }
    }

    // updating files to shop entity
    private void saveFilesToShop(long shopId, List<String> generFileNames) {
        Shop shop = shopRepository.findOne(shopId);
        if (shop != null) {
            generFileNames.addAll(shop.getFiles());
            shop.setFiles(generFileNames.stream().distinct().collect(Collectors.toList()));  //remove duplicates from list
            shopRepository.save(shop);
        }
    }

    private ApiResponse validateShopServiceId(long shopId, long shopServiceId) {
        ShopServices shopServices = shopServiceRepository.findOne(shopServiceId);
        if (shopServices != null && shopServices.getShopId() != shopId) {
            return new ApiResponse(ErrorCode.MISMATCH_SHOPID_AND_SERVICEID);
        }
        return new ApiResponse();
    }

    @Override
    @Transactional
    public ApiResponse delete(Long shopId, Long shopServiceId, List<String> fileNames) {
        ApiResponse response = null;
        Operation operation = Operation.S_DP; // shop_DP
        if (shopServiceId != null) {
            operation = Operation.SS_DP;     // shopService_DP
            response = validateShopServiceId(shopId, shopServiceId); // validate shopService belongs to shop or not
            if (!response.isSuccess()) {
                return response;
            }
        }
        List<Media> medias = null;
        if (operation == Operation.SS_DP) {
            medias = mediaRepository.findByShopIdAndShopServiceIdAndGeneratedNameIn(shopId, shopServiceId, fileNames);
        } else {
            medias = mediaRepository.findByShopIdAndGeneratedNameIn(shopId, fileNames);
        }
        if (medias == null || medias.isEmpty()) {
            return new ApiResponse(ErrorCode.FILE_DOES_NOT_EXIST);
        }
        mediaRepository.delete(medias); // deleted from entity
        deleteFileFromShopOrShopService(shopId, shopServiceId, operation, fileNames);
        return new ApiResponse();
    }

    private void deleteFileFromShopOrShopService(Long shopId, Long shopServiceId, Operation operation, List<String> fileNames) {
        if (shopServiceId != null) {
            ShopServices shopServices = shopServiceRepository.findOne(shopServiceId);
            List<String> list = new ArrayList<>(shopServices.getFiles());
            list.removeIf(file -> fileNames.contains(file));
            shopServices.setFiles(list.isEmpty() ? null : list);
            shopServiceRepository.save(shopServices);
        } else if (shopId != null) {
            Shop shop = shopRepository.findOne(shopId);
            List<String> list = new ArrayList<>(shop.getFiles());
            list.removeIf(file -> fileNames.contains(file));
            shop.setFiles(list.isEmpty() ? null : list);
            shopRepository.save(shop);
        }
    }

}
