package com.john.appo.service.Impl;

import com.john.appo.constants.C;
import com.john.appo.entity.Admin;
import com.john.appo.entity.Shop;
import com.john.appo.entity.repository.AdminRepository;
import com.john.appo.entity.repository.ShopRepository;
import com.john.appo.enums.ErrorCode;
import com.john.appo.enums.TimeZoneList;
import com.john.appo.enums.WorkingDays;
import com.john.appo.input.ShopInput;
import com.john.appo.output.ApiResponse;
import com.john.appo.output.PageableResponse;
import com.john.appo.output.ShopOutput;
import com.john.appo.service.ShopService;
import org.apache.maven.shared.utils.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * @author nakesh
 */
@Service
public class ShopServiceImpl implements ShopService {

    private static final Logger logger = LoggerFactory.getLogger(ShopServiceImpl.class);

    @Autowired
    ShopRepository shopRepository;
    @Autowired
    AdminRepository adminRepository;

    @Override
    public ApiResponse create(ShopInput input) {
        // validate userId
        ApiResponse response = validateInput(input);
        if (!response.isSuccess()) {
            return response;
        }
        Shop shop = new Shop();
        BeanUtils.copyProperties(input, shop);
        shop.setCreatedTime(LocalDateTime.now(ZoneId.of(TimeZoneList.IST.getZoneId())));
        shop = shopRepository.save(shop);
        ShopOutput shopOutput = new ShopOutput();
        BeanUtils.copyProperties(shop, shopOutput);
        response.setData(shopOutput);
        return response;
    }

    @Override
    public ApiResponse update(ShopInput input) {
        // how to avoid other admin to update others admin's record
        if (input.getId() == null) {
            return new ApiResponse(ErrorCode.INPUT_PARAM_NOT_CORRECT);
        }
        Shop shop = shopRepository.findOne(input.getId());
        if (shop == null) {
            return new ApiResponse(ErrorCode.USER_NOT_FOUND);
        }
        Boolean update = false;
        // update name
        if (!StringUtils.endsWithIgnoreCase(input.getName(), shop.getName()) && StringUtils.isNotBlank(input.getName())) {
            shop.setName(input.getName());
            update = true;
        }

        //update phone
        if (!shop.getPhone().equals(input.getPhone()) && input.getPhone() != null
                && input.getPhone().toString().length() == C.TEN) {
            shop.setPhone(input.getPhone());
            update = true;
        }

        //update mobile
        if (!shop.getMobile().equals(input.getMobile()) && input.getMobile() != null
                && input.getMobile().toString().length() == C.TEN) {
            shop.setMobile(input.getMobile());
            update = true;
        }

        //update maxSeat
        if (input.getMaxSeat() != shop.getMaxSeat() && validateMaxSeat(input.getMaxSeat())) {
            shop.setMaxSeat(input.getMaxSeat());
            update = true;
        }

        //update startTime
        if (input.getStartTime() != shop.getStartTime() && input.getStartTime() > 0) {
            if (updateStartTime(input.getStartTime(), input.getEndTime(), shop.getEndTime())) {
                shop.setStartTime(input.getStartTime());
                update = true;
            }
        }

        //update endTime
        if (input.getEndTime() != shop.getEndTime() && input.getEndTime() > 0) {
            if (updateEndTime(input.getStartTime(), input.getEndTime(), shop.getStartTime())) {
                shop.setEndTime(input.getEndTime());
                update = true;
            }
        }

        //update breakTime
        if (input.getBreakTime() != shop.getBreakTime() && input.getBreakTime() > 0) {
            if (updateBreakTime(input.getStartTime(), input.getEndTime(), shop.getStartTime(), shop.getEndTime(), input.getBreakTime())) {
                shop.setBreakTime(input.getBreakTime());
                update = true;
            }
        }

        //update breakDuration
        if (input.getBreakDuration() != shop.getBreakDuration() && input.getBreakDuration() > 0) {
            if (updateBreakDuration(input.getStartTime(), input.getEndTime(), shop.getStartTime(),
                    shop.getEndTime(), input.getBreakTime(), shop.getBreakTime(), input.getBreakDuration())) {
                shop.setBreakDuration(input.getBreakDuration());
                update = true;
            }
        }

        // update workingDays
        if (!StringUtils.endsWithIgnoreCase(input.getWorkingDays(), shop.getWorkingDays()) &&
                StringUtils.isNotBlank(input.getWorkingDays())
                && validateWorkingDays(input.getWorkingDays())) {
            shop.setWorkingDays(input.getWorkingDays());
            update = true;
        }

        // update description
        if (!StringUtils.endsWithIgnoreCase(input.getDescription(), shop.getDescription()) && StringUtils.isNotBlank(input.getDescription())) {
            shop.setDescription(input.getDescription());
            update = true;
        }

        if (update) {
            shopRepository.saveAndFlush(shop);
        }
        return get(input.getId());
    }

    @Override
    @Transactional
    public ApiResponse delete(Long id) {
        Shop shop = shopRepository.findOne(id);
        if (shop == null) {
            return new ApiResponse(ErrorCode.SHOP_NOT_FOUND, id.toString());
        }
        //first delete shopservice for given shopids
        //call sourabh service to delete shopservice
        shopRepository.delete(shop);
        return new ApiResponse();
    }

    @Override
    public ApiResponse get(Long id) {
        Shop shop = shopRepository.findOne(id);
        if (shop == null) {
            return new ApiResponse(ErrorCode.SHOP_NOT_FOUND, id.toString());
        }
        List<ShopOutput> shops = new ArrayList<ShopOutput>();
        ShopOutput shopOutput = new ShopOutput();
        BeanUtils.copyProperties(shop, shopOutput);
        shops.add(shopOutput);
        return new ApiResponse(new PageableResponse<>(shops, C.ONE, C.ZERO, C.ONE, C.ONE));
    }

    @Override
    public ApiResponse get(Pageable pageable) {
        List<ShopOutput> shopOutputs = new ArrayList<>();
        Page<Shop> shops = shopRepository.findAll(pageable);
        if (shops.getSize() == C.ZERO) {
            return new ApiResponse(new PageableResponse<ShopOutput>(new ArrayList<>(), C.ZERO, C.ZERO, C.ZERO, C.ZERO));
        }
        for (Shop shop : shops) {
            ShopOutput shopOutput = new ShopOutput();
            BeanUtils.copyProperties(shop, shopOutput);
            shopOutputs.add(shopOutput);
        }
        PageableResponse<ShopOutput> pageableResponse = new PageableResponse<>(shopOutputs, shops);
        return new ApiResponse(pageableResponse);
    }

    @Override
    public ApiResponse updateActivationAndApproval(Long id, Integer activate, Integer approve) {
        if (id == null || (activate == null && approve == null)) {
            return new ApiResponse(ErrorCode.INPUT_PARAM_NOT_CORRECT);
        }
        Shop shop = shopRepository.findOne(id);
        if (shop == null) {
            return new ApiResponse(ErrorCode.USER_NOT_FOUND);
        }
        if (approve != null) {
            shop.setApproved(approve == 1 ? true : false);
            logger.info("Marking approve - {} for shopId - {}", new Object[]{approve, id});
        } else if (activate != null && shop.isApproved()) { // no activation if shop is not approved
            logger.info("Marking active - {} for shopId - {}", new Object[]{activate, id});
            shop.setActive(activate == 1 ? true : false);
        }
        shopRepository.saveAndFlush(shop);
        return get(id);
    }

    private boolean updateStartTime(int inputStartTime, int inputEndTime, int storedEndTime) {
        int endTime = 0;
        if (inputEndTime != storedEndTime && inputEndTime > 0) {
            endTime = inputEndTime;
        } else {
            endTime = storedEndTime;
        }
        return validateStartTime(inputStartTime, endTime);
    }

    private boolean updateEndTime(int inputStartTime, int inputEndTime, int storedStartTime) {
        int startTime = 0;
        if (inputStartTime != storedStartTime && inputStartTime > 0) {
            startTime = inputStartTime;
        } else {
            startTime = storedStartTime;
        }
        return validateEndTime(startTime, inputEndTime);
    }

    private boolean updateBreakTime(int inputStartTime, int inputEndTime, int storedStartTime, int storedEndTime,
                                    int breakTime) {
        int startTime = 0;
        int endTime = 0;
        if (inputStartTime != storedStartTime && inputStartTime > 0) {
            startTime = inputStartTime;
        } else {
            startTime = storedStartTime;
        }
        if (inputEndTime != storedEndTime && inputEndTime > 0) {
            endTime = inputEndTime;
        } else {
            endTime = storedEndTime;
        }
        return validateBreakTime(startTime, endTime, breakTime);
    }

    private boolean updateBreakDuration(int inputStartTime, int inputEndTime, int storedStartTime,
                                        int storedEndTime, int inputBreakTime, int storedBreakTime, int inputBreakDuration) {
        int startTime = 0;
        int endTime = 0;
        int breakTime = 0;
        if (inputStartTime != storedStartTime && inputStartTime > 0) {
            startTime = inputStartTime;
        } else {
            startTime = storedStartTime;
        }
        if (inputEndTime != storedEndTime && inputEndTime > 0) {
            endTime = inputEndTime;
        } else {
            endTime = storedEndTime;
        }
        if (inputBreakTime != storedBreakTime && inputBreakTime > 0) {
            breakTime = inputBreakTime;
        } else {
            breakTime = storedBreakTime;
        }
        return validateBreakDuration(startTime, endTime, breakTime, inputBreakDuration);
    }

    public ApiResponse validateInput(ShopInput input) {
        // Todo : validating for duplicate shops name by : name

        // validate userId
        Admin admin = adminRepository.findOne(input.getOwnerId());
        if (admin == null) {
            return new ApiResponse(ErrorCode.USER_NOT_FOUND);
        }
        // validate shop maxSeat
        if (!validateMaxSeat(input.getMaxSeat())) {
            return new ApiResponse(ErrorCode.INVALID_MAX_SEAT, input.getWorkingDays());
        }
        // validate shop timings
        if (!validateTimings(input.getStartTime(), input.getEndTime(), input.getBreakTime(), input.getBreakDuration())) {
            return new ApiResponse(ErrorCode.INVALID_TIMINGS);
        }
        // validate workingDays
        if (!validateWorkingDays(input.getWorkingDays())) {
            return new ApiResponse(ErrorCode.INVALID_WORKING_DAYS, input.getWorkingDays());
        }
        return new ApiResponse();
    }

    private boolean validateTimings(int startTime, int endTime, int breakTime, int breakDuration) {
        // valid case : return true
        // invalid case : return false
        return validateStartTime(startTime, endTime)
                && validateEndTime(startTime, endTime)
                && validateBreakTime(startTime, endTime, breakTime)
                && validateBreakDuration(startTime, endTime, breakTime, breakDuration);
    }

    private boolean validateStartTime(int startTime, int endTime) {
        return startTime < endTime && startTime > C.FOUR * C.SIXTY;         // 4*60 = 240 min = 4 hr = 4 o'clock morning
    }

    private boolean validateEndTime(int startTime, int endTime) {
        return startTime < endTime && endTime < C.TWENTY_THREE * C.SIXTY;   // 23*60 = 1380 min = 23 hr = 23 o'clock night;
    }

    private boolean validateBreakTime(int startTime, int endTime, int breakTime) {
        return breakTime > startTime && breakTime < endTime;
    }

    private boolean validateBreakDuration(int startTime, int endTime, int breakTime, int breakDuration) {
        return breakTime != 0 && breakDuration > C.ZERO && breakDuration <= C.THREE && breakDuration < endTime - startTime;
    }

    private boolean validateMaxSeat(int maxSeat) {
        return maxSeat > C.ZERO && maxSeat < C.TWENTY;
    }

    private boolean validateWorkingDays(String commaSeparatedWorkingDays) {
        List<String> workingDays = Stream.of(WorkingDays.values()).map(WorkingDays::name).collect(Collectors.toList());
        return workingDays.containsAll(Arrays.asList(commaSeparatedWorkingDays.split("\\s*,\\s*")));
    }
}
