/**
 *
 */
package com.john.appo.controller;

import com.john.appo.constants.C;
import com.john.appo.constants.Roles;
import com.john.appo.input.CategorySubCategoryInput;
import com.john.appo.output.ApiResponse;
import com.john.appo.service.SubCategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.*;

/**
 * @author nakesh
 */
@RestController
@Secured(Roles.ROLE_SUPER_ADMIN)
@RequestMapping(value = C.SUB_CAT, consumes = {MediaType.APPLICATION_JSON_VALUE}, produces = {MediaType.APPLICATION_JSON_VALUE})
public class SubCategoryController {

    @Autowired
    SubCategoryService subCategoryService;

    @RequestMapping(method = RequestMethod.POST)
    public ApiResponse save(@RequestBody CategorySubCategoryInput input) {
        return subCategoryService.create(input);
    }

    @RequestMapping(method = RequestMethod.PUT)
    public ApiResponse update(@RequestBody CategorySubCategoryInput input) {
        return subCategoryService.update(input);
    }

    @RequestMapping(method = RequestMethod.DELETE)
    public ApiResponse delete(@RequestParam(required = true) Long id) {
        return subCategoryService.delete(id);
    }
}