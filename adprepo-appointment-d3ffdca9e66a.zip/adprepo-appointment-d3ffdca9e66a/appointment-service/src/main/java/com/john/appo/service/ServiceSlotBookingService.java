package com.john.appo.service;

import com.john.appo.entity.ServiceSlotBooking;

import java.time.LocalDate;
import java.util.List;

/**
 * @author Krishna
 */
public interface ServiceSlotBookingService {

    List<ServiceSlotBooking> getBookingList(List<Long> shopIds, LocalDate serviceDate);
}
