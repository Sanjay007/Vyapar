/**
 *
 */
package com.john.appo.controller;

import com.john.appo.constants.C;
import com.john.appo.constants.Roles;
import com.john.appo.input.ShopInput;
import com.john.appo.output.ApiResponse;
import com.john.appo.service.ShopService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.MediaType;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

/**
 * @author nakesh
 */
@RestController
@RequestMapping(value = C.SHOP, consumes = {MediaType.APPLICATION_JSON_VALUE}, produces = {
        MediaType.APPLICATION_JSON_VALUE})
public class ShopController {

    @Autowired
    ShopService shopService;

    @RequestMapping(method = RequestMethod.POST)
    @Secured({Roles.ROLE_ADMIN_UPDATE, Roles.ROLE_SUPER_ADMIN})
    public ApiResponse create(@Valid @RequestBody ShopInput input) {
        return shopService.create(input);
    }

    @RequestMapping(method = RequestMethod.PUT)
    @Secured({Roles.ROLE_ADMIN_UPDATE, Roles.ROLE_SUPER_ADMIN})
    public ApiResponse update(@RequestBody ShopInput input) {
        return shopService.update(input);
    }

    @RequestMapping(method = RequestMethod.DELETE)
    @Secured({Roles.ROLE_SUPER_ADMIN})
    public ApiResponse delete(@RequestParam(required = true) Long id) {
        return shopService.delete(id);
    }

    @RequestMapping(method = RequestMethod.GET)
    @Secured({Roles.ROLE_ADMIN_UPDATE, Roles.ROLE_SUPER_ADMIN})
    public ApiResponse get(@RequestParam(required = false) Long id, Pageable pageable) {
        if (id != null) {
            return shopService.get(id);
        } else {
            return shopService.get(pageable);
        }
    }

    @RequestMapping(value = C.TOGGLE, method = RequestMethod.PUT)
    @Secured({Roles.ROLE_SUPER_ADMIN})
    public ApiResponse updateActivationAndApproval(@RequestParam(required = true) Long id,
                                                   @RequestParam(required = false) Integer activate, @RequestParam(required = false) Integer approve) {
        return shopService.updateActivationAndApproval(id, activate, approve);
    }
}
