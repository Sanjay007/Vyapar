/**
 *
 */
package com.john.appo.service.Impl;

import com.john.appo.enums.ErrorCode;
import com.john.appo.enums.UserType;
import com.john.appo.input.LoginInput;
import com.john.appo.output.ApiResponse;
import com.john.appo.service.AdminService;
import com.john.appo.service.LoginService;
import com.john.appo.service.UserService;
import com.john.appo.security.UserRecord;
import com.john.appo.security.service.AuthenticationService;
import org.apache.maven.shared.utils.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


/**
 * @author nakesh
 */
@Service
public class LoginServiceImpl implements LoginService {

    private static final Logger logger = LoggerFactory.getLogger(LoginServiceImpl.class);

    @Autowired
    AuthenticationService authService;
    @Autowired
    UserService userService;
    @Autowired
    AdminService adminService;

    @Override
    public ApiResponse login(LoginInput input) {
        logger.info("inside LoginServiceImpl.login()");
        if (input.getUserType() == null || StringUtils.isBlank(input.getEmail()) || StringUtils.isBlank(input.getPassword())) {
            return new ApiResponse(ErrorCode.INPUT_PARAM_NOT_CORRECT);
        }
        if (UserType.ADMIN == input.getUserType()) {
            return adminService.login(input);
        } else {
            return userService.login(input);
        }
    }

    @Override
    public ApiResponse resetPassword(LoginInput input) {
        logger.info("inside LoginServiceImpl.resetPassword()");
        if (StringUtils.isBlank(input.getNewPassword()) || StringUtils.isBlank(input.getConfirmPassword())) {
            return new ApiResponse(ErrorCode.INPUT_PARAM_NOT_CORRECT);
        }
        if (!StringUtils.equals(input.getNewPassword(), input.getConfirmPassword())) {
            return new ApiResponse(ErrorCode.NEW_CONFIRM_PASSWORD_MISMATCH);
        }
        UserRecord userRecord = authService.getUser();
        if (userRecord != null) {   //
            logger.info("userId- {}, username- {}, role- {}, userType- {}", userRecord.getUserId(), userRecord.getUsername(), userRecord.getRoles(), userRecord.getUserType());
            userRecord.getAuthorities().forEach(x -> {
                logger.info("authority- {}", x.getAuthority());
            });
        }
        input.setId(userRecord.getUserId());
        if (userRecord.getUserType() == UserType.ADMIN) {
            return adminService.resetPassword(input);
        } else {
            return userService.resetPassword(input);
        }
    }

    @Override
    public ApiResponse logout() {
        UserRecord userRecord = authService.getUser();
        if (userRecord.getUserType() == UserType.ADMIN) {
            return adminService.logout(userRecord.getUserId());
        } else {
            return userService.logout(userRecord.getUserId());
        }
    }

    @Override
    public ApiResponse forgot(LoginInput input) {
        if (StringUtils.isBlank(input.getEmail())) {
            return new ApiResponse(ErrorCode.USERNAME_MISSING);
        }
        if (input.getUserType() == UserType.ADMIN) {
            return adminService.forgot(input.getEmail());
        } else {
            return userService.forgot(input.getEmail());
        }
    }
}
