/**
 *
 */
package com.john.appo.utils;

import com.john.appo.input.FcmPushInput;
import com.john.appo.output.FcmPushOutput;
import com.john.appo.service.Impl.UserServiceImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

/**
 * @author nakesh
 */
public class ApiCall {

    private static final Logger logger = LoggerFactory.getLogger(UserServiceImpl.class);

    @Value("${fcm.url:https://fcm.googleapis.com/fcm/send}")
    String fcmUrl;
    @Value("${fcm.server.key:server-key}")
    String fcmServerKey;

    public FcmPushOutput sendPushNotification(FcmPushInput fcmPushInput) {

        MultiValueMap<String, String> headers = new LinkedMultiValueMap<String, String>();
        headers.add("Authorization", "key=" + fcmServerKey);
        headers.add("Content-Type", "application/json");

        RestTemplate restTemplate = new RestTemplate();
        restTemplate.getMessageConverters().add(new MappingJackson2HttpMessageConverter());
        HttpEntity<FcmPushInput> request = new HttpEntity<FcmPushInput>(fcmPushInput, headers);
        System.out.println("fcmUrl : " + fcmUrl + " : fcmServerKey :" + fcmServerKey);

        FcmPushOutput output = restTemplate.postForObject(fcmUrl, request, FcmPushOutput.class);
        logger.info("ApiCall sendPushNotification output : " + output);
        return output;
    }
}
