/**
 *
 */
package com.john.appo.controller;

import com.john.appo.constants.C;
import com.john.appo.input.LoginInput;
import com.john.appo.output.ApiResponse;
import com.john.appo.service.LoginService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

/**
 * @author nakesh
 */
@RestController
@RequestMapping(consumes = {MediaType.APPLICATION_JSON_VALUE}, produces = {MediaType.APPLICATION_JSON_VALUE})
public class LoginController {

    private static final Logger logger = LoggerFactory.getLogger(LoginController.class);

    @Autowired
    LoginService service;

    @RequestMapping(value = C.LOGIN, method = RequestMethod.POST)
    @CrossOrigin(origins = "http://localhost:4200")
    public ApiResponse login(@RequestBody LoginInput input) {
        logger.info("inside LoginController.login()");
        return service.login(input);
    }

    @RequestMapping(value = C.FORGOT, method = RequestMethod.POST)
    public ApiResponse forgot(@RequestBody LoginInput input) {
        logger.info("inside LoginController.forgot()");
        return service.forgot(input);
    }

    @RequestMapping(value = C.LOGOUT, method = RequestMethod.POST)
    public ApiResponse logout() {
        logger.info("inside LoginController.logout()");
        return service.logout();
    }

    @RequestMapping(value = C.RESET, method = RequestMethod.POST)
    public ApiResponse resetPassword(@RequestBody LoginInput input) {
        logger.info("inside LoginController.resetPassword()");
        return service.resetPassword(input);
    }

    @RequestMapping(value = C.GREETING, method = RequestMethod.GET)
    public ApiResponse greeting() {
        logger.info("inside LoginController.login()");
        return new ApiResponse();
    }
}
