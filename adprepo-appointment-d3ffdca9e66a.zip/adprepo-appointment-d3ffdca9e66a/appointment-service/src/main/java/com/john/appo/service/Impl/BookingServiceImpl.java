package com.john.appo.service.Impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.transaction.Transactional;
import org.hibernate.Session;
import org.hibernate.engine.spi.SessionImplementor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import com.john.appo.database.SqlUtils;
import com.john.appo.entity.Booking;
import com.john.appo.entity.ServiceSlotBooking;
import com.john.appo.entity.ShopServices;
import com.john.appo.entity.repository.BookingRepository;
import com.john.appo.entity.repository.ServiceSlotBookingRepository;
import com.john.appo.entity.repository.ShopRepository;
import com.john.appo.entity.repository.ShopServicesRepository;
import com.john.appo.entity.repository.UserRepository;
import com.john.appo.enums.ErrorCode;
import com.john.appo.enums.Status;
import com.john.appo.enums.TimeZoneList;
import com.john.appo.input.BlockSlotInput;
import com.john.appo.input.BookingInput;
import com.john.appo.input.FcmDataInput;
import com.john.appo.input.ServicesSlotsBookingInput;
import com.john.appo.input.SlotInfoInput;
import com.john.appo.output.ApiResponse;
import com.john.appo.output.BookingOutput;
import com.john.appo.output.FcmDataOutput;
import com.john.appo.output.PageableResponse;
import com.john.appo.output.ServicesSlotsBookingOutput;
import com.john.appo.search.BookingSearchCriteria;
import com.john.appo.service.BookingService;
import com.john.appo.service.ListingService;
import com.john.appo.service.ServiceSlotBookingService;
import com.john.appo.transactions.services.TransactionService;
import com.john.appo.utils.DateTimeUtils;
import com.john.appo.utils.StringUtils;
import com.john.appo.utils.UniqueIdGenerator;
import com.john.appo.security.service.AuthenticationService;
import org.springframework.beans.factory.annotation.Value;

/**
 * @author Krishna
 */
@Service
public class BookingServiceImpl implements BookingService {
    private static final Logger logger = LoggerFactory.getLogger(BookingServiceImpl.class);
    //Holds request id's with slot statuses
    private static Map<String, ServicesSlotsBookingInput> availableSlotsConfStatus = new HashMap<String, ServicesSlotsBookingInput>();
    @Autowired
    ServiceSlotBookingRepository serviceSlotBookingRepository;
    @Autowired
    ShopRepository shopRepository;
    @Autowired
    ShopServicesRepository shopServicesRepository;
    @Autowired
    UserRepository userRepository;
    @Autowired
    ListingService listingService;
    @Autowired
    BookingRepository bookingRepository;
    @Autowired
    ServiceSlotBookingService serviceSlotBookingService;
    @Autowired
    private EntityManager entityManager;
    @Autowired
    TransactionService transactionService;
    @Autowired
    AuthenticationService authenticationService;

    @Value("${app.features.booking.canPayLater:false}")
    boolean canPayLater;

    @Override
    public ApiResponse validateAndLockAvailableSlotsForBooking(ServicesSlotsBookingInput input) {
        //validate inputs
        ApiResponse response = validate(input);
        if (!response.isSuccess()) {
            return response;
        }
        //check and lock if slots are available
        return validateAndLockSlotsAvailabilityStatus(input);
    }

    @Override
    @Transactional
    public ApiResponse book(BookingInput bookingInput) {
        if (bookingInput != null) {
            //validate booking details
            ServicesSlotsBookingInput cachedInput = availableSlotsConfStatus.get(bookingInput.getBookingId());
            if (cachedInput == null)
                return new ApiResponse(ErrorCode.INVALID_BOOKING_ID, bookingInput.getBookingId());
            if (cachedInput.getUserId() != bookingInput.getUserId())
                return new ApiResponse(ErrorCode.INVALID_USER_ID_FOR_BOOKING_ID, new String[]{bookingInput.getUserId().toString(), bookingInput.getBookingId()});

            for (SlotInfoInput slotInfoInput : cachedInput.getSlotInfos()) {
                if (!cachedInput.isSlotApprovalAuto() && !(Status.AUTO_APPROVED.equals(slotInfoInput.getStatus()) || Status.APPROVED_BY_SHOP.equals(slotInfoInput.getStatus()))) {
                    return new ApiResponse(ErrorCode.ONLY_APPROVED_SLOTS_CAN_BE_BOOKED);
                }
            }
            //Save payment details
            if(!canPayLater){
                ApiResponse response = transactionService.savePayment(bookingInput.getPaymentId(), bookingInput.getBookingId());
                if (!response.isSuccess()) {
                    logger.debug("Saving of payment failed with exception : {} and {}", response.getErrorCode(), response.getErrorMsgEn());
                }
            }
            //as all slots are confirmed already let's do the booking directly.
            //update status in service_slot_booking table with status as "booked" from "approved_by_shop" or "auto_approved"
            Connection conn = null;
            PreparedStatement ps = null;
            try {
                conn = getConnection();
                ps = conn.prepareStatement("update service_slot_booking set status = ? where booking_id = ? and status in (?, ?)");
                ps.setInt(1, Status.BOOKED.ordinal());
                ps.setString(2, bookingInput.getBookingId());
                ps.setInt(3, Status.APPROVED_BY_SHOP.ordinal());
                ps.setInt(4, Status.AUTO_APPROVED.ordinal());
                int updatedRecords = ps.executeUpdate();
                if (updatedRecords != 0) {
                    //Now save booking record into booking table
                    List<ServiceSlotBooking> serviceSlotBookingList = serviceSlotBookingRepository.findByBookingId(bookingInput.getBookingId());
                    List<Booking> bookingList = getBookingEntityList(serviceSlotBookingList, bookingInput);
                    bookingList = bookingRepository.save(bookingList);
                    //remove booking id from the cache
                    availableSlotsConfStatus.remove(bookingInput.getBookingId());
                    return new ApiResponse(bookingList);
                }
            } catch (SQLException ex) {
                logger.debug("Error while updating Service Slot Booking Status : {}", ex);
                return new ApiResponse(ex.getMessage());
            } finally {
                SqlUtils.closeResources(conn, ps);
            }
        }
        return new ApiResponse(ErrorCode.NO_PARAM_IN_REQUEST);
    }

    @Override
    public ApiResponse getSlotsAvailabilityConfStatus(Long userId, String bookingId) {
        if (!StringUtils.isEmpty(bookingId) && availableSlotsConfStatus.get(bookingId) != null) {
            ServicesSlotsBookingInput input = availableSlotsConfStatus.get(bookingId);
            if (userId > 0 && input.getUserId() == userId) {
                ServicesSlotsBookingOutput output = new ServicesSlotsBookingOutput();
                BeanUtils.copyProperties(input, output);
                return new ApiResponse(output);
            } else
                return new ApiResponse(ErrorCode.INVALID_USER_ID_FOR_BOOKING_ID, new String[]{userId.toString(), bookingId});
        }
        return new ApiResponse(ErrorCode.INVALID_BOOKING_ID, bookingId);
    }

    @Override
    @Transactional
    public ApiResponse updateServicesSlotsBookingStatus(List<FcmDataOutput> dataList) {
        logger.info("Updating Service Slot Booking Status...");
        if (dataList != null && dataList.size() > 0) {
            ServicesSlotsBookingInput cachedInput = availableSlotsConfStatus.get(dataList.get(0).getReqId());
            //validate booking id
            if (cachedInput == null)
                return new ApiResponse(ErrorCode.INVALID_BOOKING_ID);

            List<SlotInfoInput> cachedSlotInfoList = cachedInput.getSlotInfos();
            if (cachedSlotInfoList != null && cachedSlotInfoList.size() > 0) {
                Connection conn = null;
                PreparedStatement ps = null;
                int[] recordsUpdated = null;
                try {
                    conn = getConnection();
                    ps = conn.prepareStatement("update service_slot_booking set status = ? where booking_id = ? and shop_service_id = ? and slot = ? and duration = ?");

                    for (FcmDataOutput inputList : dataList) {
                        for (SlotInfoInput cachedSlotInfo : cachedSlotInfoList) {
                            if (inputList.getServiceId() == cachedSlotInfo.getShopServiceId() && inputList.getStartTime() == cachedSlotInfo.getSlot() && inputList.getAvgTime() == cachedSlotInfo.getDuration() && !inputList.getStatus().equals(cachedSlotInfo.getStatus())) {
                                cachedSlotInfo.setStatus(inputList.getStatus());

                                //update status into database
                                ps.setInt(1, inputList.getStatus().ordinal());
                                ps.setString(2, inputList.getReqId());
                                ps.setLong(3, inputList.getServiceId());
                                ps.setInt(4, inputList.getStartTime());
                                ps.setInt(5, inputList.getAvgTime());

                                ps.addBatch();
                            }
                        }
                    }

                    recordsUpdated = ps.executeBatch();

                } catch (SQLException ex) {
                    logger.debug("Error while updating Service Slot Booking Status : {}", ex);
                } finally {
                    SqlUtils.closeResources(conn, ps);
                }
                // update cache
                availableSlotsConfStatus.put(dataList.get(0).getReqId(), cachedInput);
                logger.info("{} Service Slot Booking Status has been updated successfully !", recordsUpdated);

                //send push notification to consumer app saying that all slots are confirmed for booking
                //TODO

                return new ApiResponse();
            }
        }

        return new ApiResponse(ErrorCode.NO_PARAM_IN_REQUEST);
    }

    @Override
    public ApiResponse blockSlotsReservation(ServicesSlotsBookingInput input) {
        //validate inputs
        ApiResponse response = validate(input);
        if (!response.isSuccess()) {
            return response;
        }

        //check if requested slots are available before blocking them
        ApiResponse slotsAvailabilityResponse = checkSlotsAvailabilityAndUpdateStatus(input);
        if (!slotsAvailabilityResponse.isSuccess()) {
            return slotsAvailabilityResponse;
        }

        if (!isAllRequestedSlotsAreAvailable(input)) {
            return new ApiResponse(ErrorCode.NOT_ALLOWED_TO_BLOCK_SLOTS);
        }

        //update status
        changeSlotInfoStatus(input, Status.BLOCKED_BY_SHOP);

        //go ahead and block the slots
        List<ServiceSlotBooking> serviceSlotBookings = getAvailableBookingSlotsEntitiesFromInput(input);
        serviceSlotBookings = lockSlots(serviceSlotBookings);
        if (serviceSlotBookings != null && serviceSlotBookings.size() > 0) {
            return new ApiResponse();
        }
        return new ApiResponse(ErrorCode.UNKNOWN_EXCEPTION);
    }

    @Override
    public ApiResponse unblockSlotsReservation(ServicesSlotsBookingInput input) {
        //validate inputs
        ApiResponse response = validate(input);
        if (!response.isSuccess()) {
            return response;
        }

        List<Long> shopServiceIdList = new ArrayList<>();
        List<Integer> slotList = new ArrayList<>();
        List<Status> statusList = new ArrayList<>();
        for (SlotInfoInput info : input.getSlotInfos()) {
            shopServiceIdList.add(info.getShopServiceId());
            slotList.add(info.getSlot());
            statusList.add(Status.BLOCKED_BY_SHOP);
        }

        //get blocked slot info
        List<ServiceSlotBooking> serviceSlotBookingList = serviceSlotBookingRepository.findByShopIdAndShopServiceIdInAndSlotInAndStatusInAndServiceDate(input.getShopId(), shopServiceIdList, slotList, statusList, input.getServiceDate());
        if (serviceSlotBookingList != null && serviceSlotBookingList.size() > 0) {
            serviceSlotBookingRepository.delete(serviceSlotBookingList);
        } else
            return new ApiResponse(ErrorCode.NO_SLOTS_TO_UNBLOCK);

        return new ApiResponse();
    }

    private ApiResponse validate(ServicesSlotsBookingInput input) {
        if (input != null) {
            if (!(input.getUserId() <= 0) && userRepository.findOne(input.getUserId()) == null) {
                return new ApiResponse(ErrorCode.USER_NOT_FOUND);
            }

            if (input.getShopId() == null || shopRepository.findOne(input.getShopId()) == null) {
                return new ApiResponse(ErrorCode.SHOP_NOT_FOUND);
            }

            if (input.getServiceDate() == null || input.getServiceDate().isBefore(LocalDate.now(ZoneId.of(TimeZoneList.IST.getZoneId())))) {
                return new ApiResponse(ErrorCode.INVALID_DATE);
            }

            if (input.getSlotInfos() == null || input.getSlotInfos().size() == 0) {
                return new ApiResponse(ErrorCode.NO_SERVICE_SLOT_SELECTED);
            }
        } else {
            return new ApiResponse(ErrorCode.NO_PARAM_IN_REQUEST);
        }

        return new ApiResponse();
    }

    //TODO need to make it small
    private ApiResponse validateAndLockSlotsAvailabilityStatus(ServicesSlotsBookingInput input) {
        ApiResponse response = validateAndLockSlots(input);
        if (!response.isSuccess()) {
            return response;
        }
        ServicesSlotsBookingOutput output = new ServicesSlotsBookingOutput();
        BeanUtils.copyProperties(input, output);
        //check if all slots are available only then we have to initiate push notification
        if (isAllRequestedSlotsAreAvailable(input)) {
            if (input.isSlotApprovalAuto()) {
                //TODO send response to app saying that all slots are ready for booking
                return new ApiResponse(output);
            } else {
                //TODO send push notification to shop for approval and send response to app with corresponding status
                //send push notification to shop for approval

                //send response to app with corresponding status
                return new ApiResponse(output);
            }
        } else {
            //return response to app with updated slots availability status
            return new ApiResponse(output);
        }
    }

    private synchronized ApiResponse validateAndLockSlots(ServicesSlotsBookingInput input) {
        //validate input slots to make sure already available and locked slot has not been changed
        validateAndUnlockSlotsIfChanged(input);
        logger.info("############# Service Date : {}  and Current Date : {} and Timezone is : {} #############", input.getServiceDate(), LocalDateTime.now(ZoneId.of(TimeZoneList.IST.getZoneId())), ZoneId.systemDefault().getId());
        //check slots availability status and update status accordingly
        ApiResponse response = checkSlotsAvailabilityAndUpdateStatus(input);
        if (!response.isSuccess()) {
            return response;
        }

        //push available slots entry with status into slot_service_booking table
        List<ServiceSlotBooking> serviceSlotBookings = getAvailableBookingSlotsEntitiesFromInput(input);
        serviceSlotBookings = lockSlots(serviceSlotBookings);
        if (serviceSlotBookings != null && serviceSlotBookings.size() > 0) {
            updateCacheList(input);
        }
        return new ApiResponse();
    }

    private List<ServiceSlotBooking> lockSlots(List<ServiceSlotBooking> serviceSlotBookings) {
        if (serviceSlotBookings.size() > 0) {
            return serviceSlotBookingRepository.save(serviceSlotBookings);
        }
        return null;
    }

    private void updateCacheList(ServicesSlotsBookingInput input) {
        ServicesSlotsBookingInput cachedInput = new ServicesSlotsBookingInput();
        BeanUtils.copyProperties(input, cachedInput);
        ArrayList<SlotInfoInput> slotInfos = getSlotInfoEntityListFromServiceSlotBooking(input);
        cachedInput.setSlotInfos(slotInfos);
        availableSlotsConfStatus.put(input.getBookingId(), cachedInput);
    }

    private ArrayList<SlotInfoInput> getSlotInfoEntityListFromServiceSlotBooking(ServicesSlotsBookingInput input) {
        return (ArrayList<SlotInfoInput>) input.getSlotInfos().stream().filter(slotInfo -> Status.AVAILABLE.equals(slotInfo.getStatus())).collect(Collectors.toList());
    }

    private ApiResponse checkSlotsAvailabilityAndUpdateStatus(ServicesSlotsBookingInput input) {
        if (input != null && input.getSlotInfos() != null && input.getSlotInfos().size() > 0) {
            List<SlotInfoInput> inputSlotInfos = input.getSlotInfos();
            List<ServiceSlotBooking> serviceSlotBookings = serviceSlotBookingService.getBookingList(Arrays.asList(input.getShopId()), input.getServiceDate());


            //check slots availability status and update status accordingly
            for (SlotInfoInput inputSlotInfo : inputSlotInfos) {
                ShopServices service = null;

                //If any slot is already available and locked then no need to check again
                if (Status.AVAILABLE.equals(inputSlotInfo.getStatus())) {
                    continue;
                }
                if (inputSlotInfo.getShopServiceId() != null) {
                    service = shopServicesRepository.findOne(inputSlotInfo.getShopServiceId());
                }
                if (service == null) {
                    return new ApiResponse(ErrorCode.SHOP_SERVICE_NOT_FOUND, inputSlotInfo.getShopServiceId().toString());
                } else {
                    int maxSeat = service.getMaxSeat();
                    int requestedSeat = inputSlotInfo.getSeat();

                    Map<Integer, Integer> availableTimeSlotsWithSeatCount = listingService.getAvailableTimeSlotsWithSeatCount(service, serviceSlotBookings, DateTimeUtils.getTimeInMinFromCurrentTime(input.getServiceDate()));

                    if (availableTimeSlotsWithSeatCount != null && availableTimeSlotsWithSeatCount.size() > 0) {

                        int requestedSlot = inputSlotInfo.getSlot();
                        if (availableTimeSlotsWithSeatCount.containsKey(requestedSlot) && (maxSeat - availableTimeSlotsWithSeatCount.get(requestedSlot)) >= requestedSeat) {
                            //update status in Slot info as slot is available for booking;
                            inputSlotInfo.setDuration(service.getAvgTime());
                            inputSlotInfo.setStatus(Status.AVAILABLE);
                            inputSlotInfo.setServiceName(service.getName());
                        } else {
                            //check if next Slots are available then suggest otherwise send status as no Slots available
                            List<Integer> suggestedSlots = availableTimeSlotsWithSeatCount.keySet().stream().filter(availableSlot -> (maxSeat - availableTimeSlotsWithSeatCount.get(availableSlot)) >= requestedSeat).collect(Collectors.toList());
                            if (suggestedSlots.size() > 0) {
                                inputSlotInfo.setDuration(service.getAvgTime());
                                inputSlotInfo.setStatus(Status.CHOOSE_ANOTHER);
                                inputSlotInfo.setSuggestedSlots(suggestedSlots);
                            } else {
                                //set slot status as no slots available
                                inputSlotInfo.setStatus(Status.NOT_AVAILABLE);
                            }
                        }
                    } else {
                        //set slot status as no slots available
                        inputSlotInfo.setStatus(Status.NOT_AVAILABLE);
                    }
                }
            }
            return new ApiResponse();
        }
        return new ApiResponse(ErrorCode.NO_PARAM_IN_REQUEST);

    }

    private List<ServiceSlotBooking> getAvailableBookingSlotsEntitiesFromInput(ServicesSlotsBookingInput input) {
        return input.getSlotInfos().stream().filter(slotInfo -> Status.AVAILABLE.equals(slotInfo.getStatus())).map(slotInfo -> getServiceSlotBookingEntity(input, slotInfo)).collect(Collectors.toList());
    }

    private ServiceSlotBooking getServiceSlotBookingEntity(ServicesSlotsBookingInput input, SlotInfoInput slotInfo) {
        ServiceSlotBooking slotBooking = new ServiceSlotBooking();
        slotBooking.setUserId(input.getUserId());
        slotBooking.setShopId(input.getShopId());
        slotBooking.setServiceDate(input.getServiceDate());
        slotBooking.setShopServiceId(slotInfo.getShopServiceId());
        slotBooking.setSlot(slotInfo.getSlot());
        slotBooking.setDuration(slotInfo.getDuration());
        //In case of auto approval, set status as auto approved so that we need not to approve it again in case of final booking.
        if (input.isSlotApprovalAuto()) {
            slotBooking.setStatus(Status.AUTO_APPROVED);
        } else {
            slotBooking.setStatus(Status.PENDING);
        }
        slotBooking.setCreatedTime(LocalDateTime.now(ZoneId.of(TimeZoneList.IST.getZoneId())));
        slotBooking.setCreatedBy(authenticationService.getUser().getUsername());
        slotBooking.setModifiedTime(null);
        slotBooking.setBookingId(input.getBookingId() != null ? input.getBookingId() : UniqueIdGenerator.getId());
        //just set booking id here in input to avoid generating multiple booking id's for a single booking request
        input.setBookingId(slotBooking.getBookingId());
        return slotBooking;
    }

    private List<Booking> getBookingEntityList(List<ServiceSlotBooking> serviceSlotBookingList, BookingInput bookingInput) {
        List<Booking> bookingList = null;
        if (serviceSlotBookingList != null && serviceSlotBookingList.size() > 0 && bookingInput != null) {
            bookingList = new ArrayList<>(serviceSlotBookingList.size());
            for (ServiceSlotBooking serviceSlotBooking : serviceSlotBookingList) {
                Booking booking = getBookingEntity(serviceSlotBooking, bookingInput);
                bookingList.add(booking);
            }
        }
        return bookingList;
    }

    private Booking getBookingEntity(ServiceSlotBooking serviceSlotBooking, BookingInput bookingInput) {
        Booking booking = new Booking();
        booking.setBookingId(serviceSlotBooking.getBookingId());
        booking.setUserId(authenticationService.getUser().getUserId());
        booking.setShopId(serviceSlotBooking.getShopId());
        booking.setShopServiceId(serviceSlotBooking.getShopServiceId());
        //booking.setAddressId(); => need to clarify about
        booking.setSlot(serviceSlotBooking.getSlot());
        booking.setDuration(serviceSlotBooking.getDuration());
        booking.setServiceDate(serviceSlotBooking.getServiceDate());
        booking.setPaymentMode(bookingInput.getPaymentMode());
        booking.setPaymentId(bookingInput.getPaymentId());
        booking.setPaidAmount(bookingInput.getPaidAmount());
        booking.setPromoId(bookingInput.getPromoId());
        booking.setPromoCode(bookingInput.getPromoCode());
        booking.setStatus(bookingInput.getStatus());
        booking.setCreatedBy(authenticationService.getUser().getUsername());
        booking.setCreatedTime(LocalDateTime.now(ZoneId.of(TimeZoneList.IST.getZoneId())));

        ShopServices shopServices = shopServicesRepository.findOne(serviceSlotBooking.getShopServiceId());
        if (shopServices != null) {
            booking.setCatId(shopServices.getCatId());
            booking.setSubCatId(shopServices.getSubCatId());
            booking.setActualPrice(shopServices.getActPrice());
            booking.setDisFlat(shopServices.getDisFlat());
            booking.setDisPercent(shopServices.getDisPercent());
            booking.setLat(shopServices.getLat());
            booking.setLon(shopServices.getLon());
            booking.setDescription(shopServices.getDescription());
        }
        return booking;
    }

    private boolean isAllRequestedSlotsAreAvailable(ServicesSlotsBookingInput input) {
        boolean status = false;
        for (SlotInfoInput slotInfo : input.getSlotInfos()) {
            if (Status.AVAILABLE.equals(slotInfo.getStatus())) {
                status = true;
            }
        }
        return status;
    }

    //update slot info status based on input
    private void changeSlotInfoStatus(List<ServiceSlotBooking> serviceSlotBookingList, Status status) {
        for (ServiceSlotBooking slotBooking : serviceSlotBookingList) {
            slotBooking.setStatus(status);
        }

    }

    //update slot info status based on input
    private void changeSlotInfoStatus(ServicesSlotsBookingInput input, Status status) {
        for (SlotInfoInput slotInfo : input.getSlotInfos()) {
            slotInfo.setStatus(status);
        }

    }

    @Transactional
    private void validateAndUnlockSlotsIfChanged(ServicesSlotsBookingInput input) {
        //Only new user will have booking id as null. It means some of the slots are already been allotted to this booking id
        if (input.getBookingId() != null) {
            boolean isMatched = false;
            List<SlotInfoInput> slotsToBeUnlocked = new ArrayList<>();
            List<SlotInfoInput> cachedSlotInfos = availableSlotsConfStatus.get(input.getBookingId()).getSlotInfos();
            List<SlotInfoInput> inputSlotInfos = input.getSlotInfos();
            for (SlotInfoInput cachedSlotInfo : cachedSlotInfos) {
                for (SlotInfoInput inputSlotInfo : inputSlotInfos) {
                    if (cachedSlotInfo.getSlot() == inputSlotInfo.getSlot()) {
                        inputSlotInfo.setStatus(cachedSlotInfo.getStatus());
                        isMatched = true;
                    }
                }
                //It means slot has been changed by user so just add it to remove from cache as well as from database
                if (!isMatched) {
                    slotsToBeUnlocked.add(cachedSlotInfo);
                }
            }

            //remove slot from db as well as from cache
            if (slotsToBeUnlocked.size() > 0) {
                List<Integer> slots = new ArrayList<>();
                List<Long> serviceIds = new ArrayList<>();
                for (SlotInfoInput slotToBeUnlocked : slotsToBeUnlocked) {
                    cachedSlotInfos.remove(slotToBeUnlocked);
                    slots.add(slotToBeUnlocked.getSlot());
                    serviceIds.add(slotToBeUnlocked.getShopServiceId());
                }
                //delete from db as well by slot, requestId and serviceID
                Query query = entityManager.createQuery("delete from ServiceSlotBooking where bookingId = :id and shopServiceId in (:serviceIds) and slot in (:slots)");
                query.setParameter("id", input.getBookingId());
                query.setParameter("serviceIds", serviceIds);
                query.setParameter("slots", slots);
                int deletedRecords = query.executeUpdate();
                if (slotsToBeUnlocked.size() == deletedRecords) {
                    logger.debug("{} Slots has been unlocked successfully", deletedRecords);
                }
            }
        }
    }

    //TODO
    private List<FcmDataInput> preparePushNotificationEntityListFromInput(ServicesSlotsBookingInput input) {
        List<FcmDataInput> fcmDataInputs = new ArrayList<>();
        for (SlotInfoInput info : input.getSlotInfos()) {
            FcmDataInput fcmDataInput = new FcmDataInput();
            fcmDataInput.setReqId(input.getBookingId());
            fcmDataInput.setServiceId(info.getShopServiceId());
            fcmDataInput.setServiceName(info.getServiceName());
            fcmDataInput.setStartTime(info.getSlot());
            fcmDataInput.setAvgTime(info.getDuration());
            fcmDataInputs.add(fcmDataInput);
        }
        return fcmDataInputs;
    }

    //TODO
    private List<Booking> getBookingEntityFromInput(ServicesSlotsBookingInput input) {
        List<Booking> bookingList = new ArrayList<>();
        Booking booking = new Booking();
        //TODO
        return bookingList;
    }

    @Override
    public ApiResponse search(BookingSearchCriteria criteria, Pageable pageable) {
        if (criteria == null)
            return new ApiResponse(ErrorCode.NO_PARAM_IN_REQUEST);
        Page<Booking> pageWiseBookings = null;
        if (criteria.getStartDate() != null && criteria.getEndDate() != null) {
            pageWiseBookings = bookingRepository.findByModifiedTimeBetweenOrderByModifiedTimeDesc(criteria.getStartDate(), criteria.getEndDate(), pageable);
        } else if (!StringUtils.isEmpty(criteria.getStatus())) {
            pageWiseBookings = bookingRepository.findByStatusOrderByModifiedTimeDesc(criteria.getStatus(), pageable);
        } else if (criteria.getCatId() != null) {
            pageWiseBookings = bookingRepository.findByCatIdOrderByModifiedTimeDesc(criteria.getCatId(), pageable);
        } else if (criteria.getBookingId() != null) {
            pageWiseBookings = bookingRepository.findByBookingId(criteria.getBookingId(), pageable);
        } else if (criteria.getShopId() != null) {
            pageWiseBookings = bookingRepository.findByShopIdOrderByModifiedTimeDesc(criteria.getShopId(), pageable);
        } else if (criteria.getShopServiceId() != null) {
            pageWiseBookings = bookingRepository.findByShopServiceIdOrderByModifiedTimeDesc(criteria.getShopServiceId(), pageable);
        } else if (criteria.getAll()) {
            pageWiseBookings = bookingRepository.findAllByOrderByModifiedTimeDesc(pageable);
        }
        if (pageWiseBookings != null) {
            List<BookingOutput> bookingOutputList = fillBookingOutputDetails(pageWiseBookings);
            PageableResponse<BookingOutput> pageableResponse = new PageableResponse<>(bookingOutputList, pageWiseBookings);
            return new ApiResponse(pageableResponse);
        }

        //TODO getBookingsByUserID
        //TODO getBookingsForRangeOfDates
        return new ApiResponse(ErrorCode.UNKNOWN_EXCEPTION);
    }

    @Transactional
    private List<BookingOutput> fillBookingOutputDetails(Page<Booking> pageWiseBookings) {
        if (pageWiseBookings != null && pageWiseBookings.getSize() > 0) {
            Connection conn = null;
            PreparedStatement pst = null;
            ResultSet rs = null;
            Map<Long, BookingOutput> bookingOutputMap = new HashMap<>();
            for (Booking booking : pageWiseBookings) {
                BookingOutput bookingOutput = new BookingOutput();
                BeanUtils.copyProperties(booking, bookingOutput);
                bookingOutputMap.put(booking.getId(), bookingOutput);
            }
            String values = bookingOutputMap.keySet().toString().replaceAll("\\[|\\]| ", "");
            String query = "SELECT BKG.ID, USERS.NAME AS USER_NAME, S.NAME AS SHOP_NAME, SS.NAME AS SHOP_SERVICE_NAME, SS.SERVING_PERSON_NAME, S.ADDRESS AS SHOP_ADDRESS, CAT.NAME AS CATEGORY_NAME, SC.NAME AS SUB_CATEGORY_NAME FROM BOOKING BKG INNER JOIN SHOP S ON BKG.SHOP_ID = S.ID INNER JOIN SUB_CATEGORY SC ON BKG.SUB_CAT_ID = SC.ID INNER JOIN CATEGORY CAT ON BKG.CAT_ID = CAT.ID INNER JOIN USERS ON BKG.USER_ID = USERS.ID INNER JOIN SHOP_SERVICES SS ON BKG.SHOP_SERVICE_ID = SS.ID WHERE BKG.ID IN (" + values + ")";
            conn = getConnection();
            try {
                pst = conn.prepareStatement(query, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
                rs = pst.executeQuery();
                while (rs.next()) {
                    Long id = rs.getLong("ID");
                    BookingOutput output = bookingOutputMap.get(id);
                    output.setUserName(rs.getString("USER_NAME"));
                    output.setShopName(rs.getString("SHOP_NAME"));
                    output.setShopAddress(rs.getString("SHOP_ADDRESS"));
                    output.setCatName(rs.getString("CATEGORY_NAME"));
                    output.setSubCatName(rs.getString("SUB_CATEGORY_NAME"));
                    output.setShopServiceName(rs.getString("SHOP_SERVICE_NAME"));
                    output.setServingPersonName(rs.getString("SERVING_PERSON_NAME"));
                }
                return new ArrayList<>(bookingOutputMap.values());
            } catch (SQLException e) {
                logger.info("Exception while filling booking output details {}", e);
            } finally {
                SqlUtils.closeResources(conn, pst, rs);
            }
        }
        return null;
    }

    private Connection getConnection() {
        Connection conn = null;
        SessionImplementor sessionImpl = (SessionImplementor) entityManager.unwrap(Session.class);
        try {
            conn = sessionImpl.getJdbcConnectionAccess().obtainConnection();
        } catch (SQLException e) {
            logger.info("Getting an exception while trying to establish a connection {}", e.getMessage());
            logger.debug("Exception while trying to create a connection {}", e);
        }
        return conn;
    }
    
    @Async
    @Override
    public void changeStatus(BlockSlotInput blockServiceInput) {
    	List<LocalDate> blockingDates = blockServiceInput.getDates().stream().map(x -> x.getDate()).collect(Collectors.toList());
    	List<Booking> bookings = bookingRepository.findByShopServiceIdAndServiceDateInAndStatus(blockServiceInput.getServiceId(), blockingDates, Status.APPROVED);
    	bookings.forEach(x -> {x.setStatus(Status.CANCELLED);});
    	bookingRepository.save(bookings);
    	// notify customer and shopOwner about booking canceling
    }
}
