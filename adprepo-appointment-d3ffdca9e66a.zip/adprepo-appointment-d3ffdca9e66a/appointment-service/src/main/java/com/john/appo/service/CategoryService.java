/**
 *
 */
package com.john.appo.service;

import com.john.appo.input.CategorySubCategoryInput;
import com.john.appo.output.ApiResponse;

/**
 * @author nakesh
 */
public interface CategoryService {
    ApiResponse create(CategorySubCategoryInput input);

    ApiResponse update(CategorySubCategoryInput input);

    ApiResponse delete(Long id);

    ApiResponse get();
}
