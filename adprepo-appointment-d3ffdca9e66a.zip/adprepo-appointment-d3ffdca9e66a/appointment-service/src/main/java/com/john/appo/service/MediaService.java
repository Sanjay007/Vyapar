/**
 *
 */
package com.john.appo.service;

import com.john.appo.output.ApiResponse;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
 * @author nakesh
 */
public interface MediaService {
    ApiResponse uploadShopPics(MultipartFile[] files, Long shopId, Long shopServiceId, Boolean active, Long senderId);

    ApiResponse uploadProfilePic(MultipartFile[] files);

    ApiResponse downloadShopPics(HttpServletResponse response, String fileName);

    ApiResponse downloadProfilePic(HttpServletResponse response, String fileName);

    ApiResponse delete(Long shopid, Long serviceid, List<String> filenames);
}
