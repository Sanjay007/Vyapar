/**
 *
 */
package com.john.appo.service;

import com.john.appo.input.LoginInput;
import com.john.appo.input.UserInput;
import com.john.appo.output.ApiResponse;
import org.springframework.data.domain.Pageable;

/**
 * @author nakesh
 */
public interface AdminService {
    ApiResponse create(UserInput input);

    ApiResponse get(Long id);

    ApiResponse update(UserInput input);

    ApiResponse login(LoginInput input);

    ApiResponse get(Pageable page);

    ApiResponse resetPassword(LoginInput input);

    ApiResponse logout(Long adminId);

    ApiResponse forgot(String email);
}
