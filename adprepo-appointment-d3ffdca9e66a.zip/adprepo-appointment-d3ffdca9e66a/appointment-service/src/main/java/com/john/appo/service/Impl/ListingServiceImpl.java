package com.john.appo.service.Impl;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.john.appo.constants.C;
import com.john.appo.entity.BlockedSlot;
import com.john.appo.entity.Category;
import com.john.appo.entity.ServiceSlotBooking;
import com.john.appo.entity.Shop;
import com.john.appo.entity.ShopServices;
import com.john.appo.entity.repository.BlockedSlotRepository;
import com.john.appo.entity.repository.CategoryRepository;
import com.john.appo.entity.repository.FeedbackRepository;
import com.john.appo.entity.repository.ServiceSlotBookingRepository;
import com.john.appo.entity.repository.ShopRepository;
import com.john.appo.entity.repository.ShopServicesRepository;
import com.john.appo.enums.ErrorCode;
import com.john.appo.enums.Operation;
import com.john.appo.enums.TimeZoneList;
import com.john.appo.output.ApiResponse;
import com.john.appo.output.AvailableSlot;
import com.john.appo.output.CategoryModel;
import com.john.appo.output.PageableResponse;
import com.john.appo.output.ServiceModel;
import com.john.appo.output.ShopShopServiceAvailabilityModel;
import com.john.appo.service.ListingService;
import com.john.appo.utils.DateTimeUtils;

/**
 * @author nakesh
 */
@Service
public class ListingServiceImpl implements ListingService {

    private static final Logger logger = LoggerFactory.getLogger(ListingServiceImpl.class);

    @Autowired
    ShopServicesRepository shopServicesRepository;
    //  @Autowired
    //   BookingRepository bookingRepository;
    @Autowired
    ShopRepository shopRepository;
    @Autowired
    CategoryRepository categoryRepository;
    @Autowired
    FeedbackRepository feedbackRepository;
    @Autowired
    ServiceSlotBookingRepository serviceSlotBookingRepository;
    @Autowired BlockedSlotRepository blockedSlotRepository;

    @Value("${time.interval.between.slots.in.min:15}")
    int timeIntervalBetweenSlotsInMin;

    @Override
    public ApiResponse listing(Long subCatId, Float lat, Float lon, Integer pinCode, Double distance, LocalDate date, Pageable pageable) {

        ApiResponse response = validate(subCatId, lat, lon, distance, pinCode, date);
        if (!response.isSuccess()) {
            return response;
        }
        Page<ShopServices> shopServicesPageable = getShopServiceList(subCatId, lat, lon, pinCode, distance, pageable);
        List<ShopServices> shopServices = shopServicesPageable.getContent();
        if (shopServices.isEmpty()) {
            return new ApiResponse(new PageableResponse<ShopServices>(shopServices, shopServicesPageable));
        }
        shopServices = getUnBlockedServices(shopServices);
        Map<Long, ShopServices> shopIdShopServiceMap = shopServices.stream().collect(Collectors.toMap(c -> c.getShopId(), c -> c));
        List<Long> shopIds = shopIdShopServiceMap.keySet().stream().collect(Collectors.toList());
        List<Shop> shops = shopRepository.findAll(shopIds);
        List<ServiceSlotBooking> bookings = getBookingList(shopIds, date);
        Map<Long, List<ServiceSlotBooking>> shopIdBookingsMap = bookings.stream().collect(Collectors.groupingBy(c -> c.getShopId()));
        List<ShopShopServiceAvailabilityModel> shopModels = new ArrayList<>();
        for (Shop shop : shops) {
            ShopServices service = shopIdShopServiceMap.get(shop.getId());
            ShopShopServiceAvailabilityModel shopModel = getShopEntityToBean(shop, null, service.getDistance());
            ServiceModel serviceModel = getShopServiceEntityToBean(service);
            AvailableSlot availableSlot = new AvailableSlot();
            availableSlot.setDate(date);
            availableSlot.setSlots(getAvailableTimeSlots(service, shopIdBookingsMap.get(shop.getId()), DateTimeUtils.getTimeInMinFromCurrentTime(date)));
            serviceModel.setAvlSlots(Arrays.asList(availableSlot));
            shopModel.setDistance(service.getDistance());
            shopModel.setServices(Arrays.asList(serviceModel));
            shopModels.add(shopModel);
        }
        return new ApiResponse(new PageableResponse<ShopShopServiceAvailabilityModel>(shopModels, shopServicesPageable));
    }

    private List<ShopServices> getUnBlockedServices(List<ShopServices> shopServices) {
    	
		List<Long> shopServiceId = shopServices.stream().map(x -> x.getId()).collect(Collectors.toList());
		List<BlockedSlot> blockedSlots = blockedSlotRepository.findByShopServiceIdInAndDateAfter(shopServiceId, LocalDate.now());
		if(blockedSlots.isEmpty()) {
			return shopServices;
		}
		List<Long> blockedShoServiceIds = blockedSlots.stream().map(x -> x.getShopServiceId()).collect(Collectors.toList());
		List<ShopServices> unBlockedShopServices = new ArrayList<>();
		shopServices.forEach(x -> {
			if(!blockedShoServiceIds.contains(x.getId())) {
				unBlockedShopServices.add(x);
			}
		});
		return unBlockedShopServices;
	}

	@Override
    public List<ServiceSlotBooking> getBookingList(List<Long> shopIds, LocalDate date) {
        List<ServiceSlotBooking> bookings = null;
        if (date != null) {
            bookings = serviceSlotBookingRepository.findByShopIdInAndServiceDate(shopIds, date);
        } else {
            bookings = serviceSlotBookingRepository.findByShopIdIn(shopIds);
        }
        return bookings;
    }

    private Page<ShopServices> getShopServiceList(Long subCatId, Float lat, Float lon, Integer pincode, Double distance, Pageable pageable) {
        Page<ShopServices> shopServices = null;
        if (pincode != null) {   // based on subCatId, pincode
            shopServices = shopServicesRepository.findBySubCatIdAndPinCodeOrderByRatingDesc(subCatId, pincode, pageable);
        } else {                                // based on subCatId, lat, lon, distance
            shopServices = shopServicesRepository.findServicesBySubCatAndLocationAndDistance(subCatId, lat, lon, distance, pageable);
        }
        return shopServices;
    }

    // will filter shop based on shop_service rating in descending order and distance in ascending order.
    @Override
    public ApiResponse getShopsForSubCategory(Long subCatId, Float lat, Float lon, Integer pincode, Double distance, Pageable pageable) {
        ApiResponse response = validate(subCatId, lat, lon, distance, pincode, null);
        if (!response.isSuccess()) {
            return response;
        }
        Page<ShopServices> shopServicesPageable = getShopServiceList(subCatId, lat, lon, pincode, distance, pageable);
        List<ShopServices> shopServiceses = shopServicesPageable.getContent();
        if (shopServiceses.isEmpty()) {
            return new ApiResponse(new PageableResponse<ShopServices>(shopServiceses, shopServicesPageable));
        }
        shopServiceses = getUnBlockedServices(shopServiceses);
        List<Long> shopIds = getShopIds(shopServiceses);
        List<Shop> shops = shopRepository.findAll(shopIds);
        Map<Long, Shop> shopIdShopMap = getShopIdShopMap(shops);
        Map<Long, Integer> shopIdFeedbackCountMap = getshopIdFeedbackCountMap(shopIds);
        List<ShopShopServiceAvailabilityModel> shopsModels = new ArrayList<>();
        for (ShopServices shopService : shopServiceses) {
            shopsModels.add(getShopEntityToBean(shopIdShopMap.get(shopService.getShopId()),
                    shopIdFeedbackCountMap.get(shopService.getShopId()), shopService.getDistance()));
        }
        return new ApiResponse(new PageableResponse<ShopShopServiceAvailabilityModel>(shopsModels, shopServicesPageable));
    }

    private Map<Long, Integer> getshopIdFeedbackCountMap(List<Long> shopIds) {
        Map<Long, Integer> shopIdFeedbackCountMap = new HashMap<>();
        List<Object[]> feedbackCountshopWise = feedbackRepository.getFeedbackCountShopWise(shopIds, Operation.U_SS_FEEDBACK);
        if (feedbackCountshopWise.isEmpty()) {
            return shopIdFeedbackCountMap;
        }
        for (long shopId : shopIds) {
            for (Object[] object : feedbackCountshopWise) {
                long shopIdFromDb = (Long) object[0];
                if (shopId == shopIdFromDb) {
                    shopIdFeedbackCountMap.put(shopId, ((Long) object[1]).intValue());
                    break;  // got feedbackCount for shopId so break the loop
                }
            }
        }
        return shopIdFeedbackCountMap;
    }

    private List<Long> getShopIds(List<ShopServices> shopServiceses) {
        List<Long> shopIds = new ArrayList<>();
        for (ShopServices service : shopServiceses) {
            shopIds.add(service.getShopId());
        }
        return shopIds;
    }

    private Map<Long, Shop> getShopIdShopMap(List<Shop> shops) {
        Map<Long, Shop> shopIdShopMap = new HashMap<>();
        for (Shop shop : shops) {
            shopIdShopMap.put(shop.getId(), shop);
        }
        return shopIdShopMap;
    }

    @Override
    public ApiResponse getServicesForShopId(Long shopId) {
        Shop shop = shopRepository.findOne(shopId);
        if (shop == null) {
            return new ApiResponse();
        }
        List<ShopServices> services = shopServicesRepository.findByShopIdOrderByRatingDesc(shopId);
        ShopShopServiceAvailabilityModel shopModel = getShopEntityToBean(shop, null, null);
        List<ServiceModel> serviceModels = new ArrayList<>();
        for (ShopServices service : services) {
            ServiceModel serviceModel = getShopServiceEntityToBean(service);
            serviceModels.add(serviceModel);
        }
        shopModel.setServices(serviceModels);
        return new ApiResponse(shopModel);
    }

    // filter by category and shop_service rating in descending order.
    @Override
    public ApiResponse getServicesForShopId_2(Long shopId) {
        Shop shop = shopRepository.findOne(shopId);
        if (shop == null) {
            return new ApiResponse();
        }
        List<ShopServices> services = shopServicesRepository.findByShopIdOrderByRatingDesc(shopId);
        List<Long> categoryIds = findCategoryIds(services);
        List<Category> categories = categoryRepository.findAll(categoryIds);
        Map<Long, Category> catIdCatMap = categories.stream().collect(Collectors.toMap(x -> x.getId(), x -> x));
        Map<Long, List<ShopServices>> catIdShopServiceMap = services.stream().collect(Collectors.groupingBy(c -> c.getCatId()));
        ShopShopServiceAvailabilityModel shopModel = getShopEntityToBean(shop, null, null);
        List<CategoryModel> categoryModels = new ArrayList<>();
        for (Long catId : catIdShopServiceMap.keySet()) {
            CategoryModel categoryModel = getCategoryEntityToBean(catIdCatMap.get(catId));
            List<ShopServices> shopServices = catIdShopServiceMap.get(catId);
            List<ServiceModel> serviceModels = new ArrayList<>();
            for (ShopServices service : shopServices) {
                ServiceModel serviceModel = getShopServiceEntityToBean(service);
                serviceModels.add(serviceModel);
            }
            categoryModel.setServices(serviceModels);
            categoryModels.add(categoryModel);
        }

        shopModel.setCategories(categoryModels);
        return new ApiResponse(shopModel);
    }

    private List<Long> findCategoryIds(List<ShopServices> services) {
        List<Long> categoryIds = new ArrayList<>();
        for (ShopServices service : services) {
            if (!categoryIds.contains(service.getCatId())) {
                categoryIds.add(service.getCatId());
            }
        }
        return categoryIds;
    }

    private CategoryModel getCategoryEntityToBean(Category category) {
        CategoryModel categoryModel = new CategoryModel();
        categoryModel.setId(category.getId());
        categoryModel.setName(category.getName());
        return categoryModel;
    }


    public ApiResponse getAvailableSlotsForService(Long serviceId, LocalDate serviceDate) {
        //BookingServiceImpl.displayPaymentDetails();
        ApiResponse response = validateDate(serviceDate);
        if (!response.isSuccess()) {
            return response;
        }
        ShopServices service = shopServicesRepository.findOne(serviceId);
        if (service == null) {
            return new ApiResponse();
        }
        List<ServiceSlotBooking> bookings = getBookingList(Arrays.asList(service.getShopId()), serviceDate);
        List<String> avlSlots = getAvailableTimeSlots(service, bookings, DateTimeUtils.getTimeInMinFromCurrentTime(serviceDate));
        ServiceModel serviceModel = getShopServiceEntityToBean(service);
        AvailableSlot availableSlot = new AvailableSlot();
        availableSlot.setDate(serviceDate);
        availableSlot.setSlots(avlSlots);
        serviceModel.setAvlSlots(Arrays.asList(availableSlot));
        response.setData(serviceModel);
        return response;
    }

    @Override
    public List<String> getAvailableTimeSlots(ShopServices service, List<ServiceSlotBooking> bookings, int startBookingTimeOnlyForToday) {
        int maxSeat = service.getMaxSeat();
        int shopStartTime = service.getStartTime();
        int shopEndTime = service.getEndTime();
        int avgTime = service.getAvgTime();
        int breakStartTime = service.getBreakTime();
        int breakDuration = service.getBreakDuration();

        int breakEndTime = breakStartTime + breakDuration;
        int slotAssignmentEndTime = shopEndTime - avgTime;
        Map<Integer, Integer> slotAllottedWithSeatsCount = new LinkedHashMap<>();
        for (int slotStartTime = shopStartTime; slotStartTime <= slotAssignmentEndTime; slotStartTime = slotStartTime + timeIntervalBetweenSlotsInMin) {
            if (slotStartTime < startBookingTimeOnlyForToday) {
                // 1. startBookingTimeOnlyForToday : is time from when customer trying to book slot : applicable for current date service booking
                // 2. if customer want to book for future date then show time slots from shop opening time if slots available : here startBookingTimeOnlyForToday
                // will be 0 so that all slotStartTime is > startBookingTimeOnlyForToday
                continue;
            }
            int slotEndTime = slotStartTime + avgTime;
            if (slotStartTime >= breakEndTime || slotEndTime <= breakStartTime) {
                // outside break time
                slotAllottedWithSeatsCount.put(slotStartTime, C.ZERO);
            } else {
                // inside break time : no need to proceed further
                continue;
            }
            if (bookings != null) {
                for (ServiceSlotBooking booking : bookings) {
                    int bookedSlotStartTime = booking.getSlot();
                    int bookedSlotEndTime = bookedSlotStartTime + booking.getDuration();
                    if (slotStartTime >= bookedSlotEndTime || slotEndTime <= bookedSlotStartTime) {
                        // that means no booking for time between slotStartTime and slotEndTime yet done
                        continue;
                    } else {
                        slotAllottedWithSeatsCount.put(slotStartTime, slotAllottedWithSeatsCount.get(slotStartTime) + C.ONE);
                    }
                }
            }
        }
        logger.info("Final slot allotted and seat reserved count slot-wise: " + slotAllottedWithSeatsCount);
        logger.info("final slot allotted count slot-wise : " + slotAllottedWithSeatsCount);
        return slotAllottedWithSeatsCount.entrySet().stream().filter(x -> x.getValue() <= maxSeat).map(x -> x.getKey())
                .map(x -> DateTimeUtils.getTimeInHrMin(x)).collect(Collectors.toList());
    }

    @Override
    public Map<Integer, Integer> getAvailableTimeSlotsWithSeatCount(ShopServices service, List<ServiceSlotBooking> serviceSlotBookingList, int startBookingTimeOnlyForToday) {
        int shopStartTime = service.getStartTime();
        int shopEndTime = service.getEndTime();
        int avgTime = service.getAvgTime();
        int breakStartTime = service.getBreakTime();
        int breakDuration = service.getBreakDuration();

        int breakEndTime = breakStartTime + breakDuration;
        int slotAssignmentEndTime = shopEndTime - avgTime;
        Map<Integer, Integer> slotAllottedWithSeatsCount = new LinkedHashMap<>();
        for (int slotStartTime = shopStartTime; slotStartTime <= slotAssignmentEndTime; slotStartTime = slotStartTime + timeIntervalBetweenSlotsInMin) {
            if (slotStartTime < startBookingTimeOnlyForToday) {
                // 1. startBookingTimeOnlyForToday : is time from when customer trying to book slot : applicable for current date service booking
                // 2. if customer want to book for future date then show time slots from shop opening time if slots available : here startBookingTimeOnlyForToday
                // will be 0 so that all slotStartTime is > startBookingTimeOnlyForToday
                continue;
            }
            int slotEndTime = slotStartTime + avgTime;
            if (slotStartTime >= breakEndTime || slotEndTime <= breakStartTime) {
                // outside break time
                slotAllottedWithSeatsCount.put(slotStartTime, C.ZERO);
            } else {
                // inside break time : no need to proceed further
                continue;
            }
            if (serviceSlotBookingList != null && serviceSlotBookingList.size() > 0) {
                for (ServiceSlotBooking booking : serviceSlotBookingList) {
                    int bookedSlotStart = booking.getSlot();
                    int bookedSlotEnd = bookedSlotStart + booking.getDuration();
                    if (slotStartTime >= bookedSlotEnd || slotEndTime <= bookedSlotStart) {
                        // that means no booking for time between slotStartTime and slotEndTime yet done
                        continue;
                    } else {
                        slotAllottedWithSeatsCount.put(slotStartTime, slotAllottedWithSeatsCount.get(slotStartTime) + C.ONE);
                    }
                }
            }
        }
        logger.info("Final slot allotted and seat reserved count slot-wise: " + slotAllottedWithSeatsCount);
        return slotAllottedWithSeatsCount;
    }

    private ShopShopServiceAvailabilityModel getShopEntityToBean(Shop shop, Integer totalFeedback, Double distance) {
        ShopShopServiceAvailabilityModel shopModel = new ShopShopServiceAvailabilityModel();
        shopModel.setId(shop.getId());
        shopModel.setName(shop.getName());
        shopModel.setMobile(shop.getMobile());
        shopModel.setAddress(shop.getAddress());
        shopModel.setLat(shop.getLat());
        shopModel.setLon(shop.getLon());
        shopModel.setStartTime(shop.getStartTime());
        shopModel.setEndTime(shop.getEndTime());
        shopModel.setRating(shop.getRating());
        if (totalFeedback != null) {
            shopModel.setTotalFeedback(totalFeedback);
        }
        shopModel.setDistance(distance);
        shopModel.setWorkingDays(Arrays.asList(shop.getWorkingDays()));
        shopModel.setFiles(shop.getFiles());
        return shopModel;
    }

    private ServiceModel getShopServiceEntityToBean(ShopServices service) {
        ServiceModel serviceModel = new ServiceModel();
        serviceModel.setId(service.getId());
        serviceModel.setName(service.getName());
        serviceModel.setActPrice(service.getActPrice());
        serviceModel.setDisFlat(service.getDisFlat());
        serviceModel.setDisPercent(service.getDisPercent());
        serviceModel.setDescription(service.getDescription());
        serviceModel.setRating(service.getRating());
        serviceModel.setServingPersonName(service.getServingPersonName());
        serviceModel.setFiles(service.getFiles());
        serviceModel.setAvgTime(service.getAvgTime());
        return serviceModel;
    }

    ApiResponse validate(Long subCatId, Float lat, Float lon, Double distance, Integer pincode, LocalDate date) {
        if (subCatId == null || (lat != null && lon == null) || (lon != null && lat == null)
                || (lat == null && lon == null && pincode == null)) {   // add more validation when required
            return new ApiResponse(ErrorCode.INPUT_PARAM_NOT_CORRECT);
        }
        return date == null ? new ApiResponse() : validateDate(date);
    }

    private ApiResponse validateDate(LocalDate serviceBookingDate) {
        if (serviceBookingDate == null || serviceBookingDate.isBefore(LocalDate.now(ZoneId.of(TimeZoneList.IST.getZoneId())))) {
            return new ApiResponse(ErrorCode.INVALID_DATE);
        }
        return new ApiResponse();
    }
}
