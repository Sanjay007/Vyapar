/**
 *
 */
package com.john.appo.loader;

import com.john.appo.constants.C;
import com.john.appo.constants.Roles;
import com.john.appo.entity.*;
import com.john.appo.entity.repository.*;
import com.john.appo.enums.*;
import com.john.appo.output.ApiResponse;
import com.john.appo.utils.UniqueIdGenerator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.*;
import java.util.stream.Collectors;

/**
 * @author nakesh
 */
@Component
public class SeedData {
    private static final Logger logger = LoggerFactory.getLogger(SeedData.class);

    @Autowired
    UserRepository userRepository;
    @Autowired
    AdminRepository adminRepository;
    @Autowired
    CategoryRepository categoryRepo;
    @Autowired
    SubCategoryRepository subCategoryRepo;
    @Autowired
    ShopRepository shopRepo;
    @Autowired
    ShopServicesRepository shopServiceRepo;
    @Autowired
    BookingRepository bookingRepo;
    @Autowired
    TruncateDatabaseService truncateDatabaseService;
    @Autowired
    ServiceSlotBookingRepository serviceSlotBookingRepository;

    public ApiResponse load(int numberOfShop) {
        // Todo : setup this to run only dev env.
        logger.info("<----------------- Seeddata loading started ----------------->");
        try {
            truncateDatabaseService.truncate();
            logger.info("<------------ Truncated old records --------->");
        } catch (Exception e) {
            logger.error("Got Exception SeedData.load() : " + e.getMessage());
            e.printStackTrace();
        }
        addSuperAdmin(1);
        logger.info("<------------ Added super admin ------------>");
        addAdmin(3);
        logger.info("<------------ Added shop admins ------------>");
        List<Long> userIds = addUser(2);
        logger.info("<------------ Added users ------------------>");
        addCategory();
        logger.info("<------------ Added Categories ------------->");
        Map<Long, List<SubCategory>> catSubCatMap = addSubCategory();
        logger.info("<------------ Added sub categories --------->");
        addShop(numberOfShop);
        logger.info("<------------ Added shops ------------------>");
        Map<Long, List<Long>> shopIdShopServiceIdMap = addShopService_2(catSubCatMap);
        logger.info("<------------ Added shop services ---------->");
        booking(shopIdShopServiceIdMap, LocalDate.now(ZoneId.of(TimeZoneList.IST.getZoneId())));
        logger.info("<------------ Added bookings --------------->");
        logger.info("<----------------- Seeddata loaded -------------------->");
        return new ApiResponse();
    }

    private void addSuperAdmin(int count) {
        for (int i = 1; i <= 1; i++) {
            Admin admin = new Admin("superAdmin_" + i, "superadmin_" + i + "@gmail.com", "password", "123456789" + i, UserType.SUPER, Sex.M,
                    null, Roles.ROLE_SUPER_ADMIN, null, -33.737885f, 151.235260f, true, true);
            admin.setCreatedBy("DataLoader");
            adminRepository.saveAndFlush(admin);
        }
    }

    private void addAdmin(int count) {
        for (int i = 1; i <= count; i++) {
            Admin admin = new Admin("admin_" + i, "admin_" + i + "@gmail.com", "password", "123456789" + i, UserType.ADMIN, Sex.M,
                    null, Roles.ROLE_ADMIN_WRITE, null, -33.737885f, 151.235260f, true, true);
            admin.setCreatedBy("DataLoader");
            adminRepository.saveAndFlush(admin);
        }
    }

    private List<Long> addUser(int count) {
        List<Long> userIds = new ArrayList<>();
        for (int i = 1; i <= count; i++) {
            User user = new User("user_" + i, "user_" + i + "@gmail.com", "password", "123456789" + i, -33.737885f, 151.235260f, UserType.USER,
                    Sex.F, null, Roles.ROLE_USER, null, Language.EN, LocalDateTime.now(ZoneId.of(TimeZoneList.IST.getZoneId())), Device.ANDROID, Status.APPROVED);
            user.setCreatedTime(LocalDateTime.now(ZoneId.of(TimeZoneList.IST.getZoneId())));
            user.setCreatedBy("DataLoader");
            user = userRepository.saveAndFlush(user);
            userIds.add(user.getId());
        }
        return userIds;
    }

    private void addCategory() {
        List<Long> categoryIds = new ArrayList<>();
        Category category = new Category();
        category.setName("Hair cutting");

        category = new Category();
        category.setName("Hair cutting");
        category = categoryRepo.saveAndFlush(category);
        categoryIds.add(category.getId());
    }


    private Map<Long, List<SubCategory>> addSubCategory() {
        List<Long> categoryIds = categoryRepo.findAll().stream().map(Category::getId).collect(Collectors.toList());
        Map<Long, List<SubCategory>> catSubCatMap = new LinkedHashMap<>();
        for (long i = 1l; i <= categoryIds.size(); i++) {
            List<SubCategory> subCategories = new ArrayList<>();
            for (DummySubCategory subCategoryEnum : DummySubCategory.values()) {  // taking value from enum
                SubCategory subCategory = new SubCategory();
                subCategory.setCatId(i);
                subCategory.setName(subCategoryEnum.getName());
                subCategory = subCategoryRepo.saveAndFlush(subCategory);
                subCategories.add(subCategory);
            }
            catSubCatMap.put(i, subCategories);
        }
        return catSubCatMap;
    }

    private void addShop(int numberOfShop) {
        List<Long> shopIds = new ArrayList<>();
        for (int i = 0; i < numberOfShop; i++) {
            DummyShop ds = DummyShop.values()[i];
            Shop shop = new Shop(ds.getOwnerId(), ds.getName(), 1234567890l, 1234567890l,
                    Float.parseFloat(ds.getLat()), Float.parseFloat(ds.getLng()), "streetname_" + ds.getId(),
                    ds.getPlace(), ds.getPlace(), "state_" + ds.getId(), "city_" + ds.getId(),
                    ds.getPinCode(), ds.getAddress(), ds.getWorkingDays(), ds.getMaxSheat(), ds.getStartTime(),
                    ds.getEndTime(), ds.getBreakTime(), ds.getBreakDuration(), ds.getRating(), "we are specialist", true, true);
            shop.setCreatedTime(LocalDateTime.now(ZoneId.of(TimeZoneList.IST.getZoneId())));
            shop.setCreatedBy("DataLoader");
            shop = shopRepo.saveAndFlush(shop);
            shopIds.add(shop.getId());
        }
    }

    private Map<Long, List<Long>> addShopService_2(Map<Long, List<SubCategory>> catSubCatMap) {
        Map<Long, List<Long>> shopIdShopServiceIdMap = new LinkedHashMap<>();
        //	List<Long> shopIds = shopRepo.findAll().stream().map(Shop :: getId).collect(Collectors.toList());
        List<Shop> shopList = shopRepo.findAllByOrderByCreatedTimeAsc();
        int firstShopId = shopList.get(0).getId().intValue();
        Map<Long, Shop> shopMap = shopRepo.findAll().stream().collect(Collectors.toMap(x -> x.getId(), x -> x));
        for (Long catId : catSubCatMap.keySet()) {
            List<SubCategory> subCategoryIds = catSubCatMap.get(catId);
            for (Long i = 1l; i <= subCategoryIds.size(); i++) {
                int noFofShops = 0;
                if (i == 1) {
                    noFofShops = shopMap.size();
                } else if (i == 2) {
                    noFofShops = shopMap.size() > 2 ? 2 : 1;
                } else if (i == 3) {
                    noFofShops = 1;
                } else {
                    continue;
                }
                for (long j = firstShopId; j <= firstShopId + noFofShops - 1; j++) {
                    int avgTime = 30;
                    if (j % 5 == 0) {
                        avgTime = 15;
                    }
                    Shop shop = shopMap.get(j);
                    ShopServices shopServices = new ShopServices(shop.getOwnerId(), j, catId, i, subCategoryIds.get(i.intValue()).getName(), "personname_" + i, "work with passion",
                            shop.getLat(), shop.getLon(), 100.00, 10.00, 0, shop.getWorkingDays(), avgTime, shop.getMaxSeat(),
                            shop.getStartTime(), shop.getEndTime(), shop.getBreakTime(), shop.getBreakDuration(), shop.getPinCode(), shop.getRating(), true, true);
                    shopServices.setCreatedTime(LocalDateTime.now(ZoneId.of(TimeZoneList.IST.getZoneId())));
                    shopServices.setCreatedBy("DataLoader");
                    shopServices = shopServiceRepo.saveAndFlush(shopServices);
                    if (shopIdShopServiceIdMap.containsKey(j)) {
                        shopIdShopServiceIdMap.get(j).add(shopServices.getId());
                    } else {
                        List<Long> shopServiceIds = new ArrayList<>();
                        shopServiceIds.add(shopServices.getId());
                        shopIdShopServiceIdMap.put(j, shopServiceIds);
                    }
                }
            }
        }
        return shopIdShopServiceIdMap;
    }

    private void booking(Map<Long, List<Long>> shopIdShopServiceIdMap, LocalDate bookingDate) {
        Map<String, Integer> shopMaxBookingMap = new HashMap<>();
        List<ServiceSlotBooking> slotBookingList = new ArrayList<>();
        List<Booking> bookings = new ArrayList<>();
        for (Long shopId : shopIdShopServiceIdMap.keySet()) {
            String bookingId = UniqueIdGenerator.getId();
            List<Long> shopServiceIds = shopIdShopServiceIdMap.get(shopId);
            for (int i = 1; i <= shopServiceIds.size(); i++) {

                ShopServices shopServices = shopServiceRepo.findOne(shopServiceIds.get(i - 1));
                for (int startTime = shopServices.getStartTime(); startTime <= (shopServices.getEndTime() - shopServices.getAvgTime()); startTime = startTime + shopServices.getAvgTime()) {
                    for (int j = 1; j <= shopServices.getMaxSeat(); j++) {
                        //restrict max count for given slot for a shop
                        String shopDateSlot = shopServices.getShopId().toString() + "_" + String.valueOf(bookingDate) + "_" + String.valueOf(startTime);
                        if ((shopMaxBookingMap.get(shopDateSlot) == null ? 0 : shopMaxBookingMap.get(shopDateSlot)) == (shopServices.getMaxSeat() - 1)   // only book 3 sheats out of maxSheat 4
                                || !(startTime >= (shopServices.getBreakTime() + shopServices.getBreakDuration()) || (startTime + shopServices.getAvgTime()) <= shopServices.getBreakTime())) {  // don't book in break time
                            break;
                        }
                        //store into service_slot_booking table
                        slotBookingList.add(new ServiceSlotBooking(bookingId, 1l, shopServices.getShopId(), shopServices.getId(), bookingDate, startTime, shopServices.getAvgTime(), Status.BOOKED, LocalDateTime.now(ZoneId.of(TimeZoneList.IST.getZoneId())), "DataLoader"));
                        //store into booking table
                        Booking booking = new Booking(bookingId, 1l, shopServices.getShopId(), shopServices.getCatId(), shopServices.getSubCatId(), shopServices.getId(), 1l, startTime, shopServices.getAvgTime(), bookingDate, PaymentMode.OFFLINE, UniqueIdGenerator.getId(), 100.00, 90.00, 10.00, 0, 1l, "PROMO_ID", Status.BOOKED, -33.737885f, 151.235260f,
                                "baal katana hai, bahut jhr raha hai");
                        booking.setCreatedTime(LocalDateTime.now(ZoneId.of(TimeZoneList.IST.getZoneId())));
                        booking.setModifiedTime(null);
                        booking.setCreatedBy("DataLoader");
                        bookings.add(booking);

                        shopMaxBookingMap.put(shopDateSlot, shopMaxBookingMap.containsKey(shopDateSlot) ? shopMaxBookingMap.get(shopDateSlot) + C.ONE : C.ONE);
                    }
                }
            }
        }
        serviceSlotBookingRepository.save(slotBookingList);
        bookingRepo.save(bookings);
    }
}
