/**
 * 
 */
package com.john.appo.service;

import com.john.appo.input.BlockSlotInput;
import com.john.appo.output.ApiResponse;

/**
 * @author nakesh
 *
 */
public interface BlockSlotService {

	ApiResponse blockSlot(BlockSlotInput input);

}
