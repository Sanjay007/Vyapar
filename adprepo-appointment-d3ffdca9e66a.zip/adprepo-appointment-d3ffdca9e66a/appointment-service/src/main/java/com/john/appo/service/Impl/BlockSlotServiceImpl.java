/**
 * 
 */
package com.john.appo.service.Impl;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.john.appo.security.UserRecord;
import com.john.appo.security.service.AuthenticationService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.john.appo.entity.BlockedSlot;
import com.john.appo.entity.ShopServices;
import com.john.appo.entity.repository.BlockedSlotRepository;
import com.john.appo.entity.repository.ShopServicesRepository;
import com.john.appo.enums.ErrorCode;
import com.john.appo.enums.UserType;
import com.john.appo.input.BlockSlotInput;
import com.john.appo.model.DateWiseBlockingSlots;
import com.john.appo.output.ApiResponse;
import com.john.appo.service.BlockSlotService;
import com.john.appo.service.BookingService;

/**
 * @author nakesh
 *
 */
@Service
public class BlockSlotServiceImpl implements BlockSlotService {
	
	private static final Logger logger = LoggerFactory.getLogger(BlockSlotServiceImpl.class);
	
	@Autowired ShopServicesRepository shopServiceRepository;
	@Autowired BlockedSlotRepository blockedSlotRepository;
	 @Autowired BookingService bookingService;
	 @Autowired
     AuthenticationService authService;
	
	@Override
	public ApiResponse blockSlot(BlockSlotInput input) {
		ApiResponse response = validateInput(input);
		if(!response.isSuccess()) {
			return response;
		}
		ShopServices shopService = shopServiceRepository.findOne(input.getServiceId());
		List<BlockedSlot> blockedSlots = new ArrayList<>();
		List<DateWiseBlockingSlots> dates = input.getDates();
		List<ShopServices> shopServices = shopServiceRepository.findByShopId(shopService.getShopId());
		shopServices.forEach(x -> {
			dates.forEach(y -> {
				BlockedSlot bs = new BlockedSlot();
				bs.setShopId(x.getShopId());
				bs.setShopServiceId(x.getId());
				bs.setDate(y.getDate());
				bs.setReason(input.getReason());
				blockedSlots.add(bs);
			});
		});
		blockedSlotRepository.save(blockedSlots);
		bookingService.changeStatus(input);
		return new ApiResponse();
	}

	private ApiResponse validateInput(BlockSlotInput input) {
		if(input.getServiceId() == null) {
			logger.info("ShopServicesImpl-validateInput: SHOP_SERVICE_NOT_FOUND: serviceId-{}", input.getServiceId()); 
			return new ApiResponse(ErrorCode.SHOP_SERVICE_NOT_FOUND);
		}
		UserRecord userRecord = authService.getUser();
		ShopServices shopService = shopServiceRepository.findOne(input.getServiceId());
		if(shopService == null) {
			logger.info("ShopServicesImpl-validateInput: SHOP_SERVICE_NOT_FOUND: serviceId-{}, shopservice-{}", input.getServiceId(), shopService); 
			return new ApiResponse(ErrorCode.SHOP_SERVICE_NOT_FOUND);
		}
		if(userRecord.getUserType() == UserType.ADMIN && !userRecord.getUserId().equals(shopService.getShopOwnerId())) {
			logger.info("ShopServicesImpl-validateInput: SHOP_SERVICE_NOT_FOUND: serviceId-{}, shopOwnerId-{}, loggedInUserId-{}", input.getServiceId(), shopService.getShopOwnerId(), userRecord.getUserId()); 
			return new ApiResponse(ErrorCode.SHOP_SERVICE_NOT_FOUND, String.valueOf(shopService.getId()));
		}
		List<DateWiseBlockingSlots> dates = input.getDates();
		if(dates == null || dates.isEmpty()) {
			logger.info("ShopServicesImpl-validateInput: INPUT_PARAM_NOT_CORRECT: dates-{}", dates); 
			return new ApiResponse(ErrorCode.INPUT_PARAM_NOT_CORRECT);
		}
		for(DateWiseBlockingSlots dateWiseBlockingSlots : dates) {
			if(!dateWiseBlockingSlots.getDate().isAfter(LocalDate.now())) {    // if blocked date is not greater than current date then should not allowed
				logger.info("ShopServicesImpl-validateInput: BLOCKING_DATE_SHOULD_BE_GREATER_THAN_TODAYS_DATE: dates-{}", dates); 
				return new ApiResponse(ErrorCode.BLOCKING_DATE_SHOULD_BE_GREATER_THAN_TODAYS_DATE);
			}
		}
		return new ApiResponse();
	}

}
