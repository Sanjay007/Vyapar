package com.john.appo.controller;

import com.john.appo.constants.C;
import com.john.appo.input.BookingInput;
import com.john.appo.input.ServicesSlotsBookingInput;
import com.john.appo.output.ApiResponse;
import com.john.appo.output.FcmDataOutput;
import com.john.appo.search.BookingSearchCriteria;
import com.john.appo.service.BookingService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(value = C.BOOKING, consumes = {MediaType.APPLICATION_JSON_VALUE}, produces = {MediaType.APPLICATION_JSON_VALUE})
public class BookingController {
    private static final Logger logger = LoggerFactory.getLogger(BookingController.class);

    @Autowired
    BookingService bookingService;


    //@Secured({Roles.ROLE_USER})
    @RequestMapping(value = C.VALIDATE_AND_LOCK_AVL_SLOTS, method = RequestMethod.POST)
    public ApiResponse validateAndLockAvailableSlots(@RequestBody ServicesSlotsBookingInput input) {
        logger.info("user having 'USER' role can access this method");
        return bookingService.validateAndLockAvailableSlotsForBooking(input);
    }

    //@Secured({Roles.ROLE_USER})
    @RequestMapping(value = C.BOOK, method = RequestMethod.POST)
    public ApiResponse book(@RequestBody BookingInput bookingInput) {
        logger.info("user having 'USER' role can access this method");
        return bookingService.book(bookingInput);
    }

    //@Secured({Roles.ROLE_USER})
    @RequestMapping(value = C.SLOTS_AVAILABILITY_CNF_STATUS, method = RequestMethod.GET)
    public ApiResponse getSlotsAvailabilityConfirmationStatus(@RequestParam(required = true) Long userId, @RequestParam(required = true) String bookingId) {
        logger.info("user having 'USER' role can access this method");
        return bookingService.getSlotsAvailabilityConfStatus(userId, bookingId);
    }

    //@Secured({Roles.ROLE_ADMIN})
    @RequestMapping(value = C.UPDATE_SLOTS_BOOKING_STATUS, method = RequestMethod.POST)
    public ApiResponse updateServiceSlotBookingStatus(@RequestBody List<FcmDataOutput> dataList) {
        return bookingService.updateServicesSlotsBookingStatus(dataList);
    }

    //@Secured({Roles.ROLE_ADMIN})
    @RequestMapping(value = C.BLOCK_SLOTS_RESV, method = RequestMethod.POST)
    public ApiResponse blockSlotsReservation(@RequestBody ServicesSlotsBookingInput input) {
        return bookingService.blockSlotsReservation(input);
    }

    //@Secured({Roles.ROLE_ADMIN})
    @RequestMapping(value = C.UNBLOCK_SLOTS_RESV, method = RequestMethod.POST)
    public ApiResponse unblockSlotsReservation(@RequestBody ServicesSlotsBookingInput input) {
        return bookingService.unblockSlotsReservation(input);
    }


    //@Secured({Roles.ROLE_USER})
    @RequestMapping(value = C.SEARCH, method = RequestMethod.POST)
    public ApiResponse search(@RequestBody BookingSearchCriteria criteria, Pageable pageable) {
        logger.info("user having 'USER' role can access this method");
        return bookingService.search(criteria, pageable);
    }
}
