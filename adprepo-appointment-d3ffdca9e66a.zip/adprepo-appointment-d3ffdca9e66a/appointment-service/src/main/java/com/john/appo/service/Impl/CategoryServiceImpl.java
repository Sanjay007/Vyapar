/**
 *
 */
package com.john.appo.service.Impl;

import com.john.appo.entity.Category;
import com.john.appo.entity.SubCategory;
import com.john.appo.entity.repository.CategoryRepository;
import com.john.appo.entity.repository.SubCategoryRepository;
import com.john.appo.enums.ErrorCode;
import com.john.appo.input.CategorySubCategoryInput;
import com.john.appo.output.ApiResponse;
import com.john.appo.service.CategoryService;
import com.john.appo.service.SubCategoryService;
import org.apache.maven.shared.utils.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.List;


/**
 * @author nakesh
 */
@Service
public class CategoryServiceImpl implements CategoryService {

    @Autowired
    CategoryRepository categoryRepository;
    @Autowired
    SubCategoryRepository subCategoryRepository;
    @Autowired
    SubCategoryService subCategoryService;

    @Override
    public ApiResponse create(CategorySubCategoryInput input) {
        if (input.getNames() == null || input.getNames().isEmpty()) {
            return new ApiResponse(ErrorCode.INPUT_PARAM_NOT_CORRECT);
        }
        List<Category> categories = new ArrayList<>();
        // for batch update
        for (String categoryName : input.getNames()) {
            Category category = new Category();
            category.setName(categoryName);
            categories.add(category);
        }
        categoryRepository.save(categories);
        // Todo : send notification to all device to get update of categorySubCategoryList

        // return all saved categories subCategories in response
        return subCategoryService.getAllCatSubCategories();
    }

    @Override
    public ApiResponse update(CategorySubCategoryInput input) {
        if (input.getId() == null || StringUtils.isBlank(input.getName())) {
            return new ApiResponse(ErrorCode.INPUT_PARAM_NOT_CORRECT);
        }
        Category category = categoryRepository.findOne(input.getId());
        if (category == null) {
            return new ApiResponse(ErrorCode.CATEGORY_NOT_FOUND, String.valueOf(input.getId()));
        }
        // update name
        category.setName(input.getName());
        categoryRepository.save(category);
        // Todo : send notification to all device to get update of categorySubCategoryList

        // return all saved categories subCategories in response
        return subCategoryService.getAllCatSubCategories();
    }

    @Override
    @Transactional
    public ApiResponse delete(Long id) {
        Category category = categoryRepository.findOne(id);
        if (category == null) {
            return new ApiResponse(ErrorCode.CATEGORY_NOT_FOUND, String.valueOf(id));
        }
        // delete from subCategory
        List<SubCategory> subCategories = subCategoryRepository.findByCatId(id);
        subCategoryRepository.delete(subCategories);

        //delete from category
        categoryRepository.delete(category);
        // Todo : send notification to all device to get update of categorySubCategoryList

        // return all saved categories subCategories in response
        return subCategoryService.getAllCatSubCategories();
    }

    @Override
    public ApiResponse get() {
        // return all saved categories subCategories in response
        return subCategoryService.getAllCatSubCategories();
    }

}
