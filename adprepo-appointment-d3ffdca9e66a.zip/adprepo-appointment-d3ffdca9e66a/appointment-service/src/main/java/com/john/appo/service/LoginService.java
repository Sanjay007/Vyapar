/**
 *
 */
package com.john.appo.service;

import com.john.appo.input.LoginInput;
import com.john.appo.output.ApiResponse;

/**
 * @author nakesh
 */
public interface LoginService {
    ApiResponse login(LoginInput input);

    ApiResponse resetPassword(LoginInput input);

    ApiResponse logout();

    ApiResponse forgot(LoginInput input);
}
