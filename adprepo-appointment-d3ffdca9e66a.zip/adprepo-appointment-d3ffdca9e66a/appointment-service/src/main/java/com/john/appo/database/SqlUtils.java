package com.john.appo.database;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * @author Krishna
 */

public class SqlUtils {

    static private Logger logger = LoggerFactory.getLogger(SqlUtils.class);

    public static void closeResources(Connection conn, Statement statement, ResultSet set) {
        closeResources(statement, set);
        closeResources(conn);
    }

    public static void closeResources(Statement statement, ResultSet set) {
        closeResources(set);
        closeResources(statement);
    }

    public static void closeResources(Connection con, Statement statement) {
        closeResources(con);
        closeResources(statement);
    }

    public static void closeResources(Statement set) {
        if (set != null)
            try {
                set.close();
            } catch (Exception e) {
            }
    }

    public static void closeResources(ResultSet set) {
        if (set != null)
            try {
                set.close();
            } catch (Exception e) {
            }
    }

    public static void closeResources(Connection con) {
        if (con != null)
            try {
                if (!con.isClosed()) {
                    con.close();
                }
            } catch (Exception e) {
            }
    }

    public static void commit(Connection conn) {
        try {
            if (conn != null)
                conn.commit();
        } catch (SQLException e) {
            //ignore
        }
    }

    public static void rollback(Connection conn) {
        try {
            if (conn != null)
                conn.rollback();
        } catch (SQLException e) {
            //ignore
        }
    }

    public static void showExceptionInfo(SQLException e) {
        logger.error("SQL Error code: {}", e.getErrorCode());
        logger.error("SQL State: {} ", e.getSQLState());
        logger.error("Message: {}", e.getMessage());
        logger.error("Stack Trace: ", e);
        SQLException act = e;
        while ((act = act.getNextException()) != null) {
            logger.error("NEXT: SQL Error code: {} ", e.getErrorCode());
            logger.error("NEXT: SQL State: {}", e.getSQLState());
            logger.error("NEXT: Message: {}", e.getMessage());
            logger.error("Stack Trace: {}", e);
        }
    }
}
