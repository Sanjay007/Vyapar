/**
 *
 */
package com.john.appo.service;

import com.john.appo.input.ShopInput;
import com.john.appo.output.ApiResponse;
import org.springframework.data.domain.Pageable;

/**
 * @author nakesh
 */
public interface ShopService {
    ApiResponse create(ShopInput input);

    ApiResponse update(ShopInput input);

    ApiResponse delete(Long id);

    ApiResponse get(Long id);

    ApiResponse get(Pageable page);

    ApiResponse validateInput(ShopInput input);

    ApiResponse updateActivationAndApproval(Long id, Integer activate, Integer approve);
}
