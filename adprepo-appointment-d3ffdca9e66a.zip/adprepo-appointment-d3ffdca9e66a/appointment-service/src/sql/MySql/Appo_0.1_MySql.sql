DROP DATABASE IF EXISTS appointment;

CREATE SCHEMA appointment;

CREATE USER 'appointment'@'%' IDENTIFIED BY 'appointment' PASSWORD EXPIRE NEVER;

GRANT ALL PRIVILEGES ON appointment.* TO 'appointment'@'%';

USE appointment;

DROP TABLE IF EXISTS users;

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) DEFAULT NULL,
  `mobile` bigint(10) NOT NULL,
  `user_type` varchar(10) DEFAULT NULL,
  `sex` varchar(5) DEFAULT NULL,
  `pro_image` varchar(100) DEFAULT NULL,
  `lat` float(10,6) DEFAULT 0,
  `lon` float(10,6) DEFAULT 0,
  `created_time` datetime DEFAULT NULL,
  `created_by` varchar(30) DEFAULT NULL,
  `modified_by` varchar(30) DEFAULT NULL,
  `modified_time` datetime DEFAULT NULL,
  `roles` varchar(100) DEFAULT NULL,
  `otp` varchar(6) DEFAULT NULL,
  `active` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS admin;

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) DEFAULT NULL,
  `mobile` bigint(10) NOT NULL,
  `user_type` varchar(10) DEFAULT NULL,
  `sex` varchar(5) DEFAULT NULL, 
  `pro_image` varchar(100) DEFAULT NULL,
  `lat` float(10,6) DEFAULT '0.000000',
  `lon` float(10,6) DEFAULT '0.000000',
  `created_time` datetime DEFAULT NULL,
  `created_by` varchar(30) DEFAULT NULL,
  `modified_by` varchar(30) DEFAULT NULL,
  `modified_time` datetime DEFAULT NULL,
  `roles` varchar(100) DEFAULT NULL,
  `otp` varchar(6) DEFAULT NULL,
  `active` tinyint(1) DEFAULT '1',
  `approved` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS category;

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS sub_category;

CREATE TABLE `sub_category` (
  `id` int(11) NOT NULL,
  `cat_id` int(11) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS shop;

CREATE TABLE `shop` (
  `id` int(11) NOT NULL,
  `owner_id` int(11) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `phone` bigint(10) DEFAULT NULL,
  `mobile` bigint(10) DEFAULT NULL,
  `lat` float(10,6) DEFAULT 0,
  `lon` float(10,6) DEFAULT 0,
  `rating` varchar(3) DEFAULT 0, 
  `description` varchar(200) DEFAULT NULL, 
  `working_days` varchar(60) DEFAULT NULL,
  `max_seat` int(4) DEFAULT 0,
  `start_time` int(6) DEFAULT 0,
  `end_time` int(6) DEFAULT 0,
  `break_time` int(6) DEFAULT 0,
  `break_duration` int(6) DEFAULT 0,
  `street_name` varchar(30) DEFAULT NULL,
  `locality` varchar(30) DEFAULT NULL,
  `area` varchar(30) DEFAULT NULL,
  `state` varchar(30) DEFAULT NULL,
  `city` varchar(10) DEFAULT NULL,
  `pin_code` int(10) DEFAULT NULL,
  `address` varchar(500) DEFAULT NULL,
  `active` tinyint(1) DEFAULT '0',
  `approved` tinyint(1) DEFAULT '0',
  `files` varchar(2000) DEFAULT NULL,
  `created_time` datetime DEFAULT NULL,
  `created_by` varchar(30) DEFAULT NULL,
  `modified_by` varchar(30) DEFAULT NULL,
  `modified_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS shop_service;

CREATE TABLE `shop_services` (
  `id` int(11) NOT NULL,
  `shop_owner_id` int(11) DEFAULT NULL,
  `shop_id` int(11) DEFAULT NULL,
  `cat_id` int(11) DEFAULT NULL,
  `sub_cat_id` int(11) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `serving_person_name` varchar(30) DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL,
  `act_price` double DEFAULT 0,
  `dis_flat` double DEFAULT 0,
  `dis_percent` int(3) DEFAULT 0,
  `avg_time` int(6) DEFAULT 0,
  `working_days` varchar(60) DEFAULT NULL,
  `max_seat` int(4) DEFAULT 0,
  `start_time` int(6) DEFAULT 0,
  `end_time` int(6) DEFAULT 0,
  `break_time` int(6) DEFAULT 0,
  `break_duration` int(6) DEFAULT 0,
  `wknd_start_time` int(6) DEFAULT 0,
  `wknd_end_time` int(6) DEFAULT 0,
  `wknd_act_price` double DEFAULT NULL,
  `pin_code` int(10) DEFAULT NULL,
  `active` tinyint(1) DEFAULT '1',
  `approved` tinyint(1) DEFAULT '0',
  `rating` varchar(3) DEFAULT 0, 
  `files` varchar(2000) DEFAULT NULL,
  `created_time` datetime DEFAULT NULL,
  `created_by` varchar(30) DEFAULT NULL,
  `modified_by` varchar(30) DEFAULT NULL,
  `modified_time` datetime DEFAULT NULL,
  `lat` float(10,6) DEFAULT 0,
  `lon` float(10,6) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS booking;

CREATE TABLE `booking` (
  `id` int(11) NOT NULL,
  `booking_id`    VARCHAR(30),
  `user_id` int(11) DEFAULT NULL,
  `shop_id` int(11) DEFAULT NULL,
  `cat_id` int(11) DEFAULT NULL,
  `sub_cat_id` int(11) DEFAULT NULL,
  `shop_service_id` int(11) DEFAULT NULL,
  `address_id` int(11) DEFAULT NULL,
  `slot` int(6) DEFAULT 0,
  `duration` int(6) DEFAULT 0,
  `service_date` date NOT NULL, -- date of service, date without time
  `payment_mode` varchar(10) DEFAULT NULL,
  `payment_id` varchar(30) DEFAULT NULL,
  `act_price` double DEFAULT 0,
  `paid_amount` double DEFAULT NULL,
  `dis_flat` double DEFAULT 0,
  `dis_percent` int(3) DEFAULT 0,
  `discount` double DEFAULT NULL,
  `promo_id` int(11) DEFAULT NULL,
  `promo_code` varchar(10) DEFAULT NULL,
  `status` tinyint(2),
  `lat` float(10,6) DEFAULT 0,
  `lon` float(10,6) DEFAULT 0,
  `description` varchar(200) DEFAULT NULL,
  `created_time` datetime DEFAULT NULL,
  `created_by` varchar(30) DEFAULT NULL,
  `modified_by` varchar(30) DEFAULT NULL,
  `modified_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `user_address` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `address`   varchar(100),
  `type`      varchar (15),
  `is-default`  tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`)
)ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS media;

CREATE TABLE `media` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `shop_id` int(11) DEFAULT NULL,
  `shop_service_id` int(11) DEFAULT NULL,
  `operation` varchar(200) DEFAULT NULL,
  `orgnl_name` varchar(200) DEFAULT NULL,
  `generated_name` varchar(200) DEFAULT NULL,
  `content_type` varchar(200) DEFAULT NULL,
  `active` tinyint(1) DEFAULT '1',
  `created_time` datetime DEFAULT NULL,
  `created_by` varchar(30) DEFAULT NULL,
  `modified_by` varchar(30) DEFAULT NULL,
  `modified_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS service_slot_booking;

CREATE TABLE service_slot_booking (
  `id` int(11) NOT NULL,
  `booking_id`    VARCHAR(30),
  `user_id`   INT NOT NULL,
  `shop_id`   INT NOT NULL,
  `shop_service_id`   INT NOT NULL,
  `service_date`      DATE NOT NULL, -- date of service, date without time
  `slot`    INT NOT NULL,
  `duration`      INT NOT NULL,
  `status`        tinyint(2),
  `created_by` varchar(30) DEFAULT NULL,
  `created_time` datetime DEFAULT NULL,
  `modified_by` varchar(30) DEFAULT NULL,
  `modified_time` datetime DEFAULT NULL,
   PRIMARY KEY (id)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS device_info;

CREATE TABLE `device_info` (
`id` int(11) NOT NULL,
`user_id` int(11),
`device_id`    varchar(40),
`device_token` varchar(50),
PRIMARY KEY (`id`))
ENGINE=InnoDB DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS feedback;

CREATE TABLE `feedback` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `shop_id` int(11) DEFAULT NULL,
  `shop_service_id` int(11) DEFAULT NULL,
  `booking_id` int(11) DEFAULT NULL,
  `operation` varchar(200) DEFAULT NULL,
  `lat` float(10,6) DEFAULT 0,
  `lon` float(10,6) DEFAULT 0,
  `rating` int(1) DEFAULT 0,
  `review` varchar(200) DEFAULT NULL,
  `device` varchar(50) DEFAULT NULL,
  `device_model` varchar(50) DEFAULT NULL,
  `created_time` datetime DEFAULT NULL,
  `created_by` varchar(30) DEFAULT NULL,
  `modified_by` varchar(30) DEFAULT NULL,
  `modified_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `lib_sequences`(
     `name`  varchar(50),
     `next_val` bigint
 )ENGINE=InnoDB DEFAULT CHARSET=utf8;

 -- 06-07-2018
alter table users drop column mobile;
alter table users drop column active;
alter table users drop column language;
alter table users drop column email;

alter table users add column language varchar(20);
alter table users add column device_token varchar(200);
alter table users add column last_login_time datetime;
alter table users add column  fb_id varchar(200);
alter table users add column  twitter_id varchar(200);
alter table users add column  google_id varchar(200);
alter table users add column  device varchar(20);
alter table users add column  status varchar(20);
alter table users add column  mobile varchar(12);
alter table users add column  email varchar(50);

create table payment (
	id varchar(50) primary key,
	order_id  varchar(50) not null,
	invoice_id varchar(50),
	refund_id varchar(50),
	booking_id varchar(50),
	user_id int,
	entity varchar(20) not null,
	amount int not null,
	currency varchar(20) default 'INR',
	status varchar(20),
	international tinyint(2) default 0,
	payment_type varchar(20),
	method varchar(20) not null,
	amt_refunded int,
	refund_status varchar(20),
	captured tinyint(2) default 0,
	description varchar(200),
	card_id varchar(25),
	bank varchar(50),
	wallet varchar(50),
	vpa varchar(50),
	email varchar(50),
	contact varchar(20),
	notes varchar(200),
	fee int,
	tax int,
	error_code varchar(50),
	error_description varchar(200),
	created_at datetime default null
);

create table order_refund (
	id varchar(50) primary key,
	payment_id varchar(50) not null,
	booking_id varchar(50),
	user_id int,
	offer_id varchar(50),
	entity varchar(20) not null,
	amount int not null,
	amount_paid int,
	amount_due int,
	currency varchar(20) default 'INR',
	receipt varchar(20),
	status varchar(20),
	attempts int,
	notes varchar(200),
	error_description varchar(200),
	created_at datetime default null
);