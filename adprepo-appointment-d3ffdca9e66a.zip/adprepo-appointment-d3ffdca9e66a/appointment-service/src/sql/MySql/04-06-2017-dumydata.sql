insert into users (name, email, password, mobile, user_type, roles) values ('nakesh', 'n@gmail.com', '123456', '123456789', 'USER', 'ROLE_SUPER_ADMIN');

INSERT INTO category (name) values ('Hair cut');
INSERT INTO category (name) values ('Massage');
INSERT INTO category (name) values ('Beared cut');
INSERT INTO category (name) values ('Trimming');

INSERT INTO sub_category (name, cat_id) values ('Boys hair cut', 1);
INSERT INTO sub_category (name, cat_id) values ('Girl hair cut', 1);
INSERT INTO sub_category (name, cat_id) values ('face massage', 2);
INSERT INTO sub_category (name, cat_id) values ('body massage', 2);
INSERT INTO sub_category (name, cat_id) values ('back massage', 2);
INSERT INTO sub_category (name, cat_id) values ('neck massage', 2);


INSERT INTO shop (name, mobile, lat, lon, address, working_days, max_seat, start_time, end_time, break_time, break_duration, rating, created_time)
	VALUES ("shop_1", 1234567890, 22.1234, 55.12345, 'shop_1 address', 'MON,TUE,WED,THU,FRI,SAT', 3, 540, 1020, 840, 60, 4, '2017-03-05 10:07:15');
INSERT INTO shop (name, mobile, lat, lon, address, working_days, max_seat, start_time, end_time, break_time, break_duration, rating, created_time)
	VALUES ("shop_2", 1234567890, 22.1234, 55.12345, 'shop_2 address', 'MON,TUE,WED,THU,FRI,SAT', 3, 540, 1020, 840, 60, 4, '2017-03-05 10:07:15');
INSERT INTO shop (name, mobile, lat, lon, address, working_days, max_seat, start_time, end_time, break_time, break_duration, rating, created_time)
	VALUES ("shop_3", 1234567890, 22.1234, 55.12345, 'shop_3 address', 'MON,TUE,WED,THU,FRI,SAT', 3, 540, 1020, 840, 60, 4, '2017-03-05 10:07:15');
INSERT INTO shop (name, mobile, lat, lon, address, working_days, max_seat, start_time, end_time, break_time, break_duration, rating, created_time)
	VALUES ("shop_4", 1234567890, 22.1234, 55.12345, 'shop_4 address', 'MON,TUE,WED,THU,FRI,SAT', 3, 540, 1020, 840, 60, 4, '2017-03-05 10:07:15');

	
INSERT INTO shop_services (shop_owner_id, shop_id, cat_id, sub_cat_id, name,serving_person_name, description, lat, lon, act_price, dis_flat, working_days, avg_time, max_seat, start_time, end_time, break_time, break_duration, rating, created_time)
	VALUES (1, 1, 1, 1, "Boys hair cut", 'irfaan', 'nice des', -33.737885,151.235260, 100, 10, 'MON,TUE,WED,THU,FRI,SAT', 30, 3,  540, 1020, 840, 60, 4, '2017-03-05 10:07:15');
INSERT INTO shop_services (shop_owner_id, shop_id, cat_id, sub_cat_id, name,serving_person_name, description, lat, lon, act_price, dis_flat, working_days, avg_time, max_seat, start_time, end_time, break_time, break_duration, rating, created_time)
	VALUES (1, 1, 1, 2, "Girl hair cut", 'irfaan', 'nice des', 22.1234, 55.12345, 100, 10, 'MON,TUE,WED,THU,FRI,SAT', 30, 3,  540, 1020, 840, 60, 4, '2017-03-05 10:07:15');
INSERT INTO shop_services (shop_owner_id, shop_id, cat_id, sub_cat_id, name,serving_person_name, description, lat, lon, act_price, dis_flat, working_days, avg_time, max_seat, start_time, end_time, break_time, break_duration, rating, created_time)
	VALUES (1, 1, 2, 3, "face massage", 'irfaan', 'nice des', 22.1234, 55.12345, 100, 10, 'MON,TUE,WED,THU,FRI,SAT', 30, 3,  540, 1020, 840, 60, 4, '2017-03-05 10:07:15');
INSERT INTO shop_services (shop_owner_id, shop_id, cat_id, sub_cat_id, name,serving_person_name, description, lat, lon, act_price, dis_flat, working_days, avg_time, max_seat, start_time, end_time, break_time, break_duration, rating, created_time)
	VALUES (2, 1, 2, 4, "body massage", 'irfaan', 'nice des', 22.1234, 55.12345, 100, 10, 'MON,TUE,WED,THU,FRI,SAT', 30, 3,  540, 1020, 840, 60, 4, '2017-03-05 10:07:15');
INSERT INTO shop_services (shop_owner_id, shop_id, cat_id, sub_cat_id, name,serving_person_name, description, lat, lon, act_price, dis_flat, working_days, avg_time, max_seat, start_time, end_time, break_time, break_duration, rating, created_time)
	VALUES (2, 2, 1, 1, "Boys hair cut", 'irfaan', 'nice des', 22.1234, 55.12345, 100, 10, 'MON,TUE,WED,THU,FRI,SAT', 30, 3,  540, 1020, 840, 60, 4, '2017-03-05 10:07:15');
INSERT INTO shop_services (shop_owner_id, shop_id, cat_id, sub_cat_id, name,serving_person_name, description, lat, lon, act_price, dis_flat, working_days, avg_time, max_seat, start_time, end_time, break_time, break_duration, rating, created_time)
	VALUES (3, 3, 1, 1, "Boys hair cut", 'irfaan', 'nice des', 22.1234, 55.12345, 100, 10, 'MON,TUE,WED,THU,FRI,SAT', 30, 3,  540, 1020, 840, 60, 4, '2017-03-05 10:07:15');
INSERT INTO shop_services (shop_owner_id, shop_id, cat_id, sub_cat_id, name,serving_person_name, description, lat, lon, act_price, dis_flat, working_days, avg_time, max_seat, start_time, end_time, break_time, break_duration, rating, created_time)
	VALUES (1, 1, 1, 1, "Boys hair cut", 'irfaan', 'nice des', -33.737885,151.235260, 100, 10, 'MON,TUE,WED,THU,FRI,SAT', 30, 3,  540, 1020, 840, 60, 4, '2017-03-05 10:07:15');
INSERT INTO shop_services (shop_owner_id, shop_id, cat_id, sub_cat_id, name,serving_person_name, description, lat, lon, act_price, dis_flat, working_days, avg_time, max_seat, start_time, end_time, break_time, break_duration, rating, created_time)
	VALUES (1, 1, 1, 1, "Boys hair cut", 'irfaan', 'nice des', -33.737885,151.235260, 100, 10, 'MON,TUE,WED,THU,FRI,SAT', 30, 3,  540, 1020, 840, 60, 4, '2017-03-05 10:07:15');
INSERT INTO shop_services (shop_owner_id, shop_id, cat_id, sub_cat_id, name,serving_person_name, description, lat, lon, act_price, dis_flat, working_days, avg_time, max_seat, start_time, end_time, break_time, break_duration, rating, created_time)
	VALUES (1, 1, 1, 1, "Boys hair cut", 'irfaan', 'nice des', -33.737885,151.235260, 100, 10, 'MON,TUE,WED,THU,FRI,SAT', 30, 3,  540, 1020, 840, 60, 4, '2017-03-05 10:07:15');
INSERT INTO shop_services (shop_owner_id, shop_id, cat_id, sub_cat_id, name,serving_person_name, description, lat, lon, act_price, dis_flat, working_days, avg_time, max_seat, start_time, end_time, break_time, break_duration, rating, created_time)
	VALUES (1, 1, 1, 1, "Boys hair cut", 'irfaan', 'nice des', -33.737885,151.235260, 100, 10, 'MON,TUE,WED,THU,FRI,SAT', 30, 3,  540, 1020, 840, 60, 4, '2017-03-05 10:07:15');
INSERT INTO shop_services (shop_owner_id, shop_id, cat_id, sub_cat_id, name,serving_person_name, description, lat, lon, act_price, dis_flat, working_days, avg_time, max_seat, start_time, end_time, break_time, break_duration, rating, created_time)
	VALUES (1, 1, 1, 1, "Boys hair cut", 'irfaan', 'nice des', -33.737885,151.235260, 100, 10, 'MON,TUE,WED,THU,FRI,SAT', 30, 3,  540, 1020, 840, 60, 4, '2017-03-05 10:07:15');
INSERT INTO shop_services (shop_owner_id, shop_id, cat_id, sub_cat_id, name,serving_person_name, description, lat, lon, act_price, dis_flat, working_days, avg_time, max_seat, start_time, end_time, break_time, break_duration, rating, created_time)
	VALUES (1, 1, 1, 1, "Boys hair cut", 'irfaan', 'nice des', -33.737885,151.235260, 100, 10, 'MON,TUE,WED,THU,FRI,SAT', 30, 3,  540, 1020, 840, 60, 4, '2017-03-05 10:07:15');

	
	
INSERT INTO booking (booking_id, user_id, shop_id, cat_id, sub_cat_id, shop_service_id, slot, duration, payment_mode, payment_id, paid_amount, discount, lat, lon, created_time, service_date)
	VALUES ('20170918_345', 1, 1, 1, 1, 1, 600, 60, 'ONLINE', 'PAY_ID', 100, 10, 22.1234, 55.12345, '2017-03-05 10:07:15', '2017-03-05');
INSERT INTO booking (user_id, shop_id, cat_id, sub_cat_id, shop_service_id, slot, duration, payment_mode, payment_id, paid_amount, discount, lat, lon, created_time, service_date)
	VALUES ('20170918_565',2, 1, 1, 1, 1, 600, 60, 'ONLINE', 'PAY_ID', 100, 10, 22.1234, 55.12345, '2017-03-05 10:07:15', '2017-03-06');
INSERT INTO booking (user_id, shop_id, cat_id, sub_cat_id, shop_service_id, slot, duration, payment_mode, payment_id, paid_amount, discount, lat, lon, created_time, service_date)
	VALUES ('20170918_345',1, 1, 1, 1, 1, 600, 60, 'ONLINE', 'PAY_ID', 100, 10, 22.1234, 55.12345, '2017-03-05 10:07:15', '2017-03-07');
INSERT INTO booking (user_id, shop_id, cat_id, sub_cat_id, shop_service_id, slot, duration, payment_mode, payment_id, paid_amount, discount, lat, lon, created_time, service_date)
	VALUES ('20170918_345',1, 2, 1, 1, 1, 600, 60, 'ONLINE', 'PAY_ID', 100, 10, 22.1234, 55.12345, '2017-03-05 10:07:15', '2017-03-08');


INSERT INTO booking (user_id, shop_id, cat_id, sub_cat_id, shop_service_id, slot, duration, payment_mode, payment_id, paid_amount, discount, lat, lon, created_time, service_date)
	VALUES (1, 1, 1, 1, 1, 660, 30, 'ONLINE', 'PAY_ID', 100, 10, 22.1234, 55.12345, '2017-08-27 01:00:40', '2017-08-27');
	

insert into feedback (id, user_id, shop_id, shop_service_id, rating, review, operation) values(1, 1, 1, 1, 1, 'hello', 'U_SS_FEEDBACK');
insert into feedback (id, user_id, shop_id, shop_service_id, rating, review, operation) values(2, 1, 1, 1, 2, 'hello', 'U_SS_FEEDBACK');
insert into feedback (id, user_id, shop_id, shop_service_id, rating, review, operation) values(3, 1, 1, 6, 3, 'hello', 'U_SS_FEEDBACK');
insert into feedback (id, user_id, shop_id, shop_service_id, rating, review, operation) values(4, 1, 1, 8, 4, 'hello', 'U_SS_FEEDBACK');
insert into feedback (id, user_id, shop_id, shop_service_id, rating, review, operation) values(5, 1, 2, 2, 5, 'hello', 'U_SS_FEEDBACK');
insert into feedback (id, user_id, shop_id, shop_service_id, rating, review, operation) values(6, 1, 2, 3, 1, 'hello', 'U_SS_FEEDBACK');
	
/*
select * from category;
select * from sub_category;
select id, owner_id, name, mobile, lat, lon, rating, working_days, max_seat, start_time, end_time, break_time, break_duration, created_time from shop;
select id, shop_id, cat_id, sub_cat_id, name, lat, lon, act_price, dis_flat,  avg_time, max_sheat, start_time, end_time, break_time, break_duration, rating, created_time from shop_service;
select id, user_id, shop_id, cat_id, sub_cat_id, shop_service_id, slot, duration, payment_mode, payment_id, paid_amount, discount, lat, lon, created_time from booking;
*/

insert into lib_sequences values ('users_seq', 1);
insert into lib_sequences values ('admin_seq', 1);
insert into lib_sequences values ('category_seq', 1);
insert into lib_sequences values ('sub_category_seq', 1);
insert into lib_sequences values ('shop_seq', 1);
insert into lib_sequences values ('shop_services_seq', 1);
insert into lib_sequences values ('booking_seq', 1);
insert into lib_sequences values ('user_address_seq', 1);
insert into lib_sequences values ('media_seq', 1);
insert into lib_sequences values ('device_info_seq', 1);
insert into lib_sequences values ('feedback_seq', 1);
insert into lib_sequences values ('service_slot_booking_seq', 1);

-- 03-08-2018
create table blocked_slot (`id` int(11) NOT NULL auto_increment, shop_id int(11), shop_service_id int(11), date datetime, reason varchar(500), `created_time` datetime DEFAULT NULL, `created_by` varchar(30) DEFAULT NULL, `modified_by` varchar(30) DEFAULT NULL, `modified_time` datetime DEFAULT NULL,PRIMARY KEY (`id`)) ENGINE=InnoDB DEFAULT CHARSET=utf8;
