insert into users (name, email, password, mobile, user_type, roles) values ('nakesh', 'n@gmail.com', '123456', '123456789', 'USER', 'ROLE_SUPER_ADMIN');

INSERT INTO category (name) values ('Hair cut');
INSERT INTO category (name) values ('Massage');
INSERT INTO category (name) values ('Beared cut');
INSERT INTO category (name) values ('Trimming');

INSERT INTO sub_category (name, cat_id) values ('Boys hair cut', 1);
INSERT INTO sub_category (name, cat_id) values ('Girl hair cut', 1);
INSERT INTO sub_category (name, cat_id) values ('face massage', 2);
INSERT INTO sub_category (name, cat_id) values ('body massage', 2);
INSERT INTO sub_category (name, cat_id) values ('back massage', 2);
INSERT INTO sub_category (name, cat_id) values ('neck massage', 2);


INSERT INTO shop (name, mobile, lat, lon, address, working_days, max_seat, start_time, end_time, break_time, break_duration, rating, created_time)
	VALUES ('shop_1', 1234567890, 22.1234, 55.12345, 'shop_1 address', 'MON,TUE,WED,THU,FRI,SAT', 3, 540, 1020, 840, 60, 4, '2017-03-05 10:07:15');
INSERT INTO shop (name, mobile, lat, lon, address, working_days, max_seat, start_time, end_time, break_time, break_duration, rating, created_time)
	VALUES ('shop_2', 1234567890, 22.1234, 55.12345, 'shop_2 address', 'MON,TUE,WED,THU,FRI,SAT', 3, 540, 1020, 840, 60, 4, '2017-03-05 10:07:15');
INSERT INTO shop (name, mobile, lat, lon, address, working_days, max_seat, start_time, end_time, break_time, break_duration, rating, created_time)
	VALUES ('shop_3', 1234567890, 22.1234, 55.12345, 'shop_3 address', 'MON,TUE,WED,THU,FRI,SAT', 3, 540, 1020, 840, 60, 4, '2017-03-05 10:07:15');
INSERT INTO shop (name, mobile, lat, lon, address, working_days, max_seat, start_time, end_time, break_time, break_duration, rating, created_time)
	VALUES ('shop_4', 1234567890, 22.1234, 55.12345, 'shop_4 address', 'MON,TUE,WED,THU,FRI,SAT', 3, 540, 1020, 840, 60, 4, '2017-03-05 10:07:15');


INSERT INTO shop_services (shop_owner_id, shop_id, cat_id, sub_cat_id, name,serving_person_name, description, lat, lon, act_price, dis_flat, working_days, avg_time, max_seat, start_time, end_time, break_time, break_duration, rating, created_time)
	VALUES (1, 1, 1, 1, 'Boys hair cut', 'irfaan', 'nice des', 22.1234, 55.12345, 100, 10, 'MON,TUE,WED,THU,FRI,SAT', 30, 3,  540, 1020, 840, 60, 4, '2017-03-05 10:07:15');
INSERT INTO shop_services (shop_owner_id, shop_id, cat_id, sub_cat_id, name,serving_person_name, description, lat, lon, act_price, dis_flat, working_days, avg_time, max_seat, start_time, end_time, break_time, break_duration, rating, created_time)
	VALUES (1, 1, 1, 2, 'Girl hair cut', 'irfaan', 'nice des', 22.1234, 55.12345, 100, 10, 'MON,TUE,WED,THU,FRI,SAT', 30, 3,  540, 1020, 840, 60, 4, '2017-03-05 10:07:15');
INSERT INTO shop_services (shop_owner_id, shop_id, cat_id, sub_cat_id, name,serving_person_name, description, lat, lon, act_price, dis_flat, working_days, avg_time, max_seat, start_time, end_time, break_time, break_duration, rating, created_time)
	VALUES (1, 1, 2, 3, 'face massage', 'irfaan', 'nice des', 22.1234, 55.12345, 100, 10, 'MON,TUE,WED,THU,FRI,SAT', 30, 3,  540, 1020, 840, 60, 4, '2017-03-05 10:07:15');
INSERT INTO shop_services (shop_owner_id, shop_id, cat_id, sub_cat_id, name,serving_person_name, description, lat, lon, act_price, dis_flat, working_days, avg_time, max_seat, start_time, end_time, break_time, break_duration, rating, created_time)
	VALUES (2, 1, 2, 4, 'body massage', 'irfaan', 'nice des', 22.1234, 55.12345, 100, 10, 'MON,TUE,WED,THU,FRI,SAT', 30, 3,  540, 1020, 840, 60, 4, '2017-03-05 10:07:15');
INSERT INTO shop_services (shop_owner_id, shop_id, cat_id, sub_cat_id, name,serving_person_name, description, lat, lon, act_price, dis_flat, working_days, avg_time, max_seat, start_time, end_time, break_time, break_duration, rating, created_time)
	VALUES (2, 2, 1, 1, 'Boys hair cut', 'irfaan', 'nice des', 22.1234, 55.12345, 100, 10, 'MON,TUE,WED,THU,FRI,SAT', 30, 3,  540, 1020, 840, 60, 4, '2017-03-05 10:07:15');
INSERT INTO shop_services (shop_owner_id, shop_id, cat_id, sub_cat_id, name,serving_person_name, description, lat, lon, act_price, dis_flat, working_days, avg_time, max_seat, start_time, end_time, break_time, break_duration, rating, created_time)
	VALUES (3, 3, 1, 1, 'Boys hair cut', 'irfaan', 'nice des', 22.1234, 55.12345, 100, 10, 'MON,TUE,WED,THU,FRI,SAT', 30, 3,  540, 1020, 840, 60, 4, '2017-03-05 10:07:15');


INSERT INTO booking (booking_id, user_id, shop_id, cat_id, sub_cat_id, shop_service_id, slot, duration, payment_mode, payment_id, paid_amount, discount, lat, lon, created_time, service_date)
	VALUES ('20170908_342', 1, 1, 1, 1, 1, 600, 60, 'ONLINE', 'PAY_ID', 100, 10, 22.1234, 55.12345, '2017-03-05 10:07:15', '2017-03-05');
INSERT INTO booking (user_id, shop_id, cat_id, sub_cat_id, shop_service_id, slot, duration, payment_mode, payment_id, paid_amount, discount, lat, lon, created_time, service_date)
	VALUES (('20170908_534',2, 1, 1, 1, 1, 600, 60, 'ONLINE', 'PAY_ID', 100, 10, 22.1234, 55.12345, '2017-03-05 10:07:15', '2017-03-06');
INSERT INTO booking (user_id, shop_id, cat_id, sub_cat_id, shop_service_id, slot, duration, payment_mode, payment_id, paid_amount, discount, lat, lon, created_time, service_date)
	VALUES (('20170908_342',1, 1, 1, 1, 1, 600, 60, 'ONLINE', 'PAY_ID', 100, 10, 22.1234, 55.12345, '2017-03-05 10:07:15', '2017-03-07');
INSERT INTO booking (user_id, shop_id, cat_id, sub_cat_id, shop_service_id, slot, duration, payment_mode, payment_id, paid_amount, discount, lat, lon, created_time, service_date)
	VALUES (('20170908_342',1, 2, 1, 1, 1, 600, 60, 'ONLINE', 'PAY_ID', 100, 10, 22.1234, 55.12345, '2017-03-05 10:07:15', '2017-03-08');



/*
select * from category;
select * from sub_category;
select id, owner_id, name, mobile, lat, lon, rating, working_days, max_sheat, start_time, end_time, break_time, break_duration, created_time from shop;
select id, shop_id, cat_id, sub_cat_id, name, lat, lon, act_price, dis_flat,  avg_time, max_seat, start_time, end_time, break_time, break_duration, rating, created_time from shop_service;
select id, user_id, shop_id, cat_id, sub_cat_id, shop_service_id, slot, duration, payment_mode, payment_id, paid_amount, discount, lat, lon, created_time from booking;
*/

INSERT INTO lib_sequences VALUES ('users_seq', 1);
INSERT INTO lib_sequences VALUES ('admin_seq', 1);
INSERT INTO lib_sequences VALUES ('category_seq', 1);
INSERT INTO lib_sequences VALUES ('sub_category_seq', 1);
INSERT INTO lib_sequences VALUES ('shop_seq', 1);
INSERT INTO lib_sequences VALUES ('shop_services_seq', 1);
INSERT INTO lib_sequences VALUES ('booking_seq', 1);
INSERT INTO lib_sequences VALUES ('user_address_seq', 1);
INSERT INTO lib_sequences VALUES ('media_seq', 1);
INSERT INTO lib_sequences VALUES ('device_info_seq', 1);
INSERT INTO lib_sequences VALUES ('feedback_seq', 1);
INSERT INTO lib_sequences VALUES ('service_slot_booking_seq', 1);



