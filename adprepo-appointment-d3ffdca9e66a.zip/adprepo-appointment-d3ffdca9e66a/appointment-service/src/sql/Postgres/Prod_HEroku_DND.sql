--
-- PostgreSQL database dump
--

-- Dumped from database version 9.6.2
-- Dumped by pg_dump version 9.6.3

-- Started on 2017-08-19 00:33:06

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE d15im0e6vrnd42;
--
-- TOC entry 3080 (class 1262 OID 11345556)
-- Name: d15im0e6vrnd42; Type: DATABASE; Schema: -; Owner: jlzbtdskdtgfse
--

CREATE DATABASE d15im0e6vrnd42 WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'en_US.UTF-8' LC_CTYPE = 'en_US.UTF-8';


ALTER DATABASE d15im0e6vrnd42 OWNER TO jlzbtdskdtgfse;

\connect d15im0e6vrnd42

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 1 (class 3079 OID 13277)
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- TOC entry 3083 (class 0 OID 0)
-- Dependencies: 1
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- TOC entry 189 (class 1259 OID 17545977)
-- Name: admin; Type: TABLE; Schema: public; Owner: jlzbtdskdtgfse
--

CREATE TABLE admin (
    id bigint NOT NULL,
    created_by character varying(255),
    created_time timestamp without time zone,
    modified_by character varying(255),
    modified_time timestamp without time zone,
    active boolean NOT NULL,
    approved boolean NOT NULL,
    email character varying(255),
    lat real,
    lon real,
    mobile character varying(255),
    name character varying(255),
    otp character varying(255),
    password character varying(255),
    pro_image character varying(255),
    roles character varying(255),
    sex character varying(255),
    user_type character varying(255)
);


ALTER TABLE admin OWNER TO jlzbtdskdtgfse;

--
-- TOC entry 190 (class 1259 OID 17545985)
-- Name: booking; Type: TABLE; Schema: public; Owner: jlzbtdskdtgfse
--

CREATE TABLE booking (
    id bigint NOT NULL,
    created_by character varying(255),
    created_time timestamp without time zone,
    modified_by character varying(255),
    modified_time timestamp without time zone,
    act_price double precision,
    address_id bigint,
    cat_id bigint,
    description character varying(255),
    dis_flat double precision,
    dis_percent integer,
    duration integer NOT NULL,
    lat real,
    lon real,
    paid_amount double precision,
    payment_id character varying(255),
    payment_mode character varying(255),
    promo_code character varying(255),
    promo_id bigint,
    shop_id bigint,
    shop_service_id bigint,
    slot integer NOT NULL,
    status integer,
    sub_cat_id bigint,
    user_id bigint
);


ALTER TABLE booking OWNER TO jlzbtdskdtgfse;

--
-- TOC entry 191 (class 1259 OID 17545993)
-- Name: category; Type: TABLE; Schema: public; Owner: jlzbtdskdtgfse
--

CREATE TABLE category (
    id bigint NOT NULL,
    name character varying(255)
);


ALTER TABLE category OWNER TO jlzbtdskdtgfse;

--
-- TOC entry 188 (class 1259 OID 17545975)
-- Name: hibernate_sequence; Type: SEQUENCE; Schema: public; Owner: jlzbtdskdtgfse
--

CREATE SEQUENCE hibernate_sequence
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE hibernate_sequence OWNER TO jlzbtdskdtgfse;

--
-- TOC entry 187 (class 1259 OID 11348825)
-- Name: service_booking_details; Type: TABLE; Schema: public; Owner: jlzbtdskdtgfse
--

CREATE TABLE service_booking_details (
    request_id character varying(30) NOT NULL,
    user_id integer NOT NULL,
    shop_service_id integer NOT NULL,
    from_time_slot integer NOT NULL,
    to_time_slot integer NOT NULL,
    device_id character varying(50) NOT NULL,
    status character varying(10) DEFAULT 'PENDING'::character varying NOT NULL,
    created_time timestamp without time zone,
    modified_time timestamp without time zone
);


ALTER TABLE service_booking_details OWNER TO jlzbtdskdtgfse;

--
-- TOC entry 192 (class 1259 OID 17545998)
-- Name: shop; Type: TABLE; Schema: public; Owner: jlzbtdskdtgfse
--

CREATE TABLE shop (
    id bigint NOT NULL,
    created_by character varying(255),
    created_time timestamp without time zone,
    modified_by character varying(255),
    modified_time timestamp without time zone,
    active boolean NOT NULL,
    address character varying(255),
    approved boolean NOT NULL,
    area character varying(255),
    break_duration integer,
    break_time integer,
    city character varying(255),
    description character varying(255),
    end_time integer,
    lat real,
    locality character varying(255),
    lon real,
    max_seat integer,
    mobile bigint,
    name character varying(255),
    owner_id bigint,
    phone bigint,
    pin_code integer,
    rating real,
    start_time integer,
    state character varying(255),
    street_name character varying(255),
    working_days character varying(255)
);


ALTER TABLE shop OWNER TO jlzbtdskdtgfse;

--
-- TOC entry 193 (class 1259 OID 17546006)
-- Name: shop_service; Type: TABLE; Schema: public; Owner: jlzbtdskdtgfse
--

CREATE TABLE shop_service (
    id bigint NOT NULL,
    created_by character varying(255),
    created_time timestamp without time zone,
    modified_by character varying(255),
    modified_time timestamp without time zone,
    act_price double precision,
    active boolean NOT NULL,
    approved boolean NOT NULL,
    avg_time integer,
    break_duration integer,
    break_time integer,
    cat_id bigint,
    description character varying(255),
    dis_flat double precision,
    dis_percent integer,
    end_time integer,
    lat real,
    lon real,
    max_seat integer,
    name character varying(255),
    rating real,
    serving_person_name character varying(255),
    shop_id bigint,
    shop_owner_id bigint,
    start_time integer,
    sub_cat_id bigint,
    wknd_act_price double precision,
    wknd_end_time integer,
    wknd_start_time integer,
    working_days character varying(255)
);


ALTER TABLE shop_service OWNER TO jlzbtdskdtgfse;

--
-- TOC entry 194 (class 1259 OID 17546014)
-- Name: sub_category; Type: TABLE; Schema: public; Owner: jlzbtdskdtgfse
--

CREATE TABLE sub_category (
    id bigint NOT NULL,
    cat_id bigint,
    name character varying(255)
);


ALTER TABLE sub_category OWNER TO jlzbtdskdtgfse;

--
-- TOC entry 186 (class 1259 OID 11348819)
-- Name: user_address; Type: TABLE; Schema: public; Owner: jlzbtdskdtgfse
--

CREATE TABLE user_address (
    id bigint NOT NULL,
    user_id integer NOT NULL,
    address character varying(100),
    type character varying(15),
    is_default boolean
);


ALTER TABLE user_address OWNER TO jlzbtdskdtgfse;

--
-- TOC entry 185 (class 1259 OID 11348817)
-- Name: user_address_id_seq; Type: SEQUENCE; Schema: public; Owner: jlzbtdskdtgfse
--

CREATE SEQUENCE user_address_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE user_address_id_seq OWNER TO jlzbtdskdtgfse;

--
-- TOC entry 3085 (class 0 OID 0)
-- Dependencies: 185
-- Name: user_address_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: jlzbtdskdtgfse
--

ALTER SEQUENCE user_address_id_seq OWNED BY user_address.id;


--
-- TOC entry 195 (class 1259 OID 17546019)
-- Name: users; Type: TABLE; Schema: public; Owner: jlzbtdskdtgfse
--

CREATE TABLE users (
    id bigint NOT NULL,
    created_by character varying(255),
    created_time timestamp without time zone,
    modified_by character varying(255),
    modified_time timestamp without time zone,
    active boolean NOT NULL,
    email character varying(255),
    lat real,
    lon real,
    mobile character varying(255),
    name character varying(255),
    otp character varying(255),
    password character varying(255),
    pro_image character varying(255),
    roles character varying(255),
    sex character varying(255),
    user_type character varying(255)
);


ALTER TABLE users OWNER TO jlzbtdskdtgfse;

--
-- TOC entry 2928 (class 2604 OID 11348822)
-- Name: user_address id; Type: DEFAULT; Schema: public; Owner: jlzbtdskdtgfse
--

ALTER TABLE ONLY user_address ALTER COLUMN id SET DEFAULT nextval('user_address_id_seq'::regclass);


--
-- TOC entry 3069 (class 0 OID 17545977)
-- Dependencies: 189
-- Data for Name: admin; Type: TABLE DATA; Schema: public; Owner: jlzbtdskdtgfse
--

INSERT INTO admin (id, created_by, created_time, modified_by, modified_time, active, approved, email, lat, lon, mobile, name, otp, password, pro_image, roles, sex, user_type) VALUES (1, 'DataLoader', '2017-08-18 18:03:35.462', NULL, '2017-08-18 18:03:35.462', true, true, 'superadmin_1@gmail.com', -33.7378845, 151.23526, '1234567891', 'superAdmin_1', NULL, 'password', 'superadmin__proImage_1.jpeg', 'ROLE_SUPER_ADMIN', 'M', 'SUPER');
INSERT INTO admin (id, created_by, created_time, modified_by, modified_time, active, approved, email, lat, lon, mobile, name, otp, password, pro_image, roles, sex, user_type) VALUES (2, 'DataLoader', '2017-08-18 18:03:35.728', NULL, '2017-08-18 18:03:35.728', true, true, 'admin_1@gmail.com', -33.7378845, 151.23526, '1234567891', 'admin_1', NULL, 'password', 'admin_proImage_1.jpeg', 'ROLE_ADMIN_WRITE', 'M', 'ADMIN');
INSERT INTO admin (id, created_by, created_time, modified_by, modified_time, active, approved, email, lat, lon, mobile, name, otp, password, pro_image, roles, sex, user_type) VALUES (3, 'DataLoader', '2017-08-18 18:03:35.748', NULL, '2017-08-18 18:03:35.748', true, true, 'admin_2@gmail.com', -33.7378845, 151.23526, '1234567892', 'admin_2', NULL, 'password', 'admin_proImage_2.jpeg', 'ROLE_ADMIN_WRITE', 'M', 'ADMIN');


--
-- TOC entry 3070 (class 0 OID 17545985)
-- Dependencies: 190
-- Data for Name: booking; Type: TABLE DATA; Schema: public; Owner: jlzbtdskdtgfse
--

INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (15, 'DataLoader', '2017-08-18 18:03:36.63', NULL, '2017-08-18 18:03:36.63', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 30, -33.7378845, 151.23526, 90, '170818180336542AP0028001', 'OFFLINE', 'PROMO_ID', 1, 1, 11, 540, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (16, 'DataLoader', '2017-08-18 18:03:36.671', NULL, '2017-08-18 18:03:36.671', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 30, -33.7378845, 151.23526, 90, '170818180336668AP0028002', 'OFFLINE', 'PROMO_ID', 1, 1, 11, 540, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (17, 'DataLoader', '2017-08-18 18:03:36.691', NULL, '2017-08-18 18:03:36.691', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 30, -33.7378845, 151.23526, 90, '170818180336689AP0028003', 'OFFLINE', 'PROMO_ID', 1, 1, 11, 540, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (18, 'DataLoader', '2017-08-18 18:03:36.725', NULL, '2017-08-18 18:03:36.725', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 30, -33.7378845, 151.23526, 90, '170818180336716AP0028004', 'OFFLINE', 'PROMO_ID', 1, 1, 11, 540, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (19, 'DataLoader', '2017-08-18 18:03:36.759', NULL, '2017-08-18 18:03:36.759', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 30, -33.7378845, 151.23526, 90, '170818180336749AP0028005', 'OFFLINE', 'PROMO_ID', 1, 1, 11, 570, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (20, 'DataLoader', '2017-08-18 18:03:36.806', NULL, '2017-08-18 18:03:36.806', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 30, -33.7378845, 151.23526, 90, '170818180336789AP0028006', 'OFFLINE', 'PROMO_ID', 1, 1, 11, 570, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (21, 'DataLoader', '2017-08-18 18:03:36.844', NULL, '2017-08-18 18:03:36.844', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 30, -33.7378845, 151.23526, 90, '170818180336838AP0028007', 'OFFLINE', 'PROMO_ID', 1, 1, 11, 570, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (22, 'DataLoader', '2017-08-18 18:03:36.861', NULL, '2017-08-18 18:03:36.861', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 30, -33.7378845, 151.23526, 90, '170818180336854AP0028008', 'OFFLINE', 'PROMO_ID', 1, 1, 11, 570, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (23, 'DataLoader', '2017-08-18 18:03:36.933', NULL, '2017-08-18 18:03:36.933', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 30, -33.7378845, 151.23526, 90, '170818180336931AP0028009', 'OFFLINE', 'PROMO_ID', 1, 1, 11, 600, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (24, 'DataLoader', '2017-08-18 18:03:37.05', NULL, '2017-08-18 18:03:37.05', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 30, -33.7378845, 151.23526, 90, '170818180337048AP0028010', 'OFFLINE', 'PROMO_ID', 1, 1, 11, 600, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (25, 'DataLoader', '2017-08-18 18:03:37.094', NULL, '2017-08-18 18:03:37.094', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 30, -33.7378845, 151.23526, 90, '170818180337085AP0028011', 'OFFLINE', 'PROMO_ID', 1, 1, 11, 600, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (26, 'DataLoader', '2017-08-18 18:03:37.119', NULL, '2017-08-18 18:03:37.119', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 30, -33.7378845, 151.23526, 90, '170818180337117AP0028012', 'OFFLINE', 'PROMO_ID', 1, 1, 11, 600, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (27, 'DataLoader', '2017-08-18 18:03:37.165', NULL, '2017-08-18 18:03:37.165', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 30, -33.7378845, 151.23526, 90, '170818180337161AP0028013', 'OFFLINE', 'PROMO_ID', 1, 1, 11, 630, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (28, 'DataLoader', '2017-08-18 18:03:37.205', NULL, '2017-08-18 18:03:37.205', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 30, -33.7378845, 151.23526, 90, '170818180337174AP0028014', 'OFFLINE', 'PROMO_ID', 1, 1, 11, 630, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (29, 'DataLoader', '2017-08-18 18:03:37.218', NULL, '2017-08-18 18:03:37.218', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 30, -33.7378845, 151.23526, 90, '170818180337217AP0028015', 'OFFLINE', 'PROMO_ID', 1, 1, 11, 630, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (30, 'DataLoader', '2017-08-18 18:03:37.3', NULL, '2017-08-18 18:03:37.3', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 30, -33.7378845, 151.23526, 90, '170818180337293AP0028016', 'OFFLINE', 'PROMO_ID', 1, 1, 11, 630, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (31, 'DataLoader', '2017-08-18 18:03:37.339', NULL, '2017-08-18 18:03:37.339', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 30, -33.7378845, 151.23526, 90, '170818180337337AP0028017', 'OFFLINE', 'PROMO_ID', 1, 1, 11, 660, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (32, 'DataLoader', '2017-08-18 18:03:37.35', NULL, '2017-08-18 18:03:37.35', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 30, -33.7378845, 151.23526, 90, '170818180337348AP0028018', 'OFFLINE', 'PROMO_ID', 1, 1, 11, 660, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (33, 'DataLoader', '2017-08-18 18:03:37.415', NULL, '2017-08-18 18:03:37.415', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 30, -33.7378845, 151.23526, 90, '170818180337386AP0028019', 'OFFLINE', 'PROMO_ID', 1, 1, 11, 660, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (34, 'DataLoader', '2017-08-18 18:03:37.512', NULL, '2017-08-18 18:03:37.512', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 30, -33.7378845, 151.23526, 90, '170818180337497AP0028020', 'OFFLINE', 'PROMO_ID', 1, 1, 11, 660, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (35, 'DataLoader', '2017-08-18 18:03:37.537', NULL, '2017-08-18 18:03:37.537', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 30, -33.7378845, 151.23526, 90, '170818180337535AP0028021', 'OFFLINE', 'PROMO_ID', 1, 1, 11, 690, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (36, 'DataLoader', '2017-08-18 18:03:37.556', NULL, '2017-08-18 18:03:37.556', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 30, -33.7378845, 151.23526, 90, '170818180337554AP0028022', 'OFFLINE', 'PROMO_ID', 1, 1, 11, 690, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (37, 'DataLoader', '2017-08-18 18:03:37.569', NULL, '2017-08-18 18:03:37.569', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 30, -33.7378845, 151.23526, 90, '170818180337567AP0028023', 'OFFLINE', 'PROMO_ID', 1, 1, 11, 690, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (38, 'DataLoader', '2017-08-18 18:03:37.58', NULL, '2017-08-18 18:03:37.58', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 30, -33.7378845, 151.23526, 90, '170818180337575AP0028024', 'OFFLINE', 'PROMO_ID', 1, 1, 11, 690, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (39, 'DataLoader', '2017-08-18 18:03:37.594', NULL, '2017-08-18 18:03:37.594', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 30, -33.7378845, 151.23526, 90, '170818180337592AP0028025', 'OFFLINE', 'PROMO_ID', 1, 1, 11, 720, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (40, 'DataLoader', '2017-08-18 18:03:37.636', NULL, '2017-08-18 18:03:37.636', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 30, -33.7378845, 151.23526, 90, '170818180337628AP0028026', 'OFFLINE', 'PROMO_ID', 1, 1, 11, 720, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (41, 'DataLoader', '2017-08-18 18:03:37.656', NULL, '2017-08-18 18:03:37.656', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 30, -33.7378845, 151.23526, 90, '170818180337646AP0028027', 'OFFLINE', 'PROMO_ID', 1, 1, 11, 720, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (42, 'DataLoader', '2017-08-18 18:03:37.711', NULL, '2017-08-18 18:03:37.711', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 30, -33.7378845, 151.23526, 90, '170818180337670AP0028028', 'OFFLINE', 'PROMO_ID', 1, 1, 11, 720, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (43, 'DataLoader', '2017-08-18 18:03:37.744', NULL, '2017-08-18 18:03:37.744', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 30, -33.7378845, 151.23526, 90, '170818180337738AP0028029', 'OFFLINE', 'PROMO_ID', 1, 1, 11, 750, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (44, 'DataLoader', '2017-08-18 18:03:37.817', NULL, '2017-08-18 18:03:37.817', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 30, -33.7378845, 151.23526, 90, '170818180337782AP0028030', 'OFFLINE', 'PROMO_ID', 1, 1, 11, 750, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (45, 'DataLoader', '2017-08-18 18:03:37.93', NULL, '2017-08-18 18:03:37.93', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 30, -33.7378845, 151.23526, 90, '170818180337928AP0028031', 'OFFLINE', 'PROMO_ID', 1, 1, 11, 750, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (46, 'DataLoader', '2017-08-18 18:03:38.005', NULL, '2017-08-18 18:03:38.005', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 30, -33.7378845, 151.23526, 90, '170818180338003AP0028032', 'OFFLINE', 'PROMO_ID', 1, 1, 11, 750, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (47, 'DataLoader', '2017-08-18 18:03:38.039', NULL, '2017-08-18 18:03:38.039', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 30, -33.7378845, 151.23526, 90, '170818180338036AP0028033', 'OFFLINE', 'PROMO_ID', 1, 1, 11, 780, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (48, 'DataLoader', '2017-08-18 18:03:38.085', NULL, '2017-08-18 18:03:38.085', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 30, -33.7378845, 151.23526, 90, '170818180338084AP0028034', 'OFFLINE', 'PROMO_ID', 1, 1, 11, 780, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (49, 'DataLoader', '2017-08-18 18:03:38.142', NULL, '2017-08-18 18:03:38.142', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 30, -33.7378845, 151.23526, 90, '170818180338140AP0028035', 'OFFLINE', 'PROMO_ID', 1, 1, 11, 780, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (50, 'DataLoader', '2017-08-18 18:03:38.284', NULL, '2017-08-18 18:03:38.284', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 30, -33.7378845, 151.23526, 90, '170818180338235AP0028036', 'OFFLINE', 'PROMO_ID', 1, 1, 11, 780, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (51, 'DataLoader', '2017-08-18 18:03:38.345', NULL, '2017-08-18 18:03:38.345', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 30, -33.7378845, 151.23526, 90, '170818180338340AP0028037', 'OFFLINE', 'PROMO_ID', 1, 1, 11, 810, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (52, 'DataLoader', '2017-08-18 18:03:38.417', NULL, '2017-08-18 18:03:38.417', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 30, -33.7378845, 151.23526, 90, '170818180338410AP0028038', 'OFFLINE', 'PROMO_ID', 1, 1, 11, 810, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (53, 'DataLoader', '2017-08-18 18:03:38.488', NULL, '2017-08-18 18:03:38.488', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 30, -33.7378845, 151.23526, 90, '170818180338486AP0028039', 'OFFLINE', 'PROMO_ID', 1, 1, 11, 810, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (54, 'DataLoader', '2017-08-18 18:03:38.533', NULL, '2017-08-18 18:03:38.533', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 30, -33.7378845, 151.23526, 90, '170818180338531AP0028040', 'OFFLINE', 'PROMO_ID', 1, 1, 11, 810, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (55, 'DataLoader', '2017-08-18 18:03:38.593', NULL, '2017-08-18 18:03:38.593', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 30, -33.7378845, 151.23526, 90, '170818180338592AP0028041', 'OFFLINE', 'PROMO_ID', 1, 1, 11, 840, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (56, 'DataLoader', '2017-08-18 18:03:38.647', NULL, '2017-08-18 18:03:38.647', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 30, -33.7378845, 151.23526, 90, '170818180338633AP0028042', 'OFFLINE', 'PROMO_ID', 1, 1, 11, 840, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (57, 'DataLoader', '2017-08-18 18:03:38.709', NULL, '2017-08-18 18:03:38.709', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 30, -33.7378845, 151.23526, 90, '170818180338708AP0028043', 'OFFLINE', 'PROMO_ID', 1, 1, 11, 840, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (58, 'DataLoader', '2017-08-18 18:03:38.777', NULL, '2017-08-18 18:03:38.777', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 30, -33.7378845, 151.23526, 90, '170818180338751AP0028044', 'OFFLINE', 'PROMO_ID', 1, 1, 11, 840, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (59, 'DataLoader', '2017-08-18 18:03:38.842', NULL, '2017-08-18 18:03:38.842', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 30, -33.7378845, 151.23526, 90, '170818180338840AP0028045', 'OFFLINE', 'PROMO_ID', 1, 1, 11, 870, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (60, 'DataLoader', '2017-08-18 18:03:38.962', NULL, '2017-08-18 18:03:38.962', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 30, -33.7378845, 151.23526, 90, '170818180338960AP0028046', 'OFFLINE', 'PROMO_ID', 1, 1, 11, 870, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (61, 'DataLoader', '2017-08-18 18:03:39.06', NULL, '2017-08-18 18:03:39.06', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 30, -33.7378845, 151.23526, 90, '170818180339048AP0028047', 'OFFLINE', 'PROMO_ID', 1, 1, 11, 870, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (62, 'DataLoader', '2017-08-18 18:03:39.115', NULL, '2017-08-18 18:03:39.115', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 30, -33.7378845, 151.23526, 90, '170818180339103AP0028048', 'OFFLINE', 'PROMO_ID', 1, 1, 11, 870, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (63, 'DataLoader', '2017-08-18 18:03:39.154', NULL, '2017-08-18 18:03:39.154', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 30, -33.7378845, 151.23526, 90, '170818180339141AP0028049', 'OFFLINE', 'PROMO_ID', 1, 1, 11, 900, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (64, 'DataLoader', '2017-08-18 18:03:39.186', NULL, '2017-08-18 18:03:39.186', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 30, -33.7378845, 151.23526, 90, '170818180339185AP0028050', 'OFFLINE', 'PROMO_ID', 1, 1, 11, 900, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (65, 'DataLoader', '2017-08-18 18:03:39.218', NULL, '2017-08-18 18:03:39.218', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 30, -33.7378845, 151.23526, 90, '170818180339215AP0028051', 'OFFLINE', 'PROMO_ID', 1, 1, 11, 900, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (66, 'DataLoader', '2017-08-18 18:03:39.228', NULL, '2017-08-18 18:03:39.228', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 30, -33.7378845, 151.23526, 90, '170818180339227AP0028052', 'OFFLINE', 'PROMO_ID', 1, 1, 11, 900, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (67, 'DataLoader', '2017-08-18 18:03:39.247', NULL, '2017-08-18 18:03:39.247', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 30, -33.7378845, 151.23526, 90, '170818180339246AP0028053', 'OFFLINE', 'PROMO_ID', 1, 1, 11, 930, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (68, 'DataLoader', '2017-08-18 18:03:39.29', NULL, '2017-08-18 18:03:39.29', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 30, -33.7378845, 151.23526, 90, '170818180339284AP0028054', 'OFFLINE', 'PROMO_ID', 1, 1, 11, 930, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (69, 'DataLoader', '2017-08-18 18:03:39.331', NULL, '2017-08-18 18:03:39.331', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 30, -33.7378845, 151.23526, 90, '170818180339330AP0028055', 'OFFLINE', 'PROMO_ID', 1, 1, 11, 930, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (70, 'DataLoader', '2017-08-18 18:03:39.378', NULL, '2017-08-18 18:03:39.378', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 30, -33.7378845, 151.23526, 90, '170818180339376AP0028056', 'OFFLINE', 'PROMO_ID', 1, 1, 11, 930, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (71, 'DataLoader', '2017-08-18 18:03:39.404', NULL, '2017-08-18 18:03:39.404', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 30, -33.7378845, 151.23526, 90, '170818180339396AP0028057', 'OFFLINE', 'PROMO_ID', 1, 1, 11, 960, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (72, 'DataLoader', '2017-08-18 18:03:39.416', NULL, '2017-08-18 18:03:39.416', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 30, -33.7378845, 151.23526, 90, '170818180339415AP0028058', 'OFFLINE', 'PROMO_ID', 1, 1, 11, 960, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (73, 'DataLoader', '2017-08-18 18:03:39.422', NULL, '2017-08-18 18:03:39.422', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 30, -33.7378845, 151.23526, 90, '170818180339421AP0028059', 'OFFLINE', 'PROMO_ID', 1, 1, 11, 960, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (74, 'DataLoader', '2017-08-18 18:03:39.475', NULL, '2017-08-18 18:03:39.475', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 30, -33.7378845, 151.23526, 90, '170818180339456AP0028060', 'OFFLINE', 'PROMO_ID', 1, 1, 11, 960, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (75, 'DataLoader', '2017-08-18 18:03:39.591', NULL, '2017-08-18 18:03:39.591', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 30, -33.7378845, 151.23526, 90, '170818180339589AP0028061', 'OFFLINE', 'PROMO_ID', 1, 1, 11, 990, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (76, 'DataLoader', '2017-08-18 18:03:39.605', NULL, '2017-08-18 18:03:39.605', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 30, -33.7378845, 151.23526, 90, '170818180339598AP0028062', 'OFFLINE', 'PROMO_ID', 1, 1, 11, 990, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (77, 'DataLoader', '2017-08-18 18:03:39.612', NULL, '2017-08-18 18:03:39.612', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 30, -33.7378845, 151.23526, 90, '170818180339611AP0028063', 'OFFLINE', 'PROMO_ID', 1, 1, 11, 990, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (78, 'DataLoader', '2017-08-18 18:03:39.629', NULL, '2017-08-18 18:03:39.629', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 30, -33.7378845, 151.23526, 90, '170818180339620AP0028064', 'OFFLINE', 'PROMO_ID', 1, 1, 11, 990, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (79, 'DataLoader', '2017-08-18 18:03:39.82', NULL, '2017-08-18 18:03:39.82', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180339819AP0028065', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 540, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (80, 'DataLoader', '2017-08-18 18:03:39.923', NULL, '2017-08-18 18:03:39.923', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180339903AP0028066', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 540, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (81, 'DataLoader', '2017-08-18 18:03:39.967', NULL, '2017-08-18 18:03:39.967', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180339957AP0028067', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 540, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (82, 'DataLoader', '2017-08-18 18:03:39.979', NULL, '2017-08-18 18:03:39.979', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180339978AP0028068', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 540, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (83, 'DataLoader', '2017-08-18 18:03:40.053', NULL, '2017-08-18 18:03:40.053', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180340047AP0028069', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 555, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (84, 'DataLoader', '2017-08-18 18:03:40.089', NULL, '2017-08-18 18:03:40.089', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180340084AP0028070', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 555, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (85, 'DataLoader', '2017-08-18 18:03:40.107', NULL, '2017-08-18 18:03:40.107', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180340096AP0028071', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 555, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (86, 'DataLoader', '2017-08-18 18:03:40.165', NULL, '2017-08-18 18:03:40.165', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180340115AP0028072', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 555, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (87, 'DataLoader', '2017-08-18 18:03:40.223', NULL, '2017-08-18 18:03:40.223', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180340201AP0028073', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 570, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (88, 'DataLoader', '2017-08-18 18:03:40.278', NULL, '2017-08-18 18:03:40.278', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180340277AP0028074', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 570, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (89, 'DataLoader', '2017-08-18 18:03:40.341', NULL, '2017-08-18 18:03:40.341', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180340339AP0028075', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 570, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (90, 'DataLoader', '2017-08-18 18:03:40.41', NULL, '2017-08-18 18:03:40.41', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180340409AP0028076', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 570, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (91, 'DataLoader', '2017-08-18 18:03:40.442', NULL, '2017-08-18 18:03:40.442', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180340441AP0028077', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 585, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (92, 'DataLoader', '2017-08-18 18:03:40.453', NULL, '2017-08-18 18:03:40.453', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180340452AP0028078', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 585, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (93, 'DataLoader', '2017-08-18 18:03:40.477', NULL, '2017-08-18 18:03:40.477', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180340476AP0028079', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 585, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (94, 'DataLoader', '2017-08-18 18:03:40.519', NULL, '2017-08-18 18:03:40.519', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180340510AP0028080', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 585, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (95, 'DataLoader', '2017-08-18 18:03:40.564', NULL, '2017-08-18 18:03:40.564', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180340529AP0028081', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 600, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (96, 'DataLoader', '2017-08-18 18:03:40.6', NULL, '2017-08-18 18:03:40.6', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180340599AP0028082', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 600, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (97, 'DataLoader', '2017-08-18 18:03:40.613', NULL, '2017-08-18 18:03:40.613', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180340609AP0028083', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 600, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (98, 'DataLoader', '2017-08-18 18:03:40.623', NULL, '2017-08-18 18:03:40.623', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180340622AP0028084', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 600, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (99, 'DataLoader', '2017-08-18 18:03:40.654', NULL, '2017-08-18 18:03:40.654', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180340650AP0028085', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 615, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (100, 'DataLoader', '2017-08-18 18:03:40.664', NULL, '2017-08-18 18:03:40.664', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180340663AP0028086', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 615, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (101, 'DataLoader', '2017-08-18 18:03:40.675', NULL, '2017-08-18 18:03:40.675', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180340674AP0028087', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 615, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (102, 'DataLoader', '2017-08-18 18:03:40.682', NULL, '2017-08-18 18:03:40.682', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180340680AP0028088', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 615, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (103, 'DataLoader', '2017-08-18 18:03:40.697', NULL, '2017-08-18 18:03:40.697', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180340696AP0028089', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 630, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (104, 'DataLoader', '2017-08-18 18:03:40.716', NULL, '2017-08-18 18:03:40.716', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180340715AP0028090', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 630, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (105, 'DataLoader', '2017-08-18 18:03:40.726', NULL, '2017-08-18 18:03:40.726', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180340725AP0028091', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 630, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (106, 'DataLoader', '2017-08-18 18:03:40.761', NULL, '2017-08-18 18:03:40.761', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180340760AP0028092', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 630, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (107, 'DataLoader', '2017-08-18 18:03:40.787', NULL, '2017-08-18 18:03:40.787', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180340779AP0028093', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 645, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (108, 'DataLoader', '2017-08-18 18:03:40.809', NULL, '2017-08-18 18:03:40.809', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180340808AP0028094', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 645, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (109, 'DataLoader', '2017-08-18 18:03:40.816', NULL, '2017-08-18 18:03:40.816', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180340815AP0028095', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 645, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (110, 'DataLoader', '2017-08-18 18:03:40.821', NULL, '2017-08-18 18:03:40.821', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180340820AP0028096', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 645, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (111, 'DataLoader', '2017-08-18 18:03:40.826', NULL, '2017-08-18 18:03:40.826', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180340825AP0028097', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 660, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (112, 'DataLoader', '2017-08-18 18:03:40.833', NULL, '2017-08-18 18:03:40.833', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180340831AP0028098', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 660, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (113, 'DataLoader', '2017-08-18 18:03:40.839', NULL, '2017-08-18 18:03:40.839', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180340838AP0028099', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 660, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (114, 'DataLoader', '2017-08-18 18:03:40.856', NULL, '2017-08-18 18:03:40.856', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180340855AP0028100', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 660, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (115, 'DataLoader', '2017-08-18 18:03:40.874', NULL, '2017-08-18 18:03:40.874', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180340872AP0028101', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 675, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (116, 'DataLoader', '2017-08-18 18:03:40.885', NULL, '2017-08-18 18:03:40.885', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180340884AP0028102', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 675, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (117, 'DataLoader', '2017-08-18 18:03:40.928', NULL, '2017-08-18 18:03:40.928', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180340909AP0028103', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 675, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (118, 'DataLoader', '2017-08-18 18:03:40.953', NULL, '2017-08-18 18:03:40.953', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180340952AP0028104', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 675, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (119, 'DataLoader', '2017-08-18 18:03:40.967', NULL, '2017-08-18 18:03:40.967', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180340966AP0028105', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 690, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (120, 'DataLoader', '2017-08-18 18:03:40.976', NULL, '2017-08-18 18:03:40.976', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180340975AP0028106', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 690, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (121, 'DataLoader', '2017-08-18 18:03:40.987', NULL, '2017-08-18 18:03:40.987', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180340986AP0028107', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 690, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (122, 'DataLoader', '2017-08-18 18:03:41', NULL, '2017-08-18 18:03:41', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180340998AP0028108', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 690, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (123, 'DataLoader', '2017-08-18 18:03:41.013', NULL, '2017-08-18 18:03:41.013', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180341012AP0028109', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 705, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (124, 'DataLoader', '2017-08-18 18:03:41.023', NULL, '2017-08-18 18:03:41.023', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180341021AP0028110', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 705, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (125, 'DataLoader', '2017-08-18 18:03:41.043', NULL, '2017-08-18 18:03:41.043', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180341041AP0028111', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 705, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (126, 'DataLoader', '2017-08-18 18:03:41.058', NULL, '2017-08-18 18:03:41.058', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180341056AP0028112', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 705, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (127, 'DataLoader', '2017-08-18 18:03:41.077', NULL, '2017-08-18 18:03:41.077', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180341073AP0028113', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 720, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (128, 'DataLoader', '2017-08-18 18:03:41.094', NULL, '2017-08-18 18:03:41.094', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180341092AP0028114', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 720, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (129, 'DataLoader', '2017-08-18 18:03:41.104', NULL, '2017-08-18 18:03:41.104', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180341103AP0028115', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 720, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (130, 'DataLoader', '2017-08-18 18:03:41.134', NULL, '2017-08-18 18:03:41.134', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180341132AP0028116', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 720, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (131, 'DataLoader', '2017-08-18 18:03:41.143', NULL, '2017-08-18 18:03:41.143', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180341142AP0028117', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 735, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (132, 'DataLoader', '2017-08-18 18:03:41.152', NULL, '2017-08-18 18:03:41.152', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180341151AP0028118', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 735, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (133, 'DataLoader', '2017-08-18 18:03:41.16', NULL, '2017-08-18 18:03:41.16', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180341159AP0028119', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 735, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (134, 'DataLoader', '2017-08-18 18:03:41.166', NULL, '2017-08-18 18:03:41.166', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180341165AP0028120', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 735, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (135, 'DataLoader', '2017-08-18 18:03:41.183', NULL, '2017-08-18 18:03:41.183', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180341182AP0028121', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 750, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (136, 'DataLoader', '2017-08-18 18:03:41.191', NULL, '2017-08-18 18:03:41.191', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180341189AP0028122', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 750, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (137, 'DataLoader', '2017-08-18 18:03:41.201', NULL, '2017-08-18 18:03:41.201', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180341200AP0028123', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 750, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (138, 'DataLoader', '2017-08-18 18:03:41.222', NULL, '2017-08-18 18:03:41.222', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180341221AP0028124', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 750, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (139, 'DataLoader', '2017-08-18 18:03:41.237', NULL, '2017-08-18 18:03:41.237', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180341236AP0028125', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 765, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (140, 'DataLoader', '2017-08-18 18:03:41.249', NULL, '2017-08-18 18:03:41.249', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180341248AP0028126', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 765, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (141, 'DataLoader', '2017-08-18 18:03:41.26', NULL, '2017-08-18 18:03:41.26', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180341259AP0028127', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 765, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (142, 'DataLoader', '2017-08-18 18:03:41.266', NULL, '2017-08-18 18:03:41.266', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180341265AP0028128', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 765, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (143, 'DataLoader', '2017-08-18 18:03:41.273', NULL, '2017-08-18 18:03:41.273', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180341272AP0028129', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 780, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (144, 'DataLoader', '2017-08-18 18:03:41.281', NULL, '2017-08-18 18:03:41.281', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180341280AP0028130', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 780, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (145, 'DataLoader', '2017-08-18 18:03:41.285', NULL, '2017-08-18 18:03:41.285', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180341284AP0028131', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 780, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (146, 'DataLoader', '2017-08-18 18:03:41.295', NULL, '2017-08-18 18:03:41.295', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180341293AP0028132', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 780, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (147, 'DataLoader', '2017-08-18 18:03:41.303', NULL, '2017-08-18 18:03:41.303', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180341300AP0028133', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 795, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (148, 'DataLoader', '2017-08-18 18:03:41.324', NULL, '2017-08-18 18:03:41.324', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180341322AP0028134', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 795, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (149, 'DataLoader', '2017-08-18 18:03:41.329', NULL, '2017-08-18 18:03:41.329', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180341328AP0028135', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 795, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (150, 'DataLoader', '2017-08-18 18:03:41.337', NULL, '2017-08-18 18:03:41.337', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180341336AP0028136', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 795, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (151, 'DataLoader', '2017-08-18 18:03:41.343', NULL, '2017-08-18 18:03:41.343', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180341342AP0028137', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 810, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (152, 'DataLoader', '2017-08-18 18:03:41.356', NULL, '2017-08-18 18:03:41.356', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180341355AP0028138', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 810, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (153, 'DataLoader', '2017-08-18 18:03:41.361', NULL, '2017-08-18 18:03:41.361', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180341360AP0028139', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 810, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (154, 'DataLoader', '2017-08-18 18:03:41.366', NULL, '2017-08-18 18:03:41.366', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180341365AP0028140', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 810, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (155, 'DataLoader', '2017-08-18 18:03:41.371', NULL, '2017-08-18 18:03:41.371', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180341370AP0028141', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 825, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (156, 'DataLoader', '2017-08-18 18:03:41.385', NULL, '2017-08-18 18:03:41.385', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180341384AP0028142', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 825, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (157, 'DataLoader', '2017-08-18 18:03:41.407', NULL, '2017-08-18 18:03:41.407', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180341400AP0028143', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 825, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (158, 'DataLoader', '2017-08-18 18:03:41.444', NULL, '2017-08-18 18:03:41.444', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180341423AP0028144', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 825, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (159, 'DataLoader', '2017-08-18 18:03:41.458', NULL, '2017-08-18 18:03:41.458', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180341457AP0028145', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 840, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (160, 'DataLoader', '2017-08-18 18:03:41.469', NULL, '2017-08-18 18:03:41.469', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180341468AP0028146', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 840, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (161, 'DataLoader', '2017-08-18 18:03:41.485', NULL, '2017-08-18 18:03:41.485', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180341484AP0028147', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 840, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (162, 'DataLoader', '2017-08-18 18:03:41.508', NULL, '2017-08-18 18:03:41.508', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180341507AP0028148', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 840, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (163, 'DataLoader', '2017-08-18 18:03:41.514', NULL, '2017-08-18 18:03:41.514', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180341513AP0028149', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 855, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (164, 'DataLoader', '2017-08-18 18:03:41.529', NULL, '2017-08-18 18:03:41.529', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180341528AP0028150', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 855, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (165, 'DataLoader', '2017-08-18 18:03:41.549', NULL, '2017-08-18 18:03:41.549', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180341548AP0028151', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 855, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (166, 'DataLoader', '2017-08-18 18:03:41.601', NULL, '2017-08-18 18:03:41.601', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180341600AP0028152', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 855, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (167, 'DataLoader', '2017-08-18 18:03:41.645', NULL, '2017-08-18 18:03:41.645', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180341644AP0028153', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 870, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (168, 'DataLoader', '2017-08-18 18:03:41.669', NULL, '2017-08-18 18:03:41.669', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180341668AP0028154', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 870, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (169, 'DataLoader', '2017-08-18 18:03:41.692', NULL, '2017-08-18 18:03:41.692', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180341691AP0028155', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 870, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (170, 'DataLoader', '2017-08-18 18:03:41.72', NULL, '2017-08-18 18:03:41.72', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180341719AP0028156', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 870, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (171, 'DataLoader', '2017-08-18 18:03:41.737', NULL, '2017-08-18 18:03:41.737', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180341735AP0028157', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 885, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (172, 'DataLoader', '2017-08-18 18:03:41.752', NULL, '2017-08-18 18:03:41.752', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180341751AP0028158', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 885, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (173, 'DataLoader', '2017-08-18 18:03:41.787', NULL, '2017-08-18 18:03:41.787', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180341786AP0028159', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 885, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (174, 'DataLoader', '2017-08-18 18:03:41.801', NULL, '2017-08-18 18:03:41.801', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180341799AP0028160', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 885, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (175, 'DataLoader', '2017-08-18 18:03:41.822', NULL, '2017-08-18 18:03:41.822', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180341818AP0028161', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 900, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (176, 'DataLoader', '2017-08-18 18:03:41.83', NULL, '2017-08-18 18:03:41.83', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180341829AP0028162', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 900, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (177, 'DataLoader', '2017-08-18 18:03:41.836', NULL, '2017-08-18 18:03:41.836', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180341835AP0028163', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 900, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (178, 'DataLoader', '2017-08-18 18:03:41.849', NULL, '2017-08-18 18:03:41.849', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180341847AP0028164', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 900, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (179, 'DataLoader', '2017-08-18 18:03:41.859', NULL, '2017-08-18 18:03:41.859', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180341858AP0028165', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 915, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (180, 'DataLoader', '2017-08-18 18:03:41.873', NULL, '2017-08-18 18:03:41.873', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180341872AP0028166', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 915, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (181, 'DataLoader', '2017-08-18 18:03:41.884', NULL, '2017-08-18 18:03:41.884', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180341883AP0028167', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 915, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (182, 'DataLoader', '2017-08-18 18:03:41.891', NULL, '2017-08-18 18:03:41.891', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180341890AP0028168', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 915, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (183, 'DataLoader', '2017-08-18 18:03:41.924', NULL, '2017-08-18 18:03:41.924', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180341906AP0028169', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 930, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (184, 'DataLoader', '2017-08-18 18:03:41.949', NULL, '2017-08-18 18:03:41.949', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180341948AP0028170', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 930, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (185, 'DataLoader', '2017-08-18 18:03:41.962', NULL, '2017-08-18 18:03:41.962', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180341960AP0028171', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 930, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (186, 'DataLoader', '2017-08-18 18:03:41.997', NULL, '2017-08-18 18:03:41.997', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180341990AP0028172', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 930, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (187, 'DataLoader', '2017-08-18 18:03:42.013', NULL, '2017-08-18 18:03:42.013', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180342011AP0028173', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 945, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (188, 'DataLoader', '2017-08-18 18:03:42.041', NULL, '2017-08-18 18:03:42.041', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180342040AP0028174', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 945, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (189, 'DataLoader', '2017-08-18 18:03:42.06', NULL, '2017-08-18 18:03:42.06', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180342059AP0028175', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 945, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (190, 'DataLoader', '2017-08-18 18:03:42.164', NULL, '2017-08-18 18:03:42.164', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180342142AP0028176', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 945, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (191, 'DataLoader', '2017-08-18 18:03:42.206', NULL, '2017-08-18 18:03:42.206', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180342204AP0028177', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 960, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (192, 'DataLoader', '2017-08-18 18:03:42.257', NULL, '2017-08-18 18:03:42.257', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180342256AP0028178', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 960, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (193, 'DataLoader', '2017-08-18 18:03:42.308', NULL, '2017-08-18 18:03:42.308', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180342307AP0028179', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 960, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (194, 'DataLoader', '2017-08-18 18:03:42.329', NULL, '2017-08-18 18:03:42.329', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180342327AP0028180', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 960, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (195, 'DataLoader', '2017-08-18 18:03:42.374', NULL, '2017-08-18 18:03:42.374', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180342372AP0028181', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 975, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (196, 'DataLoader', '2017-08-18 18:03:42.409', NULL, '2017-08-18 18:03:42.409', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180342408AP0028182', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 975, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (197, 'DataLoader', '2017-08-18 18:03:42.45', NULL, '2017-08-18 18:03:42.45', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180342449AP0028183', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 975, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (198, 'DataLoader', '2017-08-18 18:03:42.495', NULL, '2017-08-18 18:03:42.495', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180342494AP0028184', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 975, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (199, 'DataLoader', '2017-08-18 18:03:42.532', NULL, '2017-08-18 18:03:42.532', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180342531AP0028185', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 990, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (200, 'DataLoader', '2017-08-18 18:03:42.565', NULL, '2017-08-18 18:03:42.565', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180342564AP0028186', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 990, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (201, 'DataLoader', '2017-08-18 18:03:42.602', NULL, '2017-08-18 18:03:42.602', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180342601AP0028187', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 990, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (202, 'DataLoader', '2017-08-18 18:03:42.643', NULL, '2017-08-18 18:03:42.643', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180342642AP0028188', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 990, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (203, 'DataLoader', '2017-08-18 18:03:42.688', NULL, '2017-08-18 18:03:42.688', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180342686AP0028189', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 1005, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (204, 'DataLoader', '2017-08-18 18:03:42.759', NULL, '2017-08-18 18:03:42.759', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180342757AP0028190', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 1005, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (205, 'DataLoader', '2017-08-18 18:03:42.846', NULL, '2017-08-18 18:03:42.846', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180342845AP0028191', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 1005, 1, 1, 1);
INSERT INTO booking (id, created_by, created_time, modified_by, modified_time, act_price, address_id, cat_id, description, dis_flat, dis_percent, duration, lat, lon, paid_amount, payment_id, payment_mode, promo_code, promo_id, shop_id, shop_service_id, slot, status, sub_cat_id, user_id) VALUES (206, 'DataLoader', '2017-08-18 18:03:42.907', NULL, '2017-08-18 18:03:42.907', 100, 1, 1, 'baal katana hai, bahut jhr raha hai', 10, 0, 15, -33.7378845, 151.23526, 90, '170818180342906AP0028192', 'OFFLINE', 'PROMO_ID', 1, 2, 12, 1005, 1, 1, 1);


--
-- TOC entry 3071 (class 0 OID 17545993)
-- Dependencies: 191
-- Data for Name: category; Type: TABLE DATA; Schema: public; Owner: jlzbtdskdtgfse
--

INSERT INTO category (id, name) VALUES (6, 'Hair');
INSERT INTO category (id, name) VALUES (1, 'Nails');
INSERT INTO category (id, name) VALUES (3, 'AesThetics');
INSERT INTO category (id, name) VALUES (2, 'Make Up');


--
-- TOC entry 3086 (class 0 OID 0)
-- Dependencies: 188
-- Name: hibernate_sequence; Type: SEQUENCE SET; Schema: public; Owner: jlzbtdskdtgfse
--

SELECT pg_catalog.setval('hibernate_sequence', 206, true);


--
-- TOC entry 3067 (class 0 OID 11348825)
-- Dependencies: 187
-- Data for Name: service_booking_details; Type: TABLE DATA; Schema: public; Owner: jlzbtdskdtgfse
--



--
-- TOC entry 3072 (class 0 OID 17545998)
-- Dependencies: 192
-- Data for Name: shop; Type: TABLE DATA; Schema: public; Owner: jlzbtdskdtgfse
--

INSERT INTO shop (id, created_by, created_time, modified_by, modified_time, active, address, approved, area, break_duration, break_time, city, description, end_time, lat, locality, lon, max_seat, mobile, name, owner_id, phone, pin_code, rating, start_time, state, street_name, working_days) VALUES (9, 'DataLoader', '2017-08-18 18:03:36.226', NULL, '2017-08-18 18:03:36.226', true, 'address_1', true, 'area_1', 60, 840, 'city_1', 'we are specialist', 1020, -33.7378845, 'locality_1', 151.23526, 4, 1234567890, 'shop_1', 1, 1234567890, 1, 4, 540, 'state_1', 'streetname_1', 'MON,TUE,WED,THU,FRI');
INSERT INTO shop (id, created_by, created_time, modified_by, modified_time, active, address, approved, area, break_duration, break_time, city, description, end_time, lat, locality, lon, max_seat, mobile, name, owner_id, phone, pin_code, rating, start_time, state, street_name, working_days) VALUES (10, 'DataLoader', '2017-08-18 18:03:36.258', NULL, '2017-08-18 18:03:36.258', true, 'address_2', true, 'area_2', 60, 840, 'city_2', 'we are specialist', 1020, -33.7378845, 'locality_2', 151.23526, 4, 1234567890, 'shop_2', 2, 1234567890, 1, 4, 540, 'state_2', 'streetname_2', 'MON,TUE,WED,THU,FRI');


--
-- TOC entry 3073 (class 0 OID 17546006)
-- Dependencies: 193
-- Data for Name: shop_service; Type: TABLE DATA; Schema: public; Owner: jlzbtdskdtgfse
--

INSERT INTO shop_service (id, created_by, created_time, modified_by, modified_time, act_price, active, approved, avg_time, break_duration, break_time, cat_id, description, dis_flat, dis_percent, end_time, lat, lon, max_seat, name, rating, serving_person_name, shop_id, shop_owner_id, start_time, sub_cat_id, wknd_act_price, wknd_end_time, wknd_start_time, working_days) VALUES (11, 'DataLoader', '2017-08-18 18:03:36.367', NULL, '2017-08-18 18:03:36.367', 100, true, true, 30, 60, 840, 1, 'work with passion', 10, 0, 1020, -33.7378845, 151.23526, 4, 'service_1', 4, 'personname_1', 1, NULL, 540, 1, NULL, 0, 0, 'MON,TUE,WED,THU,FRI');
INSERT INTO shop_service (id, created_by, created_time, modified_by, modified_time, act_price, active, approved, avg_time, break_duration, break_time, cat_id, description, dis_flat, dis_percent, end_time, lat, lon, max_seat, name, rating, serving_person_name, shop_id, shop_owner_id, start_time, sub_cat_id, wknd_act_price, wknd_end_time, wknd_start_time, working_days) VALUES (12, 'DataLoader', '2017-08-18 18:03:36.394', NULL, '2017-08-18 18:03:36.394', 100, true, true, 15, 60, 840, 1, 'work with passion', 10, 0, 1020, -33.7378845, 151.23526, 4, 'service_1', 4, 'personname_1', 2, NULL, 540, 1, NULL, 0, 0, 'MON,TUE,WED,THU,FRI');
INSERT INTO shop_service (id, created_by, created_time, modified_by, modified_time, act_price, active, approved, avg_time, break_duration, break_time, cat_id, description, dis_flat, dis_percent, end_time, lat, lon, max_seat, name, rating, serving_person_name, shop_id, shop_owner_id, start_time, sub_cat_id, wknd_act_price, wknd_end_time, wknd_start_time, working_days) VALUES (13, 'DataLoader', '2017-08-18 18:03:36.433', NULL, '2017-08-18 18:03:36.433', 100, true, true, 30, 60, 840, 1, 'work with passion', 10, 0, 1020, -33.7378845, 151.23526, 4, 'service_2', 4, 'personname_2', 1, NULL, 540, 2, NULL, 0, 0, 'MON,TUE,WED,THU,FRI');
INSERT INTO shop_service (id, created_by, created_time, modified_by, modified_time, act_price, active, approved, avg_time, break_duration, break_time, cat_id, description, dis_flat, dis_percent, end_time, lat, lon, max_seat, name, rating, serving_person_name, shop_id, shop_owner_id, start_time, sub_cat_id, wknd_act_price, wknd_end_time, wknd_start_time, working_days) VALUES (14, 'DataLoader', '2017-08-18 18:03:36.504', NULL, '2017-08-18 18:03:36.504', 100, true, true, 15, 60, 840, 1, 'work with passion', 10, 0, 1020, -33.7378845, 151.23526, 4, 'service_2', 4, 'personname_2', 2, NULL, 540, 2, NULL, 0, 0, 'MON,TUE,WED,THU,FRI');


--
-- TOC entry 3074 (class 0 OID 17546014)
-- Dependencies: 194
-- Data for Name: sub_category; Type: TABLE DATA; Schema: public; Owner: jlzbtdskdtgfse
--

INSERT INTO sub_category (id, cat_id, name) VALUES (8, 6, 'Mens Hair Cut');
INSERT INTO sub_category (id, cat_id, name) VALUES (7, 6, 'Womens Hair Cut');
INSERT INTO sub_category (id, cat_id, name) VALUES (10, 6, 'Bridal Hair');
INSERT INTO sub_category (id, cat_id, name) VALUES (9, 6, 'Child Hair Cut');
INSERT INTO sub_category (id, cat_id, name) VALUES (15, 2, 'Eye MakeUp');
INSERT INTO sub_category (id, cat_id, name) VALUES (12, 2, 'Eyelash Tinting');
INSERT INTO sub_category (id, cat_id, name) VALUES (11, 6, 'Hair Coloring ');
INSERT INTO sub_category (id, cat_id, name) VALUES (14, 2, 'Eye Brow Shaping
');
INSERT INTO sub_category (id, cat_id, name) VALUES (13, 2, 'Bridal Makeup');
INSERT INTO sub_category (id, cat_id, name) VALUES (16, 3, 'Facial');
INSERT INTO sub_category (id, cat_id, name) VALUES (17, 3, 'Tanning
');
INSERT INTO sub_category (id, cat_id, name) VALUES (19, 3, 'Face Mask');
INSERT INTO sub_category (id, cat_id, name) VALUES (18, 3, 'Face Peeling');
INSERT INTO sub_category (id, cat_id, name) VALUES (20, 1, 'Gel nails');
INSERT INTO sub_category (id, cat_id, name) VALUES (21, 1, 'AcryLic nails');


--
-- TOC entry 3066 (class 0 OID 11348819)
-- Dependencies: 186
-- Data for Name: user_address; Type: TABLE DATA; Schema: public; Owner: jlzbtdskdtgfse
--



--
-- TOC entry 3087 (class 0 OID 0)
-- Dependencies: 185
-- Name: user_address_id_seq; Type: SEQUENCE SET; Schema: public; Owner: jlzbtdskdtgfse
--

SELECT pg_catalog.setval('user_address_id_seq', 1, false);


--
-- TOC entry 3075 (class 0 OID 17546019)
-- Dependencies: 195
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: jlzbtdskdtgfse
--

INSERT INTO users (id, created_by, created_time, modified_by, modified_time, active, email, lat, lon, mobile, name, otp, password, pro_image, roles, sex, user_type) VALUES (4, 'DataLoader', '2017-08-18 18:03:35.781', NULL, '2017-08-18 18:03:35.781', true, 'user_1@gmail.com', -33.7378845, 151.23526, '1234567891', 'user_1', NULL, 'password', 'user_proImage_1.jpeg', 'ROLE_USER', 'F', 'USER');
INSERT INTO users (id, created_by, created_time, modified_by, modified_time, active, email, lat, lon, mobile, name, otp, password, pro_image, roles, sex, user_type) VALUES (5, 'DataLoader', '2017-08-18 18:03:35.795', NULL, '2017-08-18 18:03:35.795', true, 'user_2@gmail.com', -33.7378845, 151.23526, '1234567892', 'user_2', NULL, 'password', 'user_proImage_2.jpeg', 'ROLE_USER', 'F', 'USER');


--
-- TOC entry 2935 (class 2606 OID 17545984)
-- Name: admin admin_pkey; Type: CONSTRAINT; Schema: public; Owner: jlzbtdskdtgfse
--

ALTER TABLE ONLY admin
    ADD CONSTRAINT admin_pkey PRIMARY KEY (id);


--
-- TOC entry 2937 (class 2606 OID 17545992)
-- Name: booking booking_pkey; Type: CONSTRAINT; Schema: public; Owner: jlzbtdskdtgfse
--

ALTER TABLE ONLY booking
    ADD CONSTRAINT booking_pkey PRIMARY KEY (id);


--
-- TOC entry 2939 (class 2606 OID 17545997)
-- Name: category category_pkey; Type: CONSTRAINT; Schema: public; Owner: jlzbtdskdtgfse
--

ALTER TABLE ONLY category
    ADD CONSTRAINT category_pkey PRIMARY KEY (id);


--
-- TOC entry 2933 (class 2606 OID 11348830)
-- Name: service_booking_details service_booking_details_pkey; Type: CONSTRAINT; Schema: public; Owner: jlzbtdskdtgfse
--

ALTER TABLE ONLY service_booking_details
    ADD CONSTRAINT service_booking_details_pkey PRIMARY KEY (request_id);


--
-- TOC entry 2941 (class 2606 OID 17546005)
-- Name: shop shop_pkey; Type: CONSTRAINT; Schema: public; Owner: jlzbtdskdtgfse
--

ALTER TABLE ONLY shop
    ADD CONSTRAINT shop_pkey PRIMARY KEY (id);


--
-- TOC entry 2943 (class 2606 OID 17546013)
-- Name: shop_service shop_service_pkey; Type: CONSTRAINT; Schema: public; Owner: jlzbtdskdtgfse
--

ALTER TABLE ONLY shop_service
    ADD CONSTRAINT shop_service_pkey PRIMARY KEY (id);


--
-- TOC entry 2945 (class 2606 OID 17546018)
-- Name: sub_category sub_category_pkey; Type: CONSTRAINT; Schema: public; Owner: jlzbtdskdtgfse
--

ALTER TABLE ONLY sub_category
    ADD CONSTRAINT sub_category_pkey PRIMARY KEY (id);


--
-- TOC entry 2931 (class 2606 OID 11348824)
-- Name: user_address user_address_pkey; Type: CONSTRAINT; Schema: public; Owner: jlzbtdskdtgfse
--

ALTER TABLE ONLY user_address
    ADD CONSTRAINT user_address_pkey PRIMARY KEY (id);


--
-- TOC entry 2947 (class 2606 OID 17546026)
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: jlzbtdskdtgfse
--

ALTER TABLE ONLY users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- TOC entry 3082 (class 0 OID 0)
-- Dependencies: 7
-- Name: public; Type: ACL; Schema: -; Owner: jlzbtdskdtgfse
--

GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- TOC entry 3084 (class 0 OID 0)
-- Dependencies: 601
-- Name: plpgsql; Type: ACL; Schema: -; Owner: postgres
--

GRANT ALL ON LANGUAGE plpgsql TO jlzbtdskdtgfse;


-- Completed on 2017-08-19 00:34:08

--
-- PostgreSQL database dump complete
--

