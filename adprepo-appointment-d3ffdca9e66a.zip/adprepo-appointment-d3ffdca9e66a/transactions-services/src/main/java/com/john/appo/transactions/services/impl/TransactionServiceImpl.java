package com.john.appo.transactions.services.impl;

import com.john.appo.entity.OrderAndRefund;
import com.john.appo.entity.Payment;
import com.john.appo.entity.repository.OrderAndRefundRepository;
import com.john.appo.entity.repository.PaymentRepository;
import com.john.appo.enums.ErrorCode;
import com.john.appo.output.ApiResponse;
import com.john.appo.transactions.services.TransactionService;
import com.john.appo.transactions.services.TransactionServiceHelper;
import com.john.appo.transactions.services.razorpay.RazorPayClient;
import com.john.appo.utils.StringUtils;
import com.john.appo.security.service.AuthenticationService;
import com.razorpay.RazorpayException;
import com.razorpay.Refund;
import org.hibernate.Session;
import org.hibernate.engine.spi.SessionImplementor;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.persistence.EntityManager;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

/**
 * @author krishna.kumar
 */
/*
Note*   : This payment will be auto-refunded if not captured within 5 days of creation.
        : Payment done by sending payment link comes under Orders and it is by default captured.
        : Payment done by app is not captured by default(i.e. Authorized, we need to make it captured)
        : Only those payments can be refunded who's status is captured.
*/

@Service
public class TransactionServiceImpl implements TransactionService {

    private static final Logger logger = LoggerFactory.getLogger(TransactionServiceImpl.class);
    @Autowired
    AuthenticationService authenticationService;
    @Autowired
    PaymentRepository paymentRepository;
    @Autowired
    OrderAndRefundRepository orderAndRefundRepository;
    @Autowired
    TransactionServiceHelper servicesHelper;
    @Autowired
    private EntityManager entityManager;

    @Override
    public ApiResponse savePayment(String paymentId, String bookingId) {
        if (StringUtils.isEmpty(paymentId) || StringUtils.isEmpty(bookingId))
            return new ApiResponse(ErrorCode.NO_PARAM_IN_REQUEST);
        if (!servicesHelper.isBookingExist(bookingId))
            return new ApiResponse(ErrorCode.INVALID_BOOKING_ID, bookingId);

        //Check to see if payment already has been saved for this payment Id.
        Payment ePayment = paymentRepository.findOne(paymentId);
        if (ePayment != null) {
            logger.debug("Payment already exists for payment id : {} and booking id : {}", paymentId, bookingId);
            return new ApiResponse(ePayment);
        }
        Payment payment = null;
        try {
            com.razorpay.Payment razorPayment = RazorPayClient.getInstance().Payments.fetch(paymentId);
            payment = servicesHelper.getPaymentEntity(razorPayment);
            //Check to make sure this payment id exists in razor pay server
            if (payment != null && !StringUtils.isEmpty(payment.getId())) {
                payment.setBookingId(bookingId);
                payment.setUserId(authenticationService.getUser().getUserId());
                paymentRepository.save(payment);
                logger.debug("Payment has been saved successfully for payment id : {} and booking id : {}", paymentId, bookingId);
            }
            //Capture payment in order to save it permanently otherwise it will be refunded automatically with in 5 days
            capturePayment(paymentId, payment.getAmount() - payment.getAmountRefunded());
        } catch (RazorpayException e) {
            logger.debug("Exception during persisting payment entity : ", e);
            return new ApiResponse(ErrorCode.UNKNOWN_EXCEPTION, e.toString());
        }
        return new ApiResponse(payment);
    }

    @Override
    public ApiResponse getPayment(String paymentId) {
        if (StringUtils.isEmpty(paymentId))
            return null;
        Payment payment = paymentRepository.findOne(paymentId);
        return new ApiResponse(payment);
    }

    @Override
    public ApiResponse getAllPayments() {
        List<Payment> paymentList = paymentRepository.findAll();
        return new ApiResponse(paymentList);
    }

    @Override
    public void capturePayment(String paymentId, long amountInRs) {
        if (!StringUtils.isEmpty(paymentId) && amountInRs > 0) {
            try {
                JSONObject captureRequest = new JSONObject();
                captureRequest.put("amount", amountInRs * 100); // Amount should be in paise
                RazorPayClient.getInstance().Payments.capture(paymentId, captureRequest);
                logger.debug("Payment has been captured successfully for an amount(In Rs) : {} and payment id : {}", amountInRs, paymentId);
            } catch (RazorpayException e) {
                logger.debug("Exception during capturing payment : {}", e.getMessage());
            }
        }
    }

    @Override
    public ApiResponse refundForPayment(String paymentId, String bookingId, long refundAmountInRs) {
        if (StringUtils.isEmpty(paymentId) || StringUtils.isEmpty(bookingId) || refundAmountInRs == 0)
            return new ApiResponse(ErrorCode.INPUT_PARAM_NOT_CORRECT);
        if (!servicesHelper.isBookingExist(bookingId))
            return new ApiResponse(ErrorCode.INVALID_BOOKING_ID, bookingId);

        //Check to see if payment already has been saved for this payment Id.
        Payment ePayment = paymentRepository.findOne(paymentId);
        if (ePayment == null) {
            logger.debug("No Payment exists for payment id : {} and booking id : {}", paymentId, bookingId);
            return new ApiResponse(ErrorCode.INVALID_REQUEST_FOR_REFUND, paymentId, bookingId);
        }
        OrderAndRefund refund = null;
        try {
            JSONObject refundRequest = new JSONObject();
            refundRequest.put("amount", refundAmountInRs * 100); // Amount should be in paise. If no amount specified, full refund will be done
            Refund razorRefund = RazorPayClient.getInstance().Payments.refund(paymentId, refundRequest);
            refund = servicesHelper.getRefundEntity(razorRefund);
            //Check to make sure this payment id exists in razor pay server and then save in our local as well
            if (refund != null && !StringUtils.isEmpty(refund.getId())) {
                refund.setBookingId(bookingId);
                refund.setUserId(authenticationService.getUser().getUserId());
                orderAndRefundRepository.save(refund);
            }
            //Update payment table as well with refund id
            Connection conn = null;
            PreparedStatement ps = null;
            try {
                conn = getConnection();
                ps = conn.prepareStatement("update payment set refund_id = ? where id = ?");
                ps.setString(1, refund.getId());
                ps.setString(2, paymentId);
                int updatedRecords = ps.executeUpdate();
                logger.debug("{} Record of Payment has been updated with refund id : {}", updatedRecords, refund.getId());
            } catch (SQLException ex) {
                logger.debug("Error while updating payment for refund id : {} : {}", refund.getId(), ex);
                return new ApiResponse(ErrorCode.FOUND_EXCEPTION, ex.getMessage());
            } finally {
                if (ps != null)
                    try {
                        ps.close();
                    } catch (Exception e) {
                    }
                if (conn != null)
                    try {
                        if (!conn.isClosed()) {
                            conn.close();
                        }
                    } catch (Exception e) {
                    }
            }
            logger.debug("Amount {}/- Rs has been refunded for payment id : {} and booking id : {}", refundAmountInRs, paymentId, bookingId);
        } catch (RazorpayException e) {
            logger.debug("Exception during refunding payment : {}", e.getMessage());
            return new ApiResponse(ErrorCode.FOUND_EXCEPTION, e.getMessage());
        }
        return new ApiResponse(refund);
    }

    //TODO need to put at one place
    private Connection getConnection() {
        Connection conn = null;
        SessionImplementor sessionImpl = (SessionImplementor) entityManager.unwrap(Session.class);
        try {
            conn = sessionImpl.getJdbcConnectionAccess().obtainConnection();
        } catch (SQLException e) {
            logger.info("Getting an exception while trying to establish a connection {}", e.getMessage());
            logger.debug("Exception while trying to create a connection {}", e);
        }
        return conn;
    }
}
