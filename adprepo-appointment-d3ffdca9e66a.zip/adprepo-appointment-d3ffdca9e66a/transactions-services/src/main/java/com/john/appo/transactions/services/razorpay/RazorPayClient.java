package com.john.appo.transactions.services.razorpay;

import com.john.appo.constants.C;
import com.razorpay.RazorpayClient;
import com.razorpay.RazorpayException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author krishna.kumar
 */
public class RazorPayClient {
    private static final Logger logger = LoggerFactory.getLogger(RazorPayClient.class);
    public static RazorpayClient INSTANCE;

    private RazorPayClient() {
    }

    public static RazorpayClient getInstance() {
        if (INSTANCE == null) {
            try {
                INSTANCE = new RazorpayClient(C.RAZOR_PAY_API_KEY, C.RAZOR_PAY_API_SECRET, Boolean.TRUE);
            } catch (RazorpayException e) {
                logger.debug("Exception during initialization of Razor Pay Client : ", e);
            }
        }
        return INSTANCE;
    }
}
