package com.john.appo.transactions.services;

import com.john.appo.entity.Payment;
import com.john.appo.output.ApiResponse;

/**
 * @author krishna.kumar
 */
public interface TransactionService {
    ApiResponse savePayment(String paymentId, String bookingId);
    ApiResponse getPayment(String paymentId);
    ApiResponse getAllPayments();
    /*
    * The amount to be captured (should be equal to the authorized amount)
    */
    void capturePayment(String paymentId, long amountInRs);

    ApiResponse refundForPayment(String paymentId, String bookingId, long refundAmountInRs);
}
