package com.john.appo.transactions.services;

import com.john.appo.constants.C;
import com.john.appo.entity.Booking;
import com.john.appo.entity.OrderAndRefund;
import com.john.appo.entity.Payment;
import com.john.appo.entity.ServiceSlotBooking;
import com.john.appo.entity.repository.BookingRepository;
import com.john.appo.entity.repository.ServiceSlotBookingRepository;
import com.john.appo.enums.TimeZoneList;
import com.john.appo.utils.StringUtils;
import com.razorpay.Order;
import com.razorpay.Refund;
import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.List;

/**
 * @author krishna.kumar
 */
@Service
public class TransactionServiceHelper {

    private static final Logger logger = LoggerFactory.getLogger(TransactionServiceHelper.class);
    @Autowired
    ServiceSlotBookingRepository slotBookingRepository;

    //get Payment entity with original Razor pay properties
    public Payment getPaymentEntity(com.razorpay.Payment razorPayment) {
        Payment payment = new Payment();
        if (razorPayment != null) {
            JSONObject modelJson = razorPayment.toJson();
            for (Object key : modelJson.keySet()) {
                String propKey = (String) key;
                Object value = modelJson.get(propKey);
                switch (propKey) {
                    case C.RAZOR_PAY_ID:
                        payment.setId((String) value);
                        break;
                    case C.RAZOR_PAY_ENTITY:
                        payment.setEntity((String) value);
                        break;
                    case C.RAZOR_PAY_AMOUNT:
                        payment.setAmount(((int) value) / 100); //In Rs
                        break;
                    case C.RAZOR_PAY_CURRENCY:
                        payment.setCurrency((String) value);
                        break;
                    case C.RAZOR_PAY_STATUS:
                        payment.setStatus((String) value);
                        break;
                    case C.RAZOR_PAY_ORDER_ID:
                        payment.setOrderId((String) value);
                        break;
                    case C.RAZOR_PAY_INVOICE_ID:
                        payment.setInvoiceId((String) value);
                        break;
                    case C.RAZOR_PAY_INTERNATIONAL:
                        payment.setInternational((boolean) value);
                        break;
                    case C.RAZOR_PAY_METHOD:
                        payment.setMethod((String) value);
                        break;
                    case C.RAZOR_PAY_AMOUNT_REFUNDED:
                        payment.setAmountRefunded(((int) value) / 100); //Rs
                        break;
                    case C.RAZOR_PAY_REFUND_STATUS:
                        if (!JSONObject.NULL.equals(value)) {
                            payment.setRefundStatus((String) value);
                        }
                        break;
                    case C.RAZOR_PAY_CAPTURED:
                        payment.setCaptured((boolean) value);
                        break;
                    case C.RAZOR_PAY_DESC:
                        payment.setDescription((String) value);
                        break;
                    case C.RAZOR_PAY_CARD_ID:
                        if (!JSONObject.NULL.equals(value)) {
                            payment.setCardId((String) value);
                        }
                        break;
                    case C.RAZOR_PAY_BANK:
                        if (!JSONObject.NULL.equals(value)) {
                            payment.setBank((String) value);
                        }
                        break;
                    case C.RAZOR_PAY_WALLET:
                        if (!JSONObject.NULL.equals(value)) {
                            payment.setWallet((String) value);
                        }
                        break;
                    case C.RAZOR_PAY_VPA:
                        if (!JSONObject.NULL.equals(value)) {
                            payment.setVpa((String) value);
                        }
                        break;
                    case C.RAZOR_PAY_EMAIL:
                        payment.setEmail((String) value);
                        break;
                    case C.RAZOR_PAY_CONTACT:
                        payment.setContact((String) value);
                        break;
                    case C.RAZOR_PAY_NOTES:
                        if (value != null) {
                            if (value instanceof JSONArray) {
                                JSONArray jsonArray = ((JSONArray) value);
                                if (jsonArray.length() != 0) {
                                    payment.setNotes(jsonArray.join("\\n"));
                                }
                            }
                        }
                        break;
                    case C.RAZOR_PAY_FEE:
                        payment.setFee(((int) value) / 100); //Rs
                        break;
                    case C.RAZOR_PAY_TAX:
                        payment.setTax(((int) value) / 100); //Rs
                        break;
                    case C.RAZOR_PAY_ERROR_CODE:
                        if (!JSONObject.NULL.equals(value)) {
                            payment.setErrorCode((String) value);
                        }
                        break;
                    case C.RAZOR_PAY_ERROR_DESC:
                        if (!JSONObject.NULL.equals(value)) {
                            payment.setErrorDescription((String) value);
                        }
                        break;
                    case C.RAZOR_PAY_CREATED_AT:
                        payment.setCreatedAt(LocalDateTime.ofInstant(Instant.ofEpochSecond((Integer) value), ZoneId.of(TimeZoneList.IST.getZoneId())));
                }
            }
        }
        return payment;
    }

    public OrderAndRefund getRefundEntity(Refund razorRefund) {
        if (razorRefund != null) {
            JSONObject modelJson = razorRefund.toJson();
            return getEntityForOrderOrRefund(modelJson);
        }
        return null;
    }

    public OrderAndRefund getOrderEntity(Order razorOrder) {
        if (razorOrder != null) {
            JSONObject modelJson = razorOrder.toJson();
            return getEntityForOrderOrRefund(modelJson);
        }
        return null;
    }

    //get Order or Refund entity with original Razor pay properties
    public OrderAndRefund getEntityForOrderOrRefund(JSONObject modelJson) {
        OrderAndRefund orderAndRefund = new OrderAndRefund();
        if (modelJson != null) {
            for (Object key : modelJson.keySet()) {
                String propKey = (String) key;
                Object value = modelJson.get(propKey);
                switch (propKey) {
                    case C.RAZOR_PAY_ID:
                        orderAndRefund.setId((String) value);
                        break;
                    case C.RAZOR_PAY_ENTITY:
                        orderAndRefund.setEntity((String) value);
                        break;
                    case C.RAZOR_PAY_AMOUNT:
                        orderAndRefund.setAmount(((int) value) / 100); //In Rs
                        break;
                    case C.RAZOR_PAY_CURRENCY:
                        orderAndRefund.setCurrency((String) value);
                        break;
                    case C.RAZOR_PAY_PAYMENT_ID:
                        orderAndRefund.setPaymentId((String) value);
                        break;
                    case C.RAZOR_PAY_AMOUNT_PAID:
                        orderAndRefund.setAmountPaid(((int) value) / 100); //In Rs
                        break;
                    case C.RAZOR_PAY_AMOUNT_DUE:
                        orderAndRefund.setAmountDue(((int) value) / 100); //In Rs
                        break;
                    case C.RAZOR_PAY_OFFER_ID:
                        if (!JSONObject.NULL.equals(value)) {
                            orderAndRefund.setOfferId((String) value);
                        }
                        break;
                    case C.RAZOR_PAY_STATUS:
                        orderAndRefund.setStatus((String) value);
                        break;
                    case C.RAZOR_PAY_ATTEMPTS:
                        orderAndRefund.setAttempts((int) value);
                        break;
                    case C.RAZOR_PAY_NOTES:
                        if (value != null) {
                            if (value instanceof JSONArray) {
                                JSONArray jsonArray = ((JSONArray) value);
                                if (jsonArray.length() != 0) {
                                    orderAndRefund.setNotes(jsonArray.join("\\n"));
                                }
                            }
                        }
                        break;
                    case C.RAZOR_PAY_RECEIPT:
                        if (!JSONObject.NULL.equals(value)) {
                            orderAndRefund.setReceipt((String) value);
                        }
                        break;
                    case C.RAZOR_PAY_CREATED_AT:
                        orderAndRefund.setCreatedAt(LocalDateTime.ofInstant(Instant.ofEpochSecond((Integer) value), ZoneId.of(TimeZoneList.IST.getZoneId())));
                }
            }
        }
        return orderAndRefund;
    }

    public boolean isBookingExist(String bookingId) {
        if (!StringUtils.isEmpty(bookingId)) {
            try {
                List<ServiceSlotBooking> serviceSlotBookingList = slotBookingRepository.findByBookingId(bookingId);
                if (serviceSlotBookingList != null && serviceSlotBookingList.size() > 0)
                    return true;
                else
                    return false;
            } catch (Exception e) {
                logger.debug("Exception during checking of booking existence : {}", e);
            }
        }
        return false;
    }
}
