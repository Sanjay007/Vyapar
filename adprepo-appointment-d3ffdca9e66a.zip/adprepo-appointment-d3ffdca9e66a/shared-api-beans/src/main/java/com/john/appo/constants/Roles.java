/**
 *
 */
package com.john.appo.constants;

/**
 * @author nakesh
 */
public interface Roles {
    String ROLE_USER = "ROLE_USER";
    String ROLE_USER_UPDATE = "ROLE_USER_UPDATE";
    String ROLE_ADMIN_READ = "ROLE_ADMIN_READ";
    String ROLE_ADMIN_WRITE = "ROLE_ADMIN_WRITE";
    String ROLE_ADMIN_UPDATE = "ROLE_ADMIN_UPDATE";
    String ROLE_SUPER_ADMIN = "ROLE_SUPER_ADMIN";
    String ROLE_NONE = "ROLE_NONE";
    String ROLE_ADMIN = "ROLE_ADMIN";
}
