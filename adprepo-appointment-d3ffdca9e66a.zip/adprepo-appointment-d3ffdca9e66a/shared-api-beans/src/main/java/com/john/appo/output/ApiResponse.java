package com.john.appo.output;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.john.appo.enums.ErrorCode;
import com.john.appo.utils.MessageFormatter;

/**
 * @author nakesh
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ApiResponse {

    private String errorId;
    private Integer errorCode;
    private String errorMsgEn;
    private boolean success = true;
    private Object data;

    public ApiResponse() {
    }

    public ApiResponse(Object data) {
        this.data = data;
    }

    public ApiResponse(String errorId, Integer errorCode, String errorMsgAr, String errorMsgEn) {
        super();
        this.errorId = errorId;
        this.errorMsgEn = errorMsgEn;
        if (errorCode != null) {
            this.success = false;
        }
    }

    public ApiResponse(Enum<?> code) {
        this(code, new String[]{});
    }

    public ApiResponse(Enum<?> code, String param) {
        this(code, new String[]{param});
    }

    public ApiResponse(Enum<?> code, String... params) {
        if (code instanceof ErrorCode) {
            fillErrorFields((ErrorCode) code, params);
        }
    }

    public String getErrorId() {
        return errorId;
    }

    public void setErrorId(String errorId) {
        this.errorId = errorId;
    }

    public Integer getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(Integer errorCode) {
        this.errorCode = errorCode;
    }

    public String getErrorMsgEn() {
        return errorMsgEn;
    }

    public void setErrorMsgEn(String errorMsgEn) {
        this.errorMsgEn = errorMsgEn;
    }

    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public Object getData() {
        return data;
    }

    public void setData(Object data) {
        this.data = data;
    }

    private void fillErrorFields(ErrorCode errorCode, String... params) {
        setSuccess(false);
        this.errorId = errorCode.name();
        this.errorCode = errorCode.getErrorCode();
        MessageFormatter messageObj = new MessageFormatter();
        this.errorMsgEn = messageObj.getMessage(errorCode.getErrorMessEn(), params);
    }
}
