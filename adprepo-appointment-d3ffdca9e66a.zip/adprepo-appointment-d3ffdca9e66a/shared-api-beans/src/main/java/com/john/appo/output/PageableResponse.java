/**
 *
 */
package com.john.appo.output;

import org.springframework.data.domain.Page;

import java.util.List;

/**
 * @author nakesh
 */
public class PageableResponse<T> {

    private List<T> content;
    private int totalPages;
    private int currentPage;
    private int noOfElements;
    private long totalNoOfElements;

    public PageableResponse() {
    }

    public <P> PageableResponse(List<T> content, Page<P> page) {
        this.content = content;
        this.totalPages = page.getTotalPages();
        this.currentPage = page.getNumber();
        this.noOfElements = page.getNumberOfElements();
        this.totalNoOfElements = page.getTotalElements();
    }

    public PageableResponse(List<T> content, int totalPages, int currentPage, int noOfElements,
                            long totalNoOfElements) {
        super();
        this.content = content;
        this.totalPages = totalPages;
        this.currentPage = currentPage;
        this.noOfElements = noOfElements;
        this.totalNoOfElements = totalNoOfElements;
    }

    public List<T> getContent() {
        return content;
    }

    public void setContent(List<T> content) {
        this.content = content;
    }

    public int getTotalPages() {
        return totalPages;
    }

    public void setTotalPages(int totalPages) {
        this.totalPages = totalPages;
    }

    public int getCurrentPage() {
        return currentPage;
    }

    public void setCurrentPage(int currentPage) {
        this.currentPage = currentPage;
    }

    public int getNoOfElements() {
        return noOfElements;
    }

    public void setNoOfElements(int noOfElements) {
        this.noOfElements = noOfElements;
    }

    public long getTotalNoOfElements() {
        return totalNoOfElements;
    }

    public void setTotalNoOfElements(long totalNoOfElements) {
        this.totalNoOfElements = totalNoOfElements;
    }
}

