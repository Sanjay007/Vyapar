/**
 *
 */
package com.john.appo.enums;

/**
 * @author nakesh
 */
public enum Emotion {
    HAPPY,
    SAD,
    NEUTRAL
}
