package com.john.appo.input;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.john.appo.enums.Status;

import java.util.List;

/**
 * @author Krishna
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class SlotInfoInput {

    private Long shopServiceId;//for input and output

    private String serviceName; //for output

    private int slot; //for input and output

    private List<Integer> suggestedSlots;

    private int duration; //for output

    private Status status; //for output

    private int seat = 1; //for input

    public Long getShopServiceId() {
        return shopServiceId;
    }

    public void setShopServiceId(Long shopServiceId) {
        this.shopServiceId = shopServiceId;
    }

    public String getServiceName() {
        return serviceName;
    }

    public void setServiceName(String serviceName) {
        this.serviceName = serviceName;
    }

    public int getSlot() {
        return slot;
    }

    public void setSlot(int slot) {
        this.slot = slot;
    }

    public List<Integer> getSuggestedSlots() {
        return suggestedSlots;
    }

    public void setSuggestedSlots(List<Integer> suggestedSlots) {
        this.suggestedSlots = suggestedSlots;
    }

    public int getDuration() {
        return duration;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }

    public int getSeat() {
        return seat;
    }

    public void setSeat(int seat) {
        this.seat = seat;
    }
}
