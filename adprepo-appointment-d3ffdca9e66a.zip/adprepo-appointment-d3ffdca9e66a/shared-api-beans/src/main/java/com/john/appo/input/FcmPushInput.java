/**
 *
 */
package com.john.appo.input;

import com.john.appo.constants.C;

import java.util.List;

/**
 * @author nakesh
 */
public class FcmPushInput {
    private String to;
    private FcmNotificationInput notification;
    private List<FcmDataInput> dataList;
    private String priority = C.HIGH;

    public String getPriority() {
        return priority;
    }

    public void setPriority(String priority) {
        this.priority = priority;
    }

    public String getTo() {
        return to;
    }

    public void setTo(String to) {
        this.to = to;
    }

    public FcmNotificationInput getNotification() {
        return notification;
    }

    public void setNotification(FcmNotificationInput notification) {
        this.notification = notification;
    }

    public List<FcmDataInput> getDataList() {
        return dataList;
    }

    public void setDataList(List<FcmDataInput> dataList) {
        this.dataList = dataList;
    }
}

