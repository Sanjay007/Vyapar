/**
 *
 */
package com.john.appo.enums;

/**
 * @author nakesh
 */
public enum Operation {
    U_DP("user_display_pic"),
    S_DP("shop_display_pic"),
    SS_DP("shopservice_display_pic"),
    SO_SS_FEEDBACK("shopowner_shopservice_feedback"),
    U_SS_FEEDBACK("user_shopservice_feedback"),
    APP_FEEDBACK("app_feedback");

    private String fullName;

    Operation(String fullName) {
        this.fullName = fullName;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }
}
