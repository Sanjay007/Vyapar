/**
 *
 */
package com.john.appo.input;

import com.john.appo.enums.Operation;
import org.springframework.web.multipart.MultipartFile;

/**
 * @author nakesh
 */
public class MediaInput {
    private Long userId;
    private Long shopId;
    private Long shopServiceId;
    private Operation operation;
    private String type;
    private String contentType;
    private MultipartFile[] multipartFiles;
    private boolean active;

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public Long getShopId() {
        return shopId;
    }

    public void setShopId(Long shopId) {
        this.shopId = shopId;
    }

    public Long getShopServiceId() {
        return shopServiceId;
    }

    public void setShopServiceId(Long shopServiceId) {
        this.shopServiceId = shopServiceId;
    }

    public Operation getOperation() {
        return operation;
    }

    public void setOperation(Operation operation) {
        this.operation = operation;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getContentType() {
        return contentType;
    }

    public void setContentType(String contentType) {
        this.contentType = contentType;
    }

    public MultipartFile[] getMultipartFiles() {
        return multipartFiles;
    }

    public void setMultipartFiles(MultipartFile[] multipartFiles) {
        this.multipartFiles = multipartFiles;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }
}
