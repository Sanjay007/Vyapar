/**
 *
 */
package com.john.appo.output;

import java.util.List;

/**
 * @author nakesh
 */
public class ServiceModel {
    private Long id;
    private String name;
    private Double actPrice;
    private Double disFlat; // discountFlat
    private Integer disPercent;// discountPercentage
    private String description;
    private String servingPersonName;
    private Float rating;
    private List<AvailableSlot> avlSlots;
    private List<String> files;
    private int avgTime;

    public List<String> getFiles() {
        return files;
    }

    public void setFiles(List<String> files) {
        this.files = files;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Double getDisFlat() {
        return disFlat;
    }

    public void setDisFlat(Double disFlat) {
        this.disFlat = disFlat;
    }

    public Integer getDisPercent() {
        return disPercent;
    }

    public void setDisPercent(Integer disPercent) {
        this.disPercent = disPercent;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Double getActPrice() {
        return actPrice;
    }

    public void setActPrice(Double actPrice) {
        this.actPrice = actPrice;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getServingPersonName() {
        return servingPersonName;
    }

    public void setServingPersonName(String servingPersonName) {
        this.servingPersonName = servingPersonName;
    }

    public Float getRating() {
        return rating;
    }

    public void setRating(Float rating) {
        this.rating = rating;
    }

    public List<AvailableSlot> getAvlSlots() {
        return avlSlots;
    }

    public void setAvlSlots(List<AvailableSlot> avlSlots) {
        this.avlSlots = avlSlots;
    }

    public int getAvgTime() {
        return avgTime;
    }

    public void setAvgTime(int avgTime) {
        this.avgTime = avgTime;
    }
}
