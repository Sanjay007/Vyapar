/**
 *
 */
package com.john.appo.constants;

/**
 * @author nakesh
 */
public interface Entity {
    String E_USERS = "users";
    String E_ADMIN = "admin";
    String E_CATEGORY = "category";
    String E_SUB_CATEGORY = "sub_category";
    String E_SHOP = "shop";
    String E_SHOP_SERVICES = "shop_services";
    String E_BOOKING = "booking";
    String E_MEDIA = "media";
    String E_DEVICE_INFO = "device_info";
    String E_SERVICE_SLOT_BOOKING = "service_slot_booking";
    String E_FEEDBACK = "feedback";
    String E_USER_ADDRESS = "user_address";
    String E_PAYMENT = "payment";
    String E_ORDER_REFUND = "order_refund";
    String E_BLOCKED_SLOT = "blocked_slot";
}
