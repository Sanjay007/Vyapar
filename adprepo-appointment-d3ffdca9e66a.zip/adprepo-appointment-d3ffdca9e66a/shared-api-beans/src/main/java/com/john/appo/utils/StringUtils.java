package com.john.appo.utils;

import java.util.regex.Pattern;

/**
 * @author nakesh
 */
public class StringUtils extends org.springframework.util.StringUtils {

    private static final Pattern numericPattern = Pattern.compile("\\d+");

    public static boolean isNumeric(String s) {
        if (!StringUtils.hasText(s))
            return false;
        if (s.contains(".") && s.indexOf(".") != s.lastIndexOf(".")) // 99.99.99 is not a number
            return false;
        if (s.startsWith("-") || s.startsWith("+")) {
            s = s.substring(1);
        }
        String digits = s.replaceAll("\\.", "");
        return numericPattern.matcher(digits).matches();
    }

    public static boolean isInteger(String s) {
        try {
            Integer.parseInt(s);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public static boolean isZero(String s) {
        try {
            return Integer.parseInt(s) == 0;
        } catch (Exception e) {
            return false;
        }
    }

    public static boolean isLengthBetween(String s, int len1, int len2) {
        return s.length() >= len1 && s.length() <= len2;
    }

    public static boolean isEmpty(String arg) {
        return (arg == null || arg.length() == 0);
    }
}

