package com.john.appo.output;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.john.appo.enums.PaymentMode;
import com.john.appo.enums.Status;

import java.time.LocalDateTime;


/**
 * @author Krishna
 */
public class BookingOutput extends ApiOutput<Long> {

    private String bookingId;
    private Long userId;
    private String userName; //additional
    private Long shopId;
    private String shopName; //additional
    private String shopAddress; //additional
    private Long catId;
    private String catName; //additional
    private Long subCatId;
    private String subCatName; //additional
    private Long shopServiceId;
    private String shopServiceName; //additional
    private String servingPersonName; //additional
    private Long addressId;
    private int slot;
    private int duration;
    private LocalDateTime serviceDate;
    private PaymentMode paymentMode;
    private String paymentId;
    private Double actualPrice;
    private Double paidAmount;
    private Double disFlat;
    private Integer disPercent;
    private Long promoId;
    private String promoCode;
    private Status status;
    private Float lat;
    private Float lon;
    private String description;

    public String getBookingId() {
        return bookingId;
    }

    public void setBookingId(String bookingId) {
        this.bookingId = bookingId;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public Long getShopId() {
        return shopId;
    }

    public void setShopId(Long shopId) {
        this.shopId = shopId;
    }

    public String getShopName() {
        return shopName;
    }

    public void setShopName(String shopName) {
        this.shopName = shopName;
    }

    public String getShopAddress() {
        return shopAddress;
    }

    public void setShopAddress(String shopAddress) {
        this.shopAddress = shopAddress;
    }

    public Long getCatId() {
        return catId;
    }

    public void setCatId(Long catId) {
        this.catId = catId;
    }

    public String getCatName() {
        return catName;
    }

    public void setCatName(String catName) {
        this.catName = catName;
    }

    public Long getSubCatId() {
        return subCatId;
    }

    public void setSubCatId(Long subCatId) {
        this.subCatId = subCatId;
    }

    public String getSubCatName() {
        return subCatName;
    }

    public void setSubCatName(String subCatName) {
        this.subCatName = subCatName;
    }

    public Long getShopServiceId() {
        return shopServiceId;
    }

    public void setShopServiceId(Long shopServiceId) {
        this.shopServiceId = shopServiceId;
    }

    public String getShopServiceName() {
        return shopServiceName;
    }

    public void setShopServiceName(String shopServiceName) {
        this.shopServiceName = shopServiceName;
    }

    public String getServingPersonName() {
        return servingPersonName;
    }

    public void setServingPersonName(String servingPersonName) {
        this.servingPersonName = servingPersonName;
    }

    public Long getAddressId() {
        return addressId;
    }

    public void setAddressId(Long addressId) {
        this.addressId = addressId;
    }

    public int getSlot() {
        return slot;
    }

    public void setSlot(int slot) {
        this.slot = slot;
    }

    public int getDuration() {
        return duration;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd-MM-yyyy")
    public LocalDateTime getServiceDate() {
        return serviceDate;
    }

    public void setServiceDate(LocalDateTime serviceDate) {
        this.serviceDate = serviceDate;
    }

    public PaymentMode getPaymentMode() {
        return paymentMode;
    }

    public void setPaymentMode(PaymentMode paymentMode) {
        this.paymentMode = paymentMode;
    }

    public String getPaymentId() {
        return paymentId;
    }

    public void setPaymentId(String paymentId) {
        this.paymentId = paymentId;
    }

    public Double getActualPrice() {
        return actualPrice;
    }

    public void setActualPrice(Double actualPrice) {
        this.actualPrice = actualPrice;
    }

    public Double getPaidAmount() {
        return paidAmount;
    }

    public void setPaidAmount(Double paidAmount) {
        this.paidAmount = paidAmount;
    }

    public Double getDisFlat() {
        return disFlat;
    }

    public void setDisFlat(Double disFlat) {
        this.disFlat = disFlat;
    }

    public Integer getDisPercent() {
        return disPercent;
    }

    public void setDisPercent(Integer disPercent) {
        this.disPercent = disPercent;
    }

    public Long getPromoId() {
        return promoId;
    }

    public void setPromoId(Long promoId) {
        this.promoId = promoId;
    }

    public String getPromoCode() {
        return promoCode;
    }

    public void setPromoCode(String promoCode) {
        this.promoCode = promoCode;
    }

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }

    public Float getLat() {
        return lat;
    }

    public void setLat(Float lat) {
        this.lat = lat;
    }

    public Float getLon() {
        return lon;
    }

    public void setLon(Float lon) {
        this.lon = lon;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
