package com.john.appo.output;

/**
 * @author krishna.kumar
 */
public class PaymentDetailsOutput {
}
