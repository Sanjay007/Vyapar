/**
 *
 */
package com.john.appo.input;

import org.hibernate.validator.constraints.NotBlank;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

/**
 * @author nakesh
 */
public class ShopInput extends ApiInput<Long> {
    @NotNull(message = "ownerId must not be blank!")
    private Long ownerId;   //id from admin table
    @NotBlank(message = "name must not be blank!")
    private String name;
    private Long phone;
    @NotNull(message = "mobile must not be blank!")
    @Min(1000000000L)
    @Max(9999999999L)
    private Long mobile;
    @NotNull(message = "lat must not be blank!")
    private Float lat;
    @NotNull(message = "lon must not be blank!")
    private Float lon;
    @NotBlank(message = "streetName must not be blank!")
    private String streetName;
    @NotBlank(message = "locality must not be blank!")
    private String locality;
    @NotBlank(message = "area must not be blank!")
    private String area;
    @NotBlank(message = "state must not be blank!")
    private String state;
    @NotBlank(message = "city must not be blank!")
    private String city;
    @Min(100000L)
    @Max(999999L)
    private int pinCode;
    @NotBlank(message = "address must not be blank!")
    private String address;
    @NotBlank(message = "workingDays must not be blank!")
    private String workingDays; // comma separated days like : (MON,TUE,WED)
    @Min(1L)
    @Max(1000L)
    private int maxSeat;
    private int startTime; // in minutes (24 hrs time frame)
    private int endTime; // in minutes (24 hrs time frame)
    private int breakTime; // in minutes (24 hrs time frame)
    @Max(3L)
    private int breakDuration; // in minutes (24 hrs time frame)
    private Float rating;
    private String description;
    private boolean active;
    private boolean approved;

    public Long getOwnerId() {
        return ownerId;
    }

    public void setOwnerId(Long ownerId) {
        this.ownerId = ownerId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Long getPhone() {
        return phone;
    }

    public void setPhone(Long phone) {
        this.phone = phone;
    }

    public Long getMobile() {
        return mobile;
    }

    public void setMobile(Long mobile) {
        this.mobile = mobile;
    }

    public Float getLat() {
        return lat;
    }

    public void setLat(Float lat) {
        this.lat = lat;
    }

    public Float getLon() {
        return lon;
    }

    public void setLon(Float lon) {
        this.lon = lon;
    }

    public String getStreetName() {
        return streetName;
    }

    public void setStreetName(String streetName) {
        this.streetName = streetName;
    }

    public String getLocality() {
        return locality;
    }

    public void setLocality(String locality) {
        this.locality = locality;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public int getPinCode() {
        return pinCode;
    }

    public void setPinCode(int pinCode) {
        this.pinCode = pinCode;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getWorkingDays() {
        return workingDays;
    }

    public void setWorkingDays(String workingDays) {
        this.workingDays = workingDays;
    }

    public int getMaxSeat() {
        return maxSeat;
    }

    public void setMaxSeat(int maxSeat) {
        this.maxSeat = maxSeat;
    }

    public int getStartTime() {
        return startTime;
    }

    public void setStartTime(int startTime) {
        this.startTime = startTime;
    }

    public int getEndTime() {
        return endTime;
    }

    public void setEndTime(int endTime) {
        this.endTime = endTime;
    }

    public int getBreakTime() {
        return breakTime;
    }

    public void setBreakTime(int breakTime) {
        this.breakTime = breakTime;
    }

    public int getBreakDuration() {
        return breakDuration;
    }

    public void setBreakDuration(int breakDuration) {
        this.breakDuration = breakDuration;
    }

    public Float getRating() {
        return rating;
    }

    public void setRating(Float rating) {
        this.rating = rating;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public boolean isApproved() {
        return approved;
    }

    public void setApproved(boolean approved) {
        this.approved = approved;
    }
}
