/**
 *
 */
package com.john.appo.output;

import com.fasterxml.jackson.annotation.JsonInclude;

import java.util.List;

/**
 * @author nakesh
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CategorySubCategoryOutput {
    private Long id;
    private String catName;
    private List<SubCategoryModel> subCategories;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCatName() {
        return catName;
    }

    public void setCatName(String catName) {
        this.catName = catName;
    }

    public List<SubCategoryModel> getSubCategories() {
        return subCategories;
    }

    public void setSubCategories(List<SubCategoryModel> subCategories) {
        this.subCategories = subCategories;
    }
}
