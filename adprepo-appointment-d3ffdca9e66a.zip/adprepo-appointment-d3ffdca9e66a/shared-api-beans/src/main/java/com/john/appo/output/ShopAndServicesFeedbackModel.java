/**
 *
 */
package com.john.appo.output;

import org.springframework.data.domain.Page;

import java.util.List;

/**
 * @author nakesh
 */
public class ShopAndServicesFeedbackModel extends PageableResponse {

    private Long shopId;
    private Long shopServiceId;
    private int totalFeedback;
    private float averageFeedback;
    private int oneStar;
    private int twoStar;
    private int threeStar;
    private int fourStar;
    private int fiveStar;

    public ShopAndServicesFeedbackModel() {
        super();
    }

    public ShopAndServicesFeedbackModel(List<?> content, Page<?> page, Long shopServiceId, Long shopId) {
        super(content, page);
        this.shopServiceId = shopServiceId;
        this.shopId = shopId;
    }

    public float getAverageFeedback() {
        return averageFeedback;
    }

    public void setAverageFeedback(float averageFeedback) {
        this.averageFeedback = averageFeedback;
    }

    public Long getShopId() {
        return shopId;
    }

    public void setShopId(Long shopId) {
        this.shopId = shopId;
    }

    public Long getShopServiceId() {
        return shopServiceId;
    }

    public void setShopServiceId(Long shopServiceId) {
        this.shopServiceId = shopServiceId;
    }

    public int getTotalFeedback() {
        return totalFeedback;
    }

    public void setTotalFeedback(int totalFeedback) {
        this.totalFeedback = totalFeedback;
    }

    public int getOneStar() {
        return oneStar;
    }

    public void setOneStar(int oneStar) {
        this.oneStar = oneStar;
    }

    public int getTwoStar() {
        return twoStar;
    }

    public void setTwoStar(int twoStar) {
        this.twoStar = twoStar;
    }

    public int getThreeStar() {
        return threeStar;
    }

    public void setThreeStar(int threeStar) {
        this.threeStar = threeStar;
    }

    public int getFourStar() {
        return fourStar;
    }

    public void setFourStar(int fourStar) {
        this.fourStar = fourStar;
    }

    public int getFiveStar() {
        return fiveStar;
    }

    public void setFiveStar(int fiveStar) {
        this.fiveStar = fiveStar;
    }
}
