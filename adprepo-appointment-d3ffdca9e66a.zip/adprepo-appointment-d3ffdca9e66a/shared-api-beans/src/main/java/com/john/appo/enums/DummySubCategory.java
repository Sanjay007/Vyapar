/**
 *
 */
package com.john.appo.enums;

/**
 * @author nakesh
 */
public enum DummySubCategory {
    SC_1("Beauty Parlours For Hair Cutting"),
    SC_2("Beauty Parlours For Skin Lightning"),
    SC_3("Ear Piercing"),
    SC_4("Beauty Parlours For Waxing"),
    SC_5("Beauty Parlours For Skin Facial");

    private String name;

    DummySubCategory(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
