package com.john.appo.constants;

/**
 * @author nakesh
 */
public class C implements Constants, RequestMappings, Entity, Roles, DateTimePatternFormatter, RazorPayConstants {
}
