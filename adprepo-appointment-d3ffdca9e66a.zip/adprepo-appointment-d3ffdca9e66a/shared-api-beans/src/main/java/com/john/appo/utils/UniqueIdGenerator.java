package com.john.appo.utils;

import com.john.appo.constants.C;
import com.john.appo.enums.TimeZoneList;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * @author nakesh
 */
public class UniqueIdGenerator {

    private final static String TIMESTAMP_FORMAT = "yyMMddHHmmssSSS";
    private final static String DATE_FORMAT = "yyMMdd";
    private static final AtomicInteger sequenceUpto999 = new AtomicInteger(0);

    // id for current date
    public static synchronized String getId() {
        return getIdForDate(LocalDateTime.now(ZoneId.of(TimeZoneList.IST.getZoneId())));
    }

    // id date prefix in format(yyMMdd)for before date from current date
    public static String getIdDatePrefixBeforeDays(String dayCount) {
        return getPKDatePrefixFromDate(getDateBeforeAfterCurrentDate(dayCount), DATE_FORMAT);    // -days (-2) indicates 2 days before current date
    }

    // generate 25 digit unique id(160302123108592FP10001635) which is combination of year(2)+month(2)+day(2)+hour(2)+min(2)+sec(2)+mills(3)+fpIdentifier(3)+threadId(4)+randomNo(3)
    private static String getIdForDate(LocalDateTime dateTime) {
        StringBuilder sb = new StringBuilder();
        sb.append(getPKDatePrefixFromDate(dateTime, TIMESTAMP_FORMAT))
                .append(C.APPO_CONSTANT)
                .append(String.format("%04d", Math.abs(Thread.currentThread().getId() % 10000)))
                .append(getNextThreeDigitSequence());
        return sb.toString();
    }

    // date : before after current date
    public static LocalDateTime getDateBeforeAfterCurrentDate(String dayCount) {
        LocalDateTime dateTime = LocalDateTime.now(ZoneId.of(TimeZoneList.IST.getZoneId()));
        dateTime.minusDays(Long.parseLong(dayCount));
        return dateTime;
    }

    // Convert date in string to given format
    private static String getPKDatePrefixFromDate(LocalDateTime dateTime, String format) {
        return dateTime.format(DateTimeFormatter.ofPattern(format));
    }

    public static String getNextThreeDigitSequence() {
        if (sequenceUpto999.get() == 999)
            sequenceUpto999.set(0);
        return String.format("%03d", sequenceUpto999.incrementAndGet());
    }

    public static String getPassword() {
        String date = getPKDatePrefixFromDate(LocalDateTime.now(ZoneId.of(TimeZoneList.IST.getZoneId())), TIMESTAMP_FORMAT).substring(12, 15);
        StringBuilder sb = new StringBuilder();
        sb.append(date)
                .append(getNextThreeDigitSequence());
        return sb.toString();
    }

    public static String getOtp() {
        String date = getPKDatePrefixFromDate(LocalDateTime.now(ZoneId.of(TimeZoneList.IST.getZoneId())), TIMESTAMP_FORMAT).substring(12, 15);
        StringBuilder sb = new StringBuilder();
        sb.append(date).append(getNextThreeDigitSequence());
        return sb.toString();
    }
}
