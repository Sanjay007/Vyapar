package com.john.appo.constants;

/**
 * @author nakesh
 */
public interface RequestMappings {
    String CREATE = "/create";
    String UPDATE = "/update";
    String DELETE = "/delete";
    String LIST = "/list";
    String ALL = "/all";

    String SEEDDATA = "/seeddata";
    String LOGIN = "/login";
    String USER = "/user";
    String ADMIN = "/admin";
    String CATEGORY = "/category";
    String SUB_CAT = "/subcat";
    String SHOP = "/shop";
    String SHOP_SERVICE = "/shopservice";
    String BOOKING = "/booking";
    String BOOK = "/book";
    String VALIDATE_AND_LOCK_AVL_SLOTS = "/validateandlockavlslots";
    String LISTING = "/listing";
    String MEDIA = "/media";
    String FILE = "/file";
    String FEEDBACK = "/feedback";
    String LOGOUT = "/logout";
    String TRANSACTION = "/transaction";
    String BLOCK_SLOT = "/blockslot";
    String BLOCK_SLOTS = "/blockslots";
    String SAVE = "/save";
    String GET = "/get";
    String REFUND = "/refund";

    String GREETING = "/greeting";
    String SHOPS_FOR_SUB_CAT = "/shopsforsubcat";
    String SERVICES_FOR_SHOP_ID = "/servicesforshopid";
    String SLOTS_FOR_SERVICES = "/slotsforservice";
    String SLOTS_AVAILABILITY_CNF_STATUS = "/slotsavlcnfstatus";
    String BETWEEN = "/btw";
    String BY_STATUS = "/bystatus";
    String BY_CAT_ID = "/bycatid";
    String BY_ID = "/byid";
    String BY_SHOP_ID = "/byshopid";
    String BY_SHOP_SERVICE_ID = "/byshopserviceid";
    String SEARCH = "/search";
    String UPDATE_SLOTS_BOOKING_STATUS = "/updateslotsstatus";
    String BLOCK_SLOTS_RESV = "/blockslotsresv";
    String UNBLOCK_SLOTS_RESV = "/unblockslotsresv";
    String TOGGLE = "/toggle";
    String MARKERS = "/marker";
    String PAGE = "/page";
    String UPLOAD = "/upload";
    String DOWNLOAD = "/download";
    String RESET = "/reset";
    String FORGOT = "/forgot";
    String PROFILE_PIC = "/profilepic";
    String SHOP_PIC = "/shoppic";
    String GET_FB_FOR_SERVICE = "/getfbforservice";

    String SWAGGER_UI = "/swagger-ui.html";
    String SWAGGER_RESOURCES = "/swagger-resources";
    String SWAGGER_UI_CONFIGURATION = "/swagger-resources/configuration/ui";
    String SWAGGER_API_DOC2 = "/api/v2/api-docs";
    String SWAGGER_API_DOC = "/v2/api-docs";
    String WEBJARS = "/webjars/**";
    String SWAGGER_LOGIN = "/swagger/login/**";
}
