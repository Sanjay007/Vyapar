/**
 *
 */
package com.john.appo.enums;

/**
 * @author nakesh
 */
public enum Sex {
    M,
    F;
}
