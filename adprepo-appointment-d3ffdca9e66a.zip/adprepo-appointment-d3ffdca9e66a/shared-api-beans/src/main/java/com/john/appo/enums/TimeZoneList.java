package com.john.appo.enums;

/**
 * @author Krishna
 */
public enum TimeZoneList {
    UTC("UTC", "", "UTC"),
    IST("IST", "", "Asia/Calcutta"),
    GMT("GMT", "BST", "Europe/London"),
    CET("CET", "CEST", "Europe/Amsterdam");

    private String code;
    private String dstCode;
    private String zoneId;

    TimeZoneList(String code, String dstCode, String zoneId) {
        this.code = code;
        this.dstCode = dstCode;
        this.zoneId = zoneId;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getZoneId() {
        return zoneId;
    }

    public void setZoneId(String zoneId) {
        this.zoneId = zoneId;
    }

    public String getDstCode() {
        return dstCode;
    }

    public void setDstCode(String dstCode) {
        this.dstCode = dstCode;
    }
}
