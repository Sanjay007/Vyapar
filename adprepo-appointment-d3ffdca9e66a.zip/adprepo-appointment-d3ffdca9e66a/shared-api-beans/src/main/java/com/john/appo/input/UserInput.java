/**
 *
 */
package com.john.appo.input;


import com.john.appo.enums.Device;
import com.john.appo.enums.Sex;
import com.john.appo.enums.SocialAccount;
import com.john.appo.enums.UserType;
import org.hibernate.validator.constraints.NotBlank;

/**
 * @author nakesh
 */
public class UserInput {
    private Long id;
    @NotBlank(message = "name must not be blank!")
    private String name;
    @NotBlank(message = "email must not be blank!")
    private String email;
    @NotBlank(message = "password must not be blank!")
    private String password;
    private String confirmPassword;
    @NotBlank(message = "mobile must not be blank!")
    private String mobile;
    private UserType userType;
    private String locality;
    private String area;
    private String streetName;
    private String pinCode;
    private Sex sex;
    private String proImage;
    private Float lat;
    private Float lon;
    private SocialAccount socialAccountType;
    private String socialId;
    private Device device;

    public Device getDevice() {
        return device;
    }

    public void setDevice(Device device) {
        this.device = device;
    }

    public String getConfirmPassword() {
        return confirmPassword;
    }

    public void setConfirmPassword(String confirmPassword) {
        this.confirmPassword = confirmPassword;
    }

    public SocialAccount getSocialAccountType() {
        return socialAccountType;
    }

    public void setSocialAccountType(SocialAccount socialAccountType) {
        this.socialAccountType = socialAccountType;
    }

    public String getSocialId() {
        return socialId;
    }

    public void setSocialId(String socialId) {
        this.socialId = socialId;
    }

    public Float getLat() {
        return lat;
    }

    public void setLat(Float lat) {
        this.lat = lat;
    }

    public Float getLon() {
        return lon;
    }

    public void setLon(Float lon) {
        this.lon = lon;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public UserType getUserType() {
        return userType;
    }

    public void setUserType(UserType userType) {
        this.userType = userType;
    }

    public Sex getSex() {
        return sex;
    }

    public void setSex(Sex sex) {
        this.sex = sex;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getLocality() {
        return locality;
    }

    public void setLocality(String locality) {
        this.locality = locality;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public String getStreetName() {
        return streetName;
    }

    public void setStreetName(String streetName) {
        this.streetName = streetName;
    }

    public String getPinCode() {
        return pinCode;
    }

    public void setPinCode(String pinCode) {
        this.pinCode = pinCode;
    }

    public String getProImage() {
        return proImage;
    }

    public void setProImage(String proImage) {
        this.proImage = proImage;
    }
}
