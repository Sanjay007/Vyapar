/**
 *
 */
package com.john.appo.enums;

/**
 * @author nakesh
 */
public enum DummyShop {
    SHOP_1(1, "Bodycraft Spa And Salon", "9053525241", "12.9421", "77.5854", 1l, 1f, "MON,TUE,WED,THU,FRI", 4, 540, 1020, 840, 60, 560061, "Jayanagar", "10/1, Mariyappa Road, After Parikrama School, Ashoka Pillar, 1st Block, Jayanagar, Bengaluru, Karnataka 560011, India"),
    SHOP_2(2, "Naturals Unisex Salon", "9053525241", "12.8922", "77.5822", 1l, 2f, "MON,TUE,WED,THU,FRI", 4, 540, 1020, 840, 60, 560062, "j.p. nagar", "JP Nagar 7th Phase, Bangalore, Karnataka, India"),
    SHOP_3(3, "NashJack Salon", "9053525241", "12.9421", "77.5863", 1l, 4f, "MON,TUE,WED,THU,FRI", 4, 540, 1020, 840, 60, 560063, "Ganganagar, RT Nagar", "#45, Okaly Nilaya, 2nd Main Ganganagar Layout, Ganganagar, RT Nagar, Bengaluru, Karnataka 560032, India"),
    SHOP_4(4, "Classic Touch Beauty Parlour Agarwal", "9053525241", "12.8984", "77.6179", 2l, 4f, "MON,TUE,WED,THU,FRI", 4, 540, 1020, 840, 60, 560068, "Bommanahalli", "Begur Road, Bommanahalli, Bengaluru, Karnataka 560068, India"),
    SHOP_5(5, "A ONE FAMILY SALON", "9053525241", "12.8943", "77.6290", 2l, 4f, "MON,TUE,WED,THU,FRI", 4, 540, 1020, 840, 60, 560068, "Hongasandra", "#1599 Devarachikkanahalli, Begur Cross near Shri Rama Temple, Bengaluru, Karnataka 560076, India"),
    SHOP_6(6, "YLG SALON", "9053525241", "12.9081", "77.6476", 3l, 4f, "MON,TUE,WED,THU,FRI", 4, 540, 1020, 840, 60, 560068, "HSR Layout", "#434,27th Main road, Above Adidas show room, HSR layout sec 1, Bengaluru, Karnataka 560034, India"),
    SHOP_7(7, "Akshara Beauty Tech", "9053525241", "12.9913", "77.6521", 3l, 4f, "MON,TUE,WED,THU,FRI", 4, 540, 1020, 840, 60, 560064, "Baiyappanahalli", "5,SN BUILDING, 2nd Mn Rd,, Old Baiyyappanahalli, Maruthi Sevanagar, Bengaluru, Karnataka 560033, India"),
    SHOP_8(8, "Mystique Salons", "9053525241", "12.9279", "77.6271", 3l, 4f, "MON,TUE,WED,THU,FRI", 4, 540, 1020, 840, 60, 560065, "Koramangala", "40, 100 Feet Road, 8th Main, 4th Block, Koramangala, Bengaluru, Karnataka 560034, India"),
    SHOP_9(9, "Lakme Salon", "9053525241", "12.9719", "77.5299", 3l, 4f, "MON,TUE,WED,THU,FRI", 4, 540, 1020, 840, 60, 560068, "Vijaynagar", "17th Cross, 21st Main Road, Above Pizza Hut, Near Maruti Temple, MC Layout, Vijayanagar, Bengaluru, Karnataka 560040, India"),
    SHOP_10(10, "DREAMS SALON & SPA", "9053525241", "12.9901", "77.5525", 3l, 4f, "MON,TUE,WED,THU,FRI", 4, 540, 1020, 840, 60, 560068, "Rajajinagar", "No.135/13,, 19th main, 16th Cross,, 1st Block, Rajajinagar, Bengaluru, Karnataka 560021, India"),
    SHOP_11(11, "HOP Salon", "9053525241", "13.0031", "77.5643", 3l, 4f, "MON,TUE,WED,THU,FRI", 4, 540, 1020, 840, 60, 560068, "Malleswaram", "No. 19, 1st Floor, MN Complex, Sampige Road, Malleswaram, Bengaluru, Karnataka 560003, India"),
    SHOP_12(12, "Rejoice Spa and Salon", "9053525241", "12.9226", "77.6174", 3l, 4f, "MON,TUE,WED,THU,FRI", 4, 540, 1020, 840, 60, 560068, "Madiwala", "No.19/20/21/22, K C R Shopping Complex, V.P. Road, Old, Madiwala, BTM Layout, Bengaluru, Karnataka 560068, India"),
    SHOP_13(13, "Jawed Habib", "9053525241", "12.9592", "77.6974", 3l, 4f, "MON,TUE,WED,THU,FRI", 4, 540, 1020, 840, 60, 560068, "Marathahalli", "HAL Airport Rd, Aswath Nagar, Opp. MAX Showroom, Marathahalli, Bengaluru, Karnataka 560037, India"),
    SHOP_14(14, "Bounce Salon & Spa", "9053525241", "12.9698", "77.7499", 3l, 4f, "MON,TUE,WED,THU,FRI", 4, 540, 1020, 840, 60, 560068, "Whitefield", "1st floor, 14/3, Balraj Arcade, Whitefield main road, Near Forum Value Mall,, Opp Brigade Cosmopolis Apartment, Brooke Bond First Cross, Narayanappa Garden, Whitefield, Bengaluru, Karnataka 560066, India"),
    SHOP_15(15, "Reborn Beauty Ladies Salon & Spa", "9053525241", "12.9082", "77.6074", 3l, 4f, "MON,TUE,WED,THU,FRI", 4, 540, 1020, 840, 60, 560068, "BTM", "435, Above Apollo Tyre Park, 7th Main Road, BTM 2nd Stage, Mahadeshwara Nagar, Bengaluru, Karnataka 560076, India"),
    SHOP_16(16, "Enrich Salon", "9053525241", "12.8003", "77.5770", 3l, 5f, "MON,TUE,WED,THU,FRI", 4, 540, 1020, 840, 60, 560068, "Bannerghatta", "Hypercity, Royal Meenakshi Mall,, Bannerghatta Main Road, Bengaluru, Karnataka 560076, India"),
    SHOP_17(17, "Ramya Beauty Parlour", "9053525241", "12.9507", "77.5848", 3l, 5f, "MON,TUE,WED,THU,FRI", 4, 540, 1020, 840, 60, 560068, "Lal bagh", "No. 103, 1st Floor, Above HDFC Bank, R V Road, V.V. Puram,, Near Lalbagh West Gate,, Rashtriya vidyalaya Road,, Bengaluru, Karnataka 560004, India"),
    SHOP_18(18, "Peaches The Styling Salon", "9053525241", "12.9817", "77.6286", 3l, 5f, "MON,TUE,WED,THU,FRI", 4, 540, 1020, 840, 60, 560068, "Ulsoor", "12, Aka, Abas Ali Road, Off Ulsoor Road, Near Manipal Centre, Ulsoor, Ulsoor, Bengaluru, Karnataka 560042, India"),
    SHOP_19(19, "Naturals Salon & Spa", "9053525241", "12.8474", "77.6583", 3l, 5f, "MON,TUE,WED,THU,FRI", 4, 540, 1020, 840, 60, 560068, "Electronic city", "12th Cross Road, Neeladri Nagar, Electronics City Doddathoguru,, Bengaluru, Karnataka 560100, India"),
    SHOP_20(20, "Chen's Hair & Beauty Salon", "9053525241", "13.1005", "77.5940", 3l, 5f, "MON,TUE,WED,THU,FRI", 4, 540, 1020, 840, 60, 560068, "Yelahanka", "Shop No:6 1st Main, 4th Phase, New Town , Yelahanka, Bengaluru, Karnataka 560064, India"),
    SHOP_21(21, "Paloma ladies Beauty Salon", "9053525241", "13.0358", "77.5970", 3l, 5f, "MON,TUE,WED,THU,FRI", 4, 540, 1020, 840, 60, 560068, "Hebbal", "5th Cross Rd, Kanaka Nagar, Hebbal, Bengaluru, Karnataka 560032, India"),
    SHOP_22(22, "Naturals Beauty Parlour", "9053525241", "12.8788", "77.6377", 3l, 5f, "MON,TUE,WED,THU,FRI", 4, 540, 1020, 840, 60, 560068, "Begur", "372, Begur Main Rd, Maruthi Layout, Hongasandra, Bengaluru, Karnataka 560068, India"),
    SHOP_23(23, "GLAMOUR SALON & SPA", "9053525241", "12.9610", "77.6387", 3l, 5f, "MON,TUE,WED,THU,FRI", 4, 540, 1020, 840, 60, 560068, "Domlur", "268, 1st Main Rd, 1st Stage, Domlur, Bengaluru, Karnataka 560071, India"),
    SHOP_24(24, "Leaf Lotus Unisex Salon", "9053525241", "12.8902", "77.6529", 3l, 5f, "MON,TUE,WED,THU,FRI", 4, 540, 1020, 840, 60, 560068, "Kudlu", "GR Complex, Kudlu Main Road, Near Pratham Maruthi Service Center, Bengaluru, Karnataka 560102, India"),
    SHOP_25(25, "YLG Salon / YLG Bellandur 2.5", "9053525241", "12.9260", "77.6762", 3l, 5f, "MON,TUE,WED,THU,FRI", 4, 540, 1020, 840, 60, 560068, "Bellandur", "# 203/205,ground floor ,Bellendur, Outer Ring Road, Bengaluru, Karnataka 560103, India"),
    SHOP_26(26, "K R S Style Hair Salon", "9053525241", "12.9385", "77.6308", 3l, 5f, "MON,TUE,WED,THU,FRI", 4, 540, 1020, 840, 60, 560068, "Ejipura", "27th Main Rd, VGS Layout, Ejipura, Bengaluru, Karnataka 560047, India"),
    SHOP_27(27, "Lakme Salon", "9053525241", "12.9550", "77.6142", 3l, 5f, "MON,TUE,WED,THU,FRI", 4, 540, 1020, 840, 60, 560068, "Neelasandra", "85, Sheriff House, Richmond Road, Bengaluru, Karnataka 560025, India");

    private int id;
    private String name;
    private String mobNo;
    private String lat;
    private String lng;
    private Long ownerId;
    private Float rating;
    private String workingDays;
    private int maxSheat;
    private int startTime;
    private int endTime;
    private int breakTime;
    private int breakDuration;
    private int pinCode;
    private String place;
    private String address;

    DummyShop(int id, String name, String mobNo, String lat, String lng, Long ownerId, Float rating,
              String workingDays, int maxSheat, int startTime, int endTime, int breakTime, int breakDuration,
              int pinCode, String place, String address) {
        this.id = id;
        this.name = name;
        this.mobNo = mobNo;
        this.lat = lat;
        this.lng = lng;
        this.ownerId = ownerId;
        this.rating = rating;
        this.workingDays = workingDays;
        this.maxSheat = maxSheat;
        this.startTime = startTime;
        this.endTime = endTime;
        this.breakTime = breakTime;
        this.breakDuration = breakDuration;
        this.pinCode = pinCode;
        this.place = place;
        this.address = address;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Long getOwnerId() {
        return ownerId;
    }

    public void setOwnerId(Long ownerId) {
        this.ownerId = ownerId;
    }

    public Float getRating() {
        return rating;
    }

    public void setRating(Float rating) {
        this.rating = rating;
    }

    public String getWorkingDays() {
        return workingDays;
    }

    public void setWorkingDays(String workingDays) {
        this.workingDays = workingDays;
    }

    public int getMaxSheat() {
        return maxSheat;
    }

    public void setMaxSheat(int maxSheat) {
        this.maxSheat = maxSheat;
    }

    public int getStartTime() {
        return startTime;
    }

    public void setStartTime(int startTime) {
        this.startTime = startTime;
    }

    public int getEndTime() {
        return endTime;
    }

    public void setEndTime(int endTime) {
        this.endTime = endTime;
    }

    public int getBreakTime() {
        return breakTime;
    }

    public void setBreakTime(int breakTime) {
        this.breakTime = breakTime;
    }

    public int getBreakDuration() {
        return breakDuration;
    }

    public void setBreakDuration(int breakDuration) {
        this.breakDuration = breakDuration;
    }

    public int getPinCode() {
        return pinCode;
    }

    public void setPinCode(int pinCode) {
        this.pinCode = pinCode;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPlace() {
        return place;
    }

    public void setPlace(String place) {
        this.place = place;
    }

    public String getMobNo() {
        return mobNo;
    }

    public void setMobNo(String mobNo) {
        this.mobNo = mobNo;
    }

    public String getLat() {
        return lat;
    }

    public void setLat(String lat) {
        this.lat = lat;
    }

    public String getLng() {
        return lng;
    }

    public void setLng(String lng) {
        this.lng = lng;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
}
