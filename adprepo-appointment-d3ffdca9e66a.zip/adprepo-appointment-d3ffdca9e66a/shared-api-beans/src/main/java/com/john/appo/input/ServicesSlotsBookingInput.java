package com.john.appo.input;

import com.fasterxml.jackson.annotation.JsonFormat;
import org.springframework.beans.factory.annotation.Value;

import javax.validation.constraints.NotNull;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * @author Krishna
 */
public class ServicesSlotsBookingInput extends ApiInput<Long> {

    @Value("${app.features.booking.isSlotApprovalAuto:true}")
    boolean isSlotApprovalAuto = true;

    private String bookingId; //for output
    @NotNull(message = "User Id must not be null!")

    private Long userId;
    @NotNull(message = "Shop Id must not be null!")

    private Long shopId;
    @NotNull(message = "Service Date must not be null!")

    private LocalDate serviceDate;
    @NotNull(message = "Slot Infos must not be null!")

    private List<SlotInfoInput> slotInfos = new ArrayList<>();

    public String getBookingId() {
        return bookingId;
    }

    public void setBookingId(String bookingId) {
        this.bookingId = bookingId;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public Long getShopId() {
        return shopId;
    }

    public void setShopId(Long shopId) {
        this.shopId = shopId;
    }

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd-MM-yyyy", timezone = "Asia/Kolkata")
    public LocalDate getServiceDate() {
        return serviceDate;
    }

    public void setServiceDate(LocalDate serviceDate) {
        this.serviceDate = serviceDate;
    }

    public List<SlotInfoInput> getSlotInfos() {
        return slotInfos;
    }

    public void setSlotInfos(List<SlotInfoInput> slotInfos) {
        this.slotInfos = slotInfos;
    }

    public boolean isSlotApprovalAuto() {
        return isSlotApprovalAuto;
    }

    public void setSlotApprovalAuto(boolean isSlotApprovalAuto) {
        this.isSlotApprovalAuto = isSlotApprovalAuto;
    }
}
