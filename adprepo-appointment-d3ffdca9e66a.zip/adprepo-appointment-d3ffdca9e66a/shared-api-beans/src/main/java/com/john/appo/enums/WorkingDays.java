/**
 *
 */
package com.john.appo.enums;

/**
 * @author nakesh
 */
public enum WorkingDays {
    SUN,
    MON,
    TUE,
    WED,
    THU,
    FRI,
    SAT;
}
