package com.john.appo.enums;

/**
 * @author nakesh
 */

public enum ErrorCode {
    SC_UNAUTHORIZED(403, "Unauthorized access: unable to authenticate the user"),
    INPUT_PARAM_NOT_CORRECT(10000, "Input parameters are not correct"),
    GIVEN_INPUT_PARAM_NOT_CORRECT(10001, "Input parameters are not correct : {0}"),
    UNKNOWN_EXCEPTION(10002, "Something went wrong, please contact administrator with given id {0}"),

    INVALID_CREDENTIALS(1003, "Invalid username or password"),
    USER_NOT_FOUND(1004, "User not found"),
    CATEGORY_NOT_FOUND(1005, "Category id {} not found"),
    SUB_CATEGORY_NOT_FOUND(1006, "Sub category id {0} not found"),
    SHOP_NOT_FOUND(1007, "Shop id {0} not found"),
    EMAIL_ID_EXIST(1008, "Email {0} already exist"),
    INVALID_WORKING_DAYS(1009, "Invalid working days {0}"),
    INVALID_MAX_SEAT(1010, "Invalid max seat {0}"),
    INVALID_TIMINGS(1011, "Invalid timings"),
    NEW_CONFIRM_PASSWORD_MISMATCH(1012, "New and confirm password are not matching"),
    MEDIA_DOWNLOAD_FAILED(1013, "Media download failed"),
    FILE_DOES_NOT_EXIST(1014, "File does not exist"),
    MISMATCH_SENDERID_AND_TOKENID(1015, "Sender id and token id are not matching"),
    FILE_DOES_NOT_BELONGS_TO_YOU(1016, "Requested file does not belongs to you"),
    MISMATCH_SHOPID_AND_SERVICEID(1017, "Shop id and service id are not matching"),
    NO_PARAM_IN_REQUEST(1018, "No parameter found in the request !!"),
    NO_SERVICE_SLOT_SELECTED(1019, "No service slot selected !! Please select a service with available time slot"),
    INVALID_DATE(1020, "Date should not be previous to current date"),
    SHOP_SERVICE_NOT_FOUND(1021, "shop service id {0} not found"),
    DUPLICATE_FEEDBACK(1022, "Duplicate feedback"),
    INVALID_FEEDBACK_ID(1023, "Invalid feedback id"),
    NOT_ALLOWED_TO_UPDATE_FEEDBACK(1024, "Not allowed to update feedback"),
    INVALID_RATING(1025, "Invalid rating"),
    INVALID_REQUEST_ID(1026, "Invalid request id {} !!, Please provide a valid request id"),
    BOOKING_FAILED_WITH_SLOTS_UNAVAILABILITY(1027, "Booking has been failed as either some of the slots are not available or slots in request has been changed recently!!"),
    NOT_ALLOWED_TO_BLOCK_SLOTS(1028, "Sorry !! All slots are already booked by some user"),
    NO_SLOTS_TO_UNBLOCK(1029, "Sorry !! No slots have been found to unblock"),
    INVALID_SHOP_ID(1030, "Invalid shop id !!"),
    INVALID_BOOKING_ID(1031, "Invalid booking id {}!!"),
    UNKNOWN_BOOKING_STATUS(1032, "Unknown booking status !!"),
    INVALID_SEARCH_DATE(1033, "Invalid search date !!"),
    INVALID_USER_ID_FOR_BOOKING_ID(1034, "Invalid user id {} for booking id {} !! Please enter correct details then try !"),
    ONLY_APPROVED_SLOTS_CAN_BE_BOOKED(1035, "Only approved slot can be booked !!"),
    MISSING_DEVICE_TYPE(1036, "Device type missing"),
    DEVICE_TYPE_MISSING(1037, "Device type missing"),
    USERNAME_MISSING(1038, "Username missing"),
    PASSWORD_AND_CONFIRM_PASSWORD_MISMATCH(1039, "Password and confirm password are not matching"),
    ACCOUNT_NOT_YET_APPROVED(1040, "Account not yet approved"),
    INVALID_SOCIAL_MEDIA_TYPE(1041, "Invalid social media type"),
    DEVICE_TYPE_SHOULD_NOT_BE_BLANKED(1042, "Device type should not be blanked"),
    MOBILE_SHOULD_NOT_BE_BLANKED(1043, "Mobile should not be blanked"),
    BLOCKING_DATE_SHOULD_BE_GREATER_THAN_TODAYS_DATE(1044, "Blocking date should be greater than today date"),
    INVALID_REQUEST_FOR_REFUND(1045, "Request for refund can not be completed as no payment exists for this payment id : {} and booking id : {}"),
    FOUND_EXCEPTION(1046, "Found exception : {}");


    private Integer errorCode;
    private String errorMessEn;

    private ErrorCode(Integer errorCode, String errorMessage) {
        this.errorCode = errorCode;
        this.errorMessEn = errorMessage;
    }

    public Integer getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(Integer errorCode) {
        this.errorCode = errorCode;
    }


    public String getErrorMessEn() {
        return errorMessEn;
    }

    public void setErrorMessEn(String errorMessEn) {
        this.errorMessEn = errorMessEn;
    }
}
