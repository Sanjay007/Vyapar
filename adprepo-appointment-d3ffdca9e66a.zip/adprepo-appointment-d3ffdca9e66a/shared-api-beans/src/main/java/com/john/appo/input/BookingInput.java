package com.john.appo.input;

import com.john.appo.enums.PaymentMode;
import com.john.appo.enums.Status;

/**
 * @Author Krishna
 */
public class BookingInput extends ApiInput<Long> {

    private String bookingId;
    @Deprecated
    private Long userId;
    //Payment details
    private PaymentMode paymentMode;
    private String paymentId;
    private Double paidAmount;
    private Double disFlat;
    private Integer disPercent;
    private Long promoId;
    private String promoCode;
    private Status status;
    private String description;

    public String getBookingId() {
        return bookingId;
    }

    public void setBookingId(String bookingId) {
        this.bookingId = bookingId;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public PaymentMode getPaymentMode() {
        return paymentMode;
    }

    public void setPaymentMode(PaymentMode paymentMode) {
        this.paymentMode = paymentMode;
    }

    public String getPaymentId() {
        return paymentId;
    }

    public void setPaymentId(String paymentId) {
        this.paymentId = paymentId;
    }

    public Double getPaidAmount() {
        return paidAmount;
    }

    public void setPaidAmount(Double paidAmount) {
        this.paidAmount = paidAmount;
    }

    public Double getDisFlat() {
        return disFlat;
    }

    public void setDisFlat(Double disFlat) {
        this.disFlat = disFlat;
    }

    public Integer getDisPercent() {
        return disPercent;
    }

    public void setDisPercent(Integer disPercent) {
        this.disPercent = disPercent;
    }

    public Long getPromoId() {
        return promoId;
    }

    public void setPromoId(Long promoId) {
        this.promoId = promoId;
    }

    public String getPromoCode() {
        return promoCode;
    }

    public void setPromoCode(String promoCode) {
        this.promoCode = promoCode;
    }

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
