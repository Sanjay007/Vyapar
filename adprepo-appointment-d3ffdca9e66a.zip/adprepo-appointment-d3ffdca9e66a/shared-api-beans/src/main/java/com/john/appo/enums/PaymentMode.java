/**
 *
 */
package com.john.appo.enums;

/**
 * @author nakesh
 */
public enum PaymentMode {
    ONLINE,
    OFFLINE;
}
