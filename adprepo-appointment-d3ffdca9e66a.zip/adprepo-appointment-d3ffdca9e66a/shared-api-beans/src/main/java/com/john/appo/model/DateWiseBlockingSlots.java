/**
 * 
 */
package com.john.appo.model;

import java.time.LocalDate;

/**
 * @author nakesh
 *
 */
public class DateWiseBlockingSlots {
	private LocalDate date;
	//various slots for date

	public LocalDate getDate() {
		return date;
	}

	public void setDate(LocalDate date) {
		this.date = date;
	}
}
