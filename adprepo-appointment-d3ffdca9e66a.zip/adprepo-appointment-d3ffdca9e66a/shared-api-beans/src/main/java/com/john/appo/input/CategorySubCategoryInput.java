package com.john.appo.input;

import java.util.List;

/**
 * @author nakesh
 */
public class CategorySubCategoryInput extends ApiInput<Long> {
    private Long catId;
    private Long subCatId;
    private String name;
    private List<String> names;

    public Long getSubCatId() {
        return subCatId;
    }

    public void setSubCatId(Long subCatId) {
        this.subCatId = subCatId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Long getCatId() {
        return catId;
    }

    public void setCatId(Long catId) {
        this.catId = catId;
    }

    public List<String> getNames() {
        return names;
    }

    public void setNames(List<String> names) {
        this.names = names;
    }
}
