package com.john.appo.constants;

/**
 * @author nakesh
 */
public interface Constants {
    int ZERO = 0;
    int ONE = 1;
    int TWO = 2;
    int THREE = 3;
    int FOUR = 4;
    int FIVE = 5;
    int TEN = 10;
    int TWENTY = 20;
    int TWENTY_THREE = 23;
    int SIXTY = 60;
    int BUFFER_SIZE = 4096;

    String APPO_CONSTANT = "AP";
    String APP_NAME = "APPO";
    String X_AUTH_TOKEN = "X-AUTH-TOKEN";
    String CLIENT_ID = "john";
    String DOT = ".";
    String HIGH = "high";
}