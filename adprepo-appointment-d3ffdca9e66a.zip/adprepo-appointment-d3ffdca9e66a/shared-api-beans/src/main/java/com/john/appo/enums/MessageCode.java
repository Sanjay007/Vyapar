package com.john.appo.enums;

/**
 * @author nakesh
 */
public enum MessageCode {
    API_SUCCESS("AD_0001", "SUCCESS", "SUCCESS"),
    OTP_SENT("AD_0002", "OTP is sent to registered mobile ending {0}", "تم ارسال الرمز التعريفي على الرقم {0}");
    private String code;
    private String messEn;
    private String messAr;

    private MessageCode(String code, String messEn, String messAr) {
        this.code = code;
        this.messEn = messEn;
        this.messAr = messAr;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMessEn() {
        return messEn;
    }

    public void setMessEn(String messEn) {
        this.messEn = messEn;
    }

    public String getMessAr() {
        return messAr;
    }

    public void setMessAr(String messAr) {
        this.messAr = messAr;
    }
}
