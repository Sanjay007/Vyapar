/**
 * 
 */
package com.john.appo.input;

import java.util.List;

import com.john.appo.model.DateWiseBlockingSlots;

/**
 * @author nakesh
 *
 */
public class BlockSlotInput {
	private Long serviceId;
	private String reason;
	private List<DateWiseBlockingSlots> dates;

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public Long getServiceId() {
		return serviceId;
	}

	public void setServiceId(Long serviceId) {
		this.serviceId = serviceId;
	}

	public List<DateWiseBlockingSlots> getDates() {
		return dates;
	}

	public void setDates(List<DateWiseBlockingSlots> dates) {
		this.dates = dates;
	}
	
}
