package com.john.appo.constants;

/**
 * @author Krishna
 */
public interface DateTimePatternFormatter {

    String DATE_TIME_FORMAT_SEP_WITH_HI = "dd-MM-yyyy HH:mm:ss";
    String DATE_TIME_TILL_MIN_FORMAT_SEP_WITH_HI = "dd-MM-yyyy HH:mm";
    String DATE_FORMAT_SEP_WITH_HI = "dd-MM-yyyy";
    String DATE_TIME_FORMAT_SEP_WITH_US = "dd_MM_yyyy_HH_mm_ss";
    String DATE_TIME_FORMAT_SEP_WITH_SL = "dd/MM/yyyy HH:mm:ss";
}
