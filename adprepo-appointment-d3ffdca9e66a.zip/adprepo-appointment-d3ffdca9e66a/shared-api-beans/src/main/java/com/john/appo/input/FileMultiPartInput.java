/**
 *
 */
package com.john.appo.input;

/**
 * @author nakesh
 */
public class FileMultiPartInput {

}
