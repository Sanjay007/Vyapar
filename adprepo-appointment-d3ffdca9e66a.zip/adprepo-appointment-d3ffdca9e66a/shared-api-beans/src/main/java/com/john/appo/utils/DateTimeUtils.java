/**
 *
 */
package com.john.appo.utils;

import com.john.appo.constants.C;
import com.john.appo.enums.TimeZoneList;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.temporal.ChronoUnit;
import java.util.Locale;

/**
 * @author nakesh
 */
public class DateTimeUtils {
    private static final Logger logger = LoggerFactory.getLogger(DateTimeUtils.class);

    public static LocalDateTime getValidDate(String date) {
        if (StringUtils.isEmpty(date))
            return null;
        try {
            return LocalDate.parse(date, DateTimeFormatter.ofPattern("yyyy-MM-dd", Locale.ENGLISH)).atTime(00, 00, 01); // make starting time of day
        } catch (DateTimeParseException e) {
            logger.error("Exception while parsing string date", date);
            return null;
        }
    }

    public static LocalDateTime getEndDateTimeForGivenDate(String date) {
        if (StringUtils.isEmpty(date))
            return null;
        try {
            return LocalDate.parse(date, DateTimeFormatter.ofPattern("yyyy-MM-dd", Locale.ENGLISH)).atTime(23, 59, 59); // make ending time of day
        } catch (DateTimeParseException e) {
            logger.error("Exception while parsing string date {0}", date);
            return null;
        }
    }

    public static LocalDateTime getStartDateTimeForDate(LocalDateTime dateTime) {
        return dateTime.truncatedTo(ChronoUnit.DAYS);
    }

    public static LocalDateTime getEndDateTimeForDate(LocalDateTime dateTime) {
        return dateTime.toLocalDate().atTime(23, 59, 59);
    }

    public static int getTimeInMinFromCurrentTime(LocalDate bookingLocalDate) {
        LocalDate currentLocalDate = LocalDate.now(ZoneId.of(TimeZoneList.IST.getZoneId()));
        if (bookingLocalDate.isEqual(currentLocalDate)) {
            LocalTime localTime = LocalTime.now(ZoneId.of(TimeZoneList.IST.getZoneId()));
            return localTime.getHour() * C.SIXTY + localTime.getMinute();
        } else {
            return 0;   // for future date booking it will be 0;
        }
    }

    public static String getTimeInHrMin(int minute) {
        return String.valueOf(minute / C.SIXTY) + C.DOT + String.valueOf((minute % C.SIXTY));
    }

    public static int compareDate(LocalDateTime dateTime, LocalDateTime dateTime1) {
        return dateTime.toLocalDate().compareTo(dateTime1.toLocalDate());
    }

    public static LocalDateTime getFormattedDateTime(String index) {
        return getFormattedDateTime(index, ZoneId.of(TimeZoneList.IST.getZoneId()));
    }

    public static LocalDateTime getFormattedDateTime(String index, ZoneId zone) {
        try {
            return LocalDateTime.parse(index, DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss Z", Locale.ENGLISH));
        } catch (Exception ex) {
        }
        try {
            return LocalDateTime.parse(index, DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss", Locale.ENGLISH).withZone(zone));
        } catch (Exception ex) {
        }

        try {
            return LocalDateTime.parse(index, DateTimeFormatter.ofPattern("dd-MM-yyyy", Locale.ENGLISH).withZone(zone));
        } catch (Exception ex) {
        }

        try {
            return LocalDateTime.parse(index, DateTimeFormatter.ofPattern("MM-yyyy", Locale.ENGLISH).withZone(zone));
        } catch (Exception ex) {
        }

        try {
            if (zone != null)
                return LocalDateTime.parse(index, DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss", Locale.ENGLISH).withZone(zone));
            return LocalDateTime.parse(index, DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss", Locale.ENGLISH));
        } catch (Exception ex) {
        }
        logger.error("Date ({0}) cannot be parsed", index);
        return null;
    }

    public static String formatDateTime(LocalDateTime dateTime, String pattern) {
        return formatDateTime(dateTime, pattern, ZoneId.of(TimeZoneList.IST.getZoneId()));
    }

    public static String formatDateTime(LocalDateTime dateTime, String pattern, ZoneId zoneId) {
        return dateTime.format(DateTimeFormatter.ofPattern(pattern).withZone(zoneId));
    }
}
