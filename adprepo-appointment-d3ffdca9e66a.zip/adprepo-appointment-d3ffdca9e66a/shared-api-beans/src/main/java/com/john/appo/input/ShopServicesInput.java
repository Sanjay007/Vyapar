package com.john.appo.input;


import org.hibernate.validator.constraints.NotBlank;

import javax.persistence.Transient;
import java.util.List;

public class ShopServicesInput extends ApiInput<Long> {


    @NotBlank(message = "userId must not be blank!")
    private Long userId;
    @NotBlank(message = "shopId must not be blank!")
    private Long shopId;
    @NotBlank(message = "catId must not be blank!")
    private Long catId;
    @NotBlank(message = "subCatId must not be blank!")
    private List<Long> subCatId;
    @NotBlank(message = "name must not be blank!")
    private String name;
    @NotBlank(message = "servingPersonName must not be blank!")
    private String servingPersonName;
    private String description;
    @NotBlank(message = "lat must not be blank!")
    private Float lat;
    @NotBlank(message = "lon must not be blank!")
    private Float lon;
    @NotBlank(message = "actPrice must not be blank!")
    private Double actPrice; // actualPrice
    @NotBlank(message = "disFlat must not be blank!")
    private Double disFlat; // discountFlat
    @NotBlank(message = "disPercent must not be blank!")
    private Integer disPercent;// discountPercentage
    @NotBlank(message = "workingDays must not be blank!")
    private String workingDays; // comma separated days
    @NotBlank(message = "avgTime must not be blank!")
    private int avgTime;
    @NotBlank(message = "maxSeat must not be blank!")
    private int maxSeat;
    @NotBlank(message = "startTime must not be blank!")
    private int startTime; // in minutes (24 hrs time frame)
    @NotBlank(message = "endTime must not be blank!")
    private int endTime; // in minutes (24 hrs time frame)
    @NotBlank(message = "breakTime must not be blank!")
    private int breakTime; // in minutes (24 hrs time frame)
    @NotBlank(message = "breakDuration must not be blank!")
    private int breakDuration; // in minutes (24 hrs time frame)
    @NotBlank(message = "wkndStartTime must not be blank!")
    private int wkndStartTime; // weekendStartTime
    @NotBlank(message = "wkndEndTime must not be blank!")
    private int wkndEndTime; // weekendEndTime
    @NotBlank(message = "wkndActPrice must not be blank!")
    private Double wkndActPrice; // weekendActualTime
    private Float rating;
    private boolean active;
    private boolean approved;

    @Transient
    private Double distance;

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public Long getShopId() {
        return shopId;
    }

    public void setShopId(Long shopId) {
        this.shopId = shopId;
    }

    public Long getCatId() {
        return catId;
    }

    public void setCatId(Long catId) {
        this.catId = catId;
    }

    public List<Long> getSubCatId() {
        return subCatId;
    }

    public void setSubCatId(List<Long> subCatId) {
        this.subCatId = subCatId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getServingPersonName() {
        return servingPersonName;
    }

    public void setServingPersonName(String servingPersonName) {
        this.servingPersonName = servingPersonName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Float getLat() {
        return lat;
    }

    public void setLat(Float lat) {
        this.lat = lat;
    }

    public Float getLon() {
        return lon;
    }

    public void setLon(Float lon) {
        this.lon = lon;
    }

    public Double getActPrice() {
        return actPrice;
    }

    public void setActPrice(Double actPrice) {
        this.actPrice = actPrice;
    }

    public Double getDisFlat() {
        return disFlat;
    }

    public void setDisFlat(Double disFlat) {
        this.disFlat = disFlat;
    }

    public Integer getDisPercent() {
        return disPercent;
    }

    public void setDisPercent(Integer disPercent) {
        this.disPercent = disPercent;
    }

    public String getWorkingDays() {
        return workingDays;
    }

    public void setWorkingDays(String workingDays) {
        this.workingDays = workingDays;
    }

    public int getAvgTime() {
        return avgTime;
    }

    public void setAvgTime(int avgTime) {
        this.avgTime = avgTime;
    }

    public int getMaxSeat() {
        return maxSeat;
    }

    public void setMaxSeat(int maxSheat) {
        this.maxSeat = maxSheat;
    }

    public int getStartTime() {
        return startTime;
    }

    public void setStartTime(int startTime) {
        this.startTime = startTime;
    }

    public int getEndTime() {
        return endTime;
    }

    public void setEndTime(int endTime) {
        this.endTime = endTime;
    }

    public int getBreakTime() {
        return breakTime;
    }

    public void setBreakTime(int breakTime) {
        this.breakTime = breakTime;
    }

    public int getBreakDuration() {
        return breakDuration;
    }

    public void setBreakDuration(int breakDuration) {
        this.breakDuration = breakDuration;
    }

    public int getWkndStartTime() {
        return wkndStartTime;
    }

    public void setWkndStartTime(int wkndStartTime) {
        this.wkndStartTime = wkndStartTime;
    }

    public int getWkndEndTime() {
        return wkndEndTime;
    }

    public void setWkndEndTime(int wkndEndTime) {
        this.wkndEndTime = wkndEndTime;
    }

    public Double getWkndActPrice() {
        return wkndActPrice;
    }

    public void setWkndActPrice(Double wkndActPrice) {
        this.wkndActPrice = wkndActPrice;
    }

    public Float getRating() {
        return rating;
    }

    public void setRating(Float rating) {
        this.rating = rating;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public boolean isApproved() {
        return approved;
    }

    public void setApproved(boolean approved) {
        this.approved = approved;
    }

    public Double getDistance() {
        return distance;
    }

    public void setDistance(Double distance) {
        this.distance = distance;
    }


}
