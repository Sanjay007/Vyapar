package com.john.appo.constants;

/**
 * @author krishna.kumar
 */
public interface RazorPayConstants {
    String RAZOR_PAY_BASE_URL = "https://api.razorpay.com/v1";
    String RAZOR_PAY_API_KEY = "rzp_test_QwEJn6cfDnHWKU";
    String RAZOR_PAY_API_SECRET = "liljfoqNUy0SfRPvvJVEoieq";

    String RAZOR_PAY_ID = "id";
    String RAZOR_PAY_PAYMENT_ID = "payment_id";
    String RAZOR_PAY_ENTITY = "entity";
    String RAZOR_PAY_AMOUNT = "amount";
    String RAZOR_PAY_AMOUNT_PAID = "amount_paid";
    String RAZOR_PAY_AMOUNT_DUE = "amount_due";
    String RAZOR_PAY_AMOUNT_REFUNDED = "amount_refunded";
    String RAZOR_PAY_CURRENCY = "currency";
    String RAZOR_PAY_STATUS = "status";
    String RAZOR_PAY_ORDER_ID = "order_id";
    String RAZOR_PAY_INVOICE_ID = "invoice_id";
    String RAZOR_PAY_INTERNATIONAL = "international";
    String RAZOR_PAY_METHOD = "method";
    String RAZOR_PAY_REFUND_STATUS = "refund_status";
    String RAZOR_PAY_CAPTURED = "captured";
    String RAZOR_PAY_DESC = "description";
    String RAZOR_PAY_CARD_ID = "card_id";
    String RAZOR_PAY_BANK = "bank";
    String RAZOR_PAY_WALLET = "wallet";
    String RAZOR_PAY_VPA = "vpa";
    String RAZOR_PAY_EMAIL = "email";
    String RAZOR_PAY_CONTACT = "contact";
    String RAZOR_PAY_NOTES = "notes";
    String RAZOR_PAY_FEE = "fee";
    String RAZOR_PAY_TAX = "tax";
    String RAZOR_PAY_ERROR_CODE = "error_code";
    String RAZOR_PAY_ERROR_DESC = "error_description";
    String RAZOR_PAY_CREATED_AT = "created_at";
    String RAZOR_PAY_RECEIPT = "receipt";
    String RAZOR_PAY_OFFER_ID = "offer_id";
    String RAZOR_PAY_ATTEMPTS = "attempts";
}
