package com.john.appo.feedback.service;

import com.john.appo.enums.Operation;
import com.john.appo.input.FeedbackInput;
import com.john.appo.output.ApiResponse;
import org.springframework.data.domain.Pageable;


/**
 * @author: nakesh
 */
public interface FeedbackService {
    ApiResponse add(FeedbackInput input);

    ApiResponse update(FeedbackInput input);

    ApiResponse getFeedbacks(Long shopServiceId, Long shopId, Integer rating, Operation operation, Pageable pageable);
}
