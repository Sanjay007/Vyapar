/**
 *
 */
package com.john.appo.feedback.helper;

import com.john.appo.entity.Shop;
import com.john.appo.entity.ShopServices;
import com.john.appo.entity.repository.FeedbackRepository;
import com.john.appo.entity.repository.ShopRepository;
import com.john.appo.entity.repository.ShopServicesRepository;
import com.john.appo.enums.ErrorCode;
import com.john.appo.enums.Operation;
import com.john.appo.input.FeedbackInput;
import com.john.appo.output.ApiResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.text.DecimalFormat;

/**
 * @author nakesh
 */
@Service
public class FeedbackHelper {

    @Autowired
    FeedbackRepository feedbackRepository;
    @Autowired
    ShopRepository shopRepository;
    @Autowired
    ShopServicesRepository shopServicesRepository;

    @Async
    public void updateShopAndShopServicesAverageRating(FeedbackInput input) {
        if (input.getOperation() == Operation.U_SS_FEEDBACK) {    // rating by user
            Shop shop = shopRepository.findOne(input.getShopId());
            ShopServices shopService = shopServicesRepository.findOne(input.getShopServiceId());
            Double serviceAverageRating = feedbackRepository.findAverageRatingForServiceId(input.getShopServiceId(), input.getOperation());
            Double shopAverageRating = feedbackRepository.findAverageRatingForShopId(input.getShopId(), input.getOperation());
            DecimalFormat oneDigitAfterDecimal = new DecimalFormat("#,##0.0");//format to 1 decimal place
            shop.setRating(Float.parseFloat(oneDigitAfterDecimal.format(shopAverageRating)));
            shopService.setRating(Float.parseFloat(oneDigitAfterDecimal.format(serviceAverageRating)));
            shopRepository.save(shop);
            shopServicesRepository.save(shopService);
        }
    }

    public ApiResponse validateShopAndShopService(FeedbackInput input) {
        ShopServices shopService = shopServicesRepository.findOne(input.getShopServiceId());
        if (shopService == null) {
            return new ApiResponse(ErrorCode.SHOP_SERVICE_NOT_FOUND, String.valueOf(input.getShopServiceId()));
        }
        if (shopService.getShopId() != input.getShopId()) {
            return new ApiResponse(ErrorCode.MISMATCH_SHOPID_AND_SERVICEID);
        }
        return new ApiResponse();
    }

    public ApiResponse validateDuplicateFeedback(FeedbackInput input) {
        if (null != feedbackRepository.findByUserIdAndBookingIdAndOperation(input.getUserId(), input.getBookingId(), input.getOperation())) {
            return new ApiResponse(ErrorCode.DUPLICATE_FEEDBACK);
        }
        return new ApiResponse();
    }

    public ApiResponse validateRating(int rating) {
        if (rating < 1 || rating > 5) {
            return new ApiResponse(ErrorCode.INVALID_RATING);
        }
        return new ApiResponse();
    }

    public ApiResponse validateInput(FeedbackInput input) {
        if (input.getDevice() == null || input.getDeviceModel() == null
                || input.getLat() == null || input.getLon() == null
                || input.getOperation() == null
                || (input.getOperation() == Operation.SO_SS_FEEDBACK || input.getOperation() == Operation.U_SS_FEEDBACK
                && (input.getUserId() == null || input.getShopId() == null || input.getShopServiceId() == null))) {
            return new ApiResponse(ErrorCode.INPUT_PARAM_NOT_CORRECT);
        }
        if (input.getOperation() == Operation.SO_SS_FEEDBACK || input.getOperation() == Operation.U_SS_FEEDBACK) {
            // for Operation.APP_FEEDBACK no need to validate shop and shopService as those values would be null
            ApiResponse response = validateDuplicateFeedback(input);
            if (!response.isSuccess()) {
                return response;
            }
            return validateShopAndShopService(input);
        }
        return validateRating(input.getRating());
    }
}
