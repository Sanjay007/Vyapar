/**
 *
 */
package com.john.appo.feedback.service.impl;

import com.john.appo.constants.C;
import com.john.appo.entity.Feedback;
import com.john.appo.entity.User;
import com.john.appo.entity.repository.FeedbackRepository;
import com.john.appo.entity.repository.ShopServicesRepository;
import com.john.appo.entity.repository.UserRepository;
import com.john.appo.enums.ErrorCode;
import com.john.appo.enums.Operation;
import com.john.appo.enums.TimeZoneList;
import com.john.appo.input.FeedbackInput;
import com.john.appo.output.ApiResponse;
import com.john.appo.output.FeedbackModel;
import com.john.appo.output.ShopAndServicesFeedbackModel;
import com.john.appo.feedback.helper.FeedbackHelper;
import com.john.appo.feedback.service.FeedbackService;
import org.apache.maven.shared.utils.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.text.DecimalFormat;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @author nakesh
 */
@Service
public class FeedbackServiceImpl implements FeedbackService {

    @Autowired
    ShopServicesRepository shopServiceRepository;
    @Autowired
    FeedbackRepository feedbackRepository;
    @Autowired
    UserRepository userRepository;
    @Autowired
    FeedbackHelper helper;

    // Todo : validate bookingId belongs to same shop and shopService
    @Override
    public ApiResponse add(FeedbackInput input) {
        ApiResponse response = helper.validateInput(input);
        if (!response.isSuccess()) {
            return response;
        }
        Feedback feedback = new Feedback();
        BeanUtils.copyProperties(input, feedback);
        feedback.setCreatedTime(LocalDateTime.now(ZoneId.of(TimeZoneList.IST.getZoneId())));
        feedbackRepository.save(feedback);
        //updating shop and shopService average rating from feedback ratings : Async call
        helper.updateShopAndShopServicesAverageRating(input);
        return new ApiResponse();
    }

    @Override
    public ApiResponse update(FeedbackInput input) {
        Feedback feedback = feedbackRepository.findOne(input.getId());
        if (feedback == null) {
            return new ApiResponse(ErrorCode.INVALID_FEEDBACK_ID);
        }
        if (feedback.getUserId() != input.getUserId()) {
            return new ApiResponse(ErrorCode.NOT_ALLOWED_TO_UPDATE_FEEDBACK);
        }
        if (input.getRating() > 0) {
            feedback.setRating(input.getRating());
        }
        if (StringUtils.isNotBlank(input.getReview())) {
            feedback.setReview(input.getReview());
        }
        feedback.setModifiedTime(LocalDateTime.now(ZoneId.of(TimeZoneList.IST.getZoneId())));
        feedbackRepository.save(feedback);
        if ((feedback.getOperation() == Operation.U_SS_FEEDBACK || feedback.getOperation() == Operation.SO_SS_FEEDBACK)
                && helper.validateRating(input.getRating()).isSuccess()) {
            input.setShopId(feedback.getShopId());
            input.setShopServiceId(feedback.getShopServiceId());
            input.setOperation(feedback.getOperation());
            helper.updateShopAndShopServicesAverageRating(input);
        }
        return new ApiResponse();
    }

    @Override
    public ApiResponse getFeedbacks(Long shopServiceId, Long shopId, Integer rating, Operation operation, Pageable pageable) {
        if (shopServiceId == null && shopId == null && rating == null) {
            return new ApiResponse(ErrorCode.INPUT_PARAM_NOT_CORRECT);
        }
        Page<Feedback> feedbacksPageable = getFeedbackPageable(shopServiceId, shopId, rating, operation, pageable);
        List<Feedback> feedbacks = feedbacksPageable.getContent();
        if (feedbacks.isEmpty()) {
            ShopAndServicesFeedbackModel shopAndServicesFeedbackModel = new ShopAndServicesFeedbackModel(feedbacks, feedbacksPageable, shopServiceId, shopId);
            return new ApiResponse(shopAndServicesFeedbackModel);
        }
        List<Object[]> feedbackCounts = getFeedbackCount(shopServiceId, shopId, rating, operation);
        Map<Long, User> userIdUserMap = null;
        if (!feedbacks.isEmpty()) {
            List<Long> userIds = getUserIds(feedbacks);
            List<User> users = userRepository.findAll(userIds);
            userIdUserMap = users.stream().collect(Collectors.toMap(x -> x.getId(), x -> x));
        }
        ShopAndServicesFeedbackModel shopAndServicesFeedbackModel =
                new ShopAndServicesFeedbackModel(getFeedbackEntityToBean(feedbacks, userIdUserMap), feedbacksPageable, shopServiceId, shopId);
        addfeedbackCounts(shopAndServicesFeedbackModel, feedbackCounts, feedbacks.size());
        return new ApiResponse(shopAndServicesFeedbackModel);
    }

    private Page<Feedback> getFeedbackPageable(Long shopServiceId, Long shopId, Integer rating, Operation operation, Pageable pageable) {
        Page<Feedback> feedbacksPageable = null;
        if (shopId != null && rating != null) {
            feedbacksPageable = feedbackRepository.findByShopIdAndRatingAndOperationOrderByCreatedTimeDesc(shopId, rating, operation, pageable);
        } else if (shopServiceId != null && rating != null) {
            feedbacksPageable = feedbackRepository.findByShopServiceIdAndRatingAndOperationOrderByCreatedTimeDesc(shopServiceId, rating, operation, pageable);
        } else if (shopId != null) {
            feedbacksPageable = feedbackRepository.findByShopIdAndOperationOrderByRatingDescCreatedTimeDesc(shopId, operation, pageable);
        } else if (shopServiceId != null) {
            feedbacksPageable = feedbackRepository.findByShopServiceIdAndOperationOrderByRatingDescCreatedTimeDesc(shopServiceId, operation, pageable);
        } else if (rating != null) {
            feedbacksPageable = feedbackRepository.findByRatingAndOperationOrderByCreatedTimeDesc(rating, operation, pageable);
        }
        return feedbacksPageable;
    }


    public List<Object[]> getFeedbackCount(Long shopServiceId, Long shopId, Integer rating, Operation operation) {
        List<Object[]> feedbackCounts = null;
        if (shopId != null && rating != null) {
            feedbackCounts = feedbackRepository.findByShopIdAndRatingAndOperation(shopId, rating, operation);
        } else if (shopServiceId != null && rating != null) {
            feedbackCounts = feedbackRepository.findByShopServiceIdAndRatingAndOperation(shopServiceId, rating, operation);
        } else if (shopId != null) {
            feedbackCounts = feedbackRepository.findByShopIdAndOperation(shopId, operation);
        } else if (shopServiceId != null) {
            feedbackCounts = feedbackRepository.findByShopServiceIdAndOperation(shopServiceId, operation);
        } else if (rating != null) {
            feedbackCounts = feedbackRepository.findByRatingAndOperation(rating, operation);
        }
        return feedbackCounts;
    }

    private List<Long> getUserIds(List<Feedback> feedbacks) {
        List<Long> userIds = new ArrayList<>();
        for (Feedback feedback : feedbacks) {
            if (!userIds.contains(feedback.getUserId())) {
                userIds.add(feedback.getUserId());
            }
        }
        return userIds;
    }

    private void addfeedbackCounts(ShopAndServicesFeedbackModel shopAndServicesFeedbackModel, List<Object[]> feedbackCounts, int numberOfFeedback) {
        int totalRating = 0;
        for (Object[] object : feedbackCounts) {
            int ratingNo = (Integer) object[0];
            int ratingCount = ((Long) object[1]).intValue();
            totalRating = totalRating + ratingNo * ratingCount;
            if (ratingNo == C.FIVE) {
                shopAndServicesFeedbackModel.setFiveStar(ratingCount);
            } else if (ratingNo == C.FOUR) {
                shopAndServicesFeedbackModel.setFourStar(ratingCount);
            } else if (ratingNo == C.THREE) {
                shopAndServicesFeedbackModel.setThreeStar(ratingCount);
            } else if (ratingNo == C.TWO) {
                shopAndServicesFeedbackModel.setTwoStar(ratingCount);
            } else if (ratingNo == C.ONE) {
                shopAndServicesFeedbackModel.setOneStar(ratingCount);
            }
        }
        shopAndServicesFeedbackModel.setTotalFeedback(numberOfFeedback);
        DecimalFormat oneDigitAfterDecimal = new DecimalFormat("#,##0.0");//format to 1 decimal place
        shopAndServicesFeedbackModel.setAverageFeedback(Float.parseFloat(oneDigitAfterDecimal.format((float) totalRating / numberOfFeedback)));
    }

    private List<FeedbackModel> getFeedbackEntityToBean(List<Feedback> feedbacks, Map<Long, User> userIdUserMap) {
        List<FeedbackModel> feedbackModels = new ArrayList<>();
        for (Feedback feedback : feedbacks) {
            FeedbackModel feedbackModel = new FeedbackModel();
            User user = userIdUserMap.get(feedback.getUserId());
            feedbackModel.setId(feedback.getId());
            feedbackModel.setUserName(user.getName());
            feedbackModel.setUserProImage(user.getProImage());
            feedbackModel.setRating(feedback.getRating());
            feedbackModel.setReview(feedback.getReview());
            feedbackModel.setBookingId(feedback.getBookingId());
            feedbackModel.setShopServiceId(feedback.getShopServiceId());
            feedbackModel.setCreatedTime(feedback.getCreatedTime());
            feedbackModels.add(feedbackModel);
        }
        return feedbackModels;
    }
}
