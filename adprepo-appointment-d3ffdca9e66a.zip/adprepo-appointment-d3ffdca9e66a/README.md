#API DOC ...

https://docs.google.com/spreadsheets/d/1b9aIBwG4SI5MJrAt4Lj5X4Lp4ZjkvO92wxBZ8o6Df_Q/edit?usp=sharing



# README #

This README would normally document whatever steps are necessary to get your application up and running.

### What is this repository for? ###

* Apis for application named appointment used for taking appointments from barber shop, parlors etc.
* Version : 0.1

### Project Structure ###

# There are four component of project under 'appointment'
* shared-api-beans (utility component): will contain all inputs, outputs, models, utils, enums shared among all other component.
* authentication : responsible for authenticating exposed apis. allows role based access of apis. component dependency includes shared-api-beans
* entities : will contain all entities, repository and its implementation. component dependency includes shared-api-beans
* appointment-service : core component having all apis controller, service, service implementation, dao, dao impl and their business logics. component dependency includes shared-api-beans, authentication, entities

### How do I get set up? ###

* Summary of set up : Download git project
* Configuration : run 'mvn clean install'
* Dependencies : pom.xml contains all dependency


### Database configuration : 
* Used any database mysql, postgre, sql server Add/replace datasource url, username, password, dialect in appointment.properties under /src/main/resource folder
* run sql queries from /appointment-service/db_script/22-05-2017 folder to create database and tables (applicable on mysql)

### Running project : 
* go to folder appointment and run : mvn clean install
* go to folder appointment-service and run : mvn spring-boot:run
* if every thing is ok, server must start on configured port.
* for testing open postman and try to hit : http://localhost:port/login/greeting

### Postman request for ###
## Creating User : 
*  Request method : POST
*  URL : http://localhost:port/user/create
*  Request Body : {
	"name":"nakesh",
	"email":"nkes4@gmail.com",
	"password":"123",
	"phone":"1234567891",
	"userType":"USER",
	"locality":"boomanhalli",
	"area":"rupena",
	"streetName":"rupena",
	"pinCode":"1234546",
	"sex":"M"
        }
*   Response Body : 
{
  "success": true,
  "data": {
    "id": 1,
    "name": "nakesh",
    "email": "nkesh@gmail.com",
    "phone": "1234567891",
    "userType": "USER",
    "locality": "boomanhalli",
    "area": "rupena",
    "streetName": "rupena",
    "pinCode": "1234546",
    "sex": "M",
    "proImage": null,
    "authToken": "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIxIi"
  }
}

## Login : 
*   Request method : POST
*   URL : http://localhost:port/login
*   Request Body : 
{
	"email":"nkesh@gmail.com",
	"password":"123"
}
*    Response Body : 
{
  "success": true,
  "data": {
    "id": 1,
    "name": "nakesh",
    "email": "nkesh@gmail.com",
    "phone": "1234567891",
    "userType": "USER",
    "locality": "boomanhalli",
    "area": "rupena",
    "streetName": "rupena",
    "pinCode": "1234546",
    "sex": "M",
    "proImage": null,
    "authToken": "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIxIi"
  }
}

# Use authToken for subsequent request.


### Values stored in authToken ###

{
  "sub": "1",
  "aud": "APPO",
  "roles": "USER",
  "userType": "MERCHANT",
  "iat": 1495521614,
  "exp": 1495608014
}

### Contribution guidelines ###

* Writing tests
* Code review
* Other guidelines

### Who do I talk to? ###

* Repo owner or admin
* Other community or team contact

### Razor Pay Credential ###
key_id,key_secret
rzp_test_QwEJn6cfDnHWKU,liljfoqNUy0SfRPvvJVEoieq
